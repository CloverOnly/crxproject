package com.project.crx.controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.vo.TicketVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface TicketController {
    ModelAndView saveSeat(@ModelAttribute("seat") TicketVO seat) throws Exception;

	ModelAndView saveSeat(TicketVO seat, HttpServletRequest request, HttpServletResponse response,
			RedirectAttributes rAttr);
}
