package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.TicketService;
import com.project.crx.vo.TicketVO;

@Controller
public class TicketControllerImpl implements TicketController {
	
    private final TicketService ticketService;

    // 생성자 주입
    public TicketControllerImpl(TicketService ticketService) {
        this.ticketService = ticketService;
    }
	
	//일반예매
    @GetMapping("/ticket.do")
    public String ticket() {
        return "ticket"; 
    }
    
    //단체예매
    @GetMapping("/groupTicket.do")
    public String groupTicket() {
        return "groupTicket"; 
    }
    
    //역 명 조회 작은 팝업
    @GetMapping("/lookUp.do")
	public String lookUp() {
	    return "lookUp"; 
	}
	@GetMapping("/lookUp2.do")
	public String lookUp2() {
	    return "lookUp2"; 
	}
	
    //좌석예매 팝업
	@GetMapping("/seat.do")
	public ModelAndView seatForm() {
		ModelAndView mav = new ModelAndView("seat");
		return mav;
	}
	
	@Override
	@PostMapping("/seat.do")
	public ModelAndView saveSeat(@ModelAttribute("seat") TicketVO seat, RedirectAttributes rAttr) {
	    ModelAndView mav = new ModelAndView();

	    try {
	        // 좌석 정보를 저장하는 서비스 호출
	        ticketService.saveSeat(seat);

	        // 성공 메시지 설정
	        mav.addObject("message", "좌석 정보가 성공적으로 저장되었습니다.");
	    } catch (Exception e) {
	        e.printStackTrace();
	        mav.addObject("message", "좌석 정보 저장에 실패했습니다.");
	    }

	    return mav;
	}


    
    //예약
    @GetMapping("/reservation.do")
    public String reservation() {
        return "reservation"; 
    }
    
    //결제
    @GetMapping("/payment.do")
    public String payment() {
        return "payment"; 
    }
    
    //발권
    @GetMapping("/ticketing.do")
    public String ticketing() {
        return "ticketing"; 
    }
    
    //예매관리
    @GetMapping("/management.do")
    public String management() {
        return "management"; 
    }
    
    //이용내역
    @GetMapping("/usageDetails.do")
    public String usageDetails() {
        return "usageDetails"; 
    }
    
    //환불
    @GetMapping("/refund.do")
    public String refund() {
        return "refund"; 
    }
    
    //환불완료
    @GetMapping("/refundEnd.do")
    public String refundEnd() {
        return "refundEnd"; 
    }
    
    //화천역
    @GetMapping("/hwacheon.do")
    public String hwacheon() {
        return "hwacheon"; 
    }
    //양구역
    @GetMapping("/yanggu.do")
    public String yanggu() {
        return "yanggu"; 
    }
    //인제역
    @GetMapping("/inje.do")
    public String inje() {
        return "inje"; 
    }
    //고성역
    @GetMapping("/goseong.do")
    public String goseong() {
        return "goseong"; 
    }
    //속초역
    @GetMapping("/sokcho.do")
    public String sokcho() {
        return "sokcho"; 
    }
    //양양역
    @GetMapping("/yangyang.do")
    public String yangyang() {
        return "yangyang"; 
    }
    
    
    
    //테스트
    @GetMapping("/test.do")
    public String test() {
        return "test"; 
    }
    @GetMapping("/test2.do")
    public String test2() {
        return "test2"; 
    }
	@GetMapping("/test3.do")
	public String test3() {
	    return "test3"; 
	}
	@GetMapping("/test4.do")
	public String test4() {
	    return "test4"; 
	}
	
}