package com.project.crx.service;

import com.project.crx.vo.TicketVO;

public interface TicketService {
    void saveSeat(TicketVO seat) throws Exception;
}
