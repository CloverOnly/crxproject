package com.project.crx.dao;

import org.apache.ibatis.annotations.Mapper;

import com.project.crx.vo.TicketVO;

@Mapper
public interface TicketDAO {
    void insertSeat(TicketVO seat) throws Exception;
}
