package com.project.crx.vo;

import lombok.Data;

@Data
public class TicketVO {
    private String payno;        // 결제번호
    private String trainno;      // 열차번호
    private String startname;    // 출발역
    private String endname;      // 도착역
    private String startdate;    // 출발일(승차일)
    private String starttime;    // 출발시각
    private String endtime;      // 도착시각
    private String paystatus;    // 결제상태 
    private String seatType;     // 시트타입
    private String trainType;    // 열차종류
    private String personnelCount;  // 인원수
    private String childCount;      // 어린이수
    private String depTime;      // 출발시간
    private String arrTime;      // 도착시간
    private String duration;     // 소요시간
    private String selectedSeats;        // 호차
    private String hocha;         // 좌석
    private String userid;			//유저 아이디
    private String totalAdultCharge;	//성인요금
    private String totalChildCharge;	//아동요금
    private String totalCharge;			//총요금
    private String totalDiscount;		//할인요금
    private String endCharge;			//최종 요금
    
	private String carno;        // 호차
    private String seat;         // 좌석
    private String seatstatus;   // 좌석 상태
    
    public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getTotalAdultCharge() {
		return totalAdultCharge;
	}
	public void setTotalAdultCharge(String totalAdultCharge) {
		this.totalAdultCharge = totalAdultCharge;
	}
	public String getTotalChildCharge() {
		return totalChildCharge;
	}
	public void setTotalChildCharge(String totalChildCharge) {
		this.totalChildCharge = totalChildCharge;
	}
	public String getTotalCharge() {
		return totalCharge;
	}
	public void setTotalCharge(String totalCharge) {
		this.totalCharge = totalCharge;
	}
	public String getTotalDiscount() {
		return totalDiscount;
	}
	public void setTotalDiscount(String totalDiscount) {
		this.totalDiscount = totalDiscount;
	}
	public String getEndCharge() {
		return endCharge;
	}
	public void setEndCharge(String endCharge) {
		this.endCharge = endCharge;
	}
	public String getSelectedSeats() {
		return selectedSeats;
	}
	public void setSelectedSeats(String selectedSeats) {
		this.selectedSeats = selectedSeats;
	}
	public String getHocha() {
		return hocha;
	}
	public void setHocha(String hocha) {
		this.hocha = hocha;
	}
    public String getSeatType() {
		return seatType;
	}
	public void setSeatType(String seatType) {
		this.seatType = seatType;
	}
	public String getTrainType() {
		return trainType;
	}
	public void setTrainType(String trainType) {
		this.trainType = trainType;
	}
	public String getPersonnelCount() {
		return personnelCount;
	}
	public void setPersonnelCount(String personnelCount) {
		this.personnelCount = personnelCount;
	}
	public String getChildCount() {
		return childCount;
	}
	public void setChildCount(String childCount) {
		this.childCount = childCount;
	}
	public String getDepTime() {
		return depTime;
	}
	public void setDepTime(String depTime) {
		this.depTime = depTime;
	}
	public String getArrTime() {
		return arrTime;
	}
	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getPayno() {
		return payno;
	}
	public void setPayno(String payno) {
		this.payno = payno;
	}
	public String getTrainno() {
		return trainno;
	}
	public String getCarno() {
		return carno;
	}
	public void setCarno(String carno) {
		this.carno = carno;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	}
	public String getSeatstatus() {
		return seatstatus;
	}
	public void setSeatstatus(String seatstatus) {
		this.seatstatus = seatstatus;
	}
	public void setTrainno(String trainno) {
		this.trainno = trainno;
	}
	public String getStartname() {
		return startname;
	}
	public void setStartname(String startname) {
		this.startname = startname;
	}
	public String getEndname() {
		return endname;
	}
	public void setEndname(String endname) {
		this.endname = endname;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public String getPaystatus() {
		return paystatus;
	}
	public void setPaystatus(String paystatus) {
		this.paystatus = paystatus;
	}
    
    
}
