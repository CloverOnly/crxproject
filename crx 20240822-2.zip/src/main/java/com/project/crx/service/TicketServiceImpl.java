package com.project.crx.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.crx.dao.TicketDAO;
import com.project.crx.vo.TicketVO;

@Service
public class TicketServiceImpl implements TicketService {

    private final TicketDAO ticketDAO;

    @Autowired
    public TicketServiceImpl(TicketDAO ticketDAO) {
        this.ticketDAO = ticketDAO;
    }

    @Override
    public void saveReservation(TicketVO reservation) throws Exception {
        ticketDAO.insertReservation(reservation);
    }
    
    @Override
    public List<TicketVO> getPayment() {
        return ticketDAO.getPayment();
    }
}
