package com.project.crx.controller;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.vo.TicketVO;

public interface TicketController {

	ModelAndView saveReservation(TicketVO reservation, RedirectAttributes rAttr);

	ModelAndView saveSeat(TicketVO seat, RedirectAttributes rAttr);
	
}
