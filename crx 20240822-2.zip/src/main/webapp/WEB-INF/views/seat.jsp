<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
	Integer userid = (Integer) session.getAttribute("userid");
%>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
	<title>좌석 선택</title>
    <style>
        body {
            margin: 0;
        }
        .seat-container {
            display: inline-block;
            list-style: none;
            padding: 0;
            margin: 0 5px;
        }
        .seat-button {
            position: relative;
            background: url(../img/seat1.jpg) no-repeat center center;
            background-size: 63%;
            width: 63px;
            height: 60px;
            border: none;
            cursor: pointer;
            text-align: center;
        }
		/* 선택된 좌석 이미지 */
		.seat-button.selected {
		    background: url('../img/seat2.jpg') no-repeat center center;
            background-size: 63%;
		}
        .seat-button label {
            position: absolute;
            left: 59%;
            transform: translateX(-50%);
            color: black;
            font-size: 14px;
            font-weight: bold;
            top: 27px;
        }
        .line {
            border: solid 2px green;
        }
        .seatAll {
            border-width: 10px 5px 5px 5px;
            border-style: solid;
            border-color: green;
        }
        .seatTitle {
            background: green;
            color: white;
            width: 100%;
            height: 60px;
            text-align: center;
            line-height: 60px;
            margin: 1;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .uall {
            margin: -14px;
        }
        .hoBa {
            background: url(../img/train.png) no-repeat center center;
            background-size: cover;
            height: 110px;
        }
        .ho {
            list-style: none;
            display: inline-block;
        }
        .hocha {
            position: relative;
            background: url(../img/ss.jpg) no-repeat center center;
            background-size: cover;
            width: 111px;
            height: 48px;
            border: none;
            cursor: pointer;
            text-align: center;
            top: 48px;
            right: -85%;
        }
		/* 선택된 호차의 이미지 */
		.hocha.selected {
		    background: url('../img/ss2.jpg') no-repeat center center;
		    background-size: cover;
		}
		a:hover .hocha {
		    background-image: url('../img/ss2.jpg');
		    background-size: cover;
		}
        .ho label {
            position: absolute;
            left: 38%;
            color: black;
            font-size: 14px;
            font-weight: bold;
            top: 14px;
        }
        .line2 {
            position: relative;
            width: 820px;
            height: 1px;
            background: repeating-linear-gradient(to right, 
                black 0%, 
                black 2px, 
                transparent 2px, 
                transparent 4px
            );
            background-size: 4px 100%;
            color: green;
            margin: 24px;
        }
        .cre {
            position: relative;
            left: 99%;
            top: -15px;
            font-size: 21px;
            background-repeat: repeat-x;
            color: green;
        }
        #seatReservation {
			background: green;
			    color: white;
			    border: 1px solid green;
			    border-radius: 12px;
			    padding: 10px;
			    position: absolute;
			    bottom: 138px;
			    right: 15px
        }
        .butt {
            text-align: center;
        }
        .tli {
            font-size: 12px;
        }
        .fie {
            width: 950px;
        }
        .centered-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }
        .inf {
            float: right;
        }
    </style>
    <meta name="viewport" content="width=1000">
	<script>
	    let selectedHocha = '';
	    let selectedSeats = [];
	    let totalCount = 0;
	    let totalAdultCharge = 0;
	    let totalChildCharge = 0;
	    let totalDiscount = 0;

	    function toggleSeat(sectionId, buttonElement) {
	        document.querySelectorAll('.hocha').forEach(function(button) {
	            button.classList.remove('selected');
	        });

	        document.querySelectorAll('.section').forEach(function(section) {
	            section.style.display = 'none';
	        });

	        buttonElement.classList.add('selected');
	        selectedHocha = buttonElement.value;

	        const section = document.getElementById(sectionId);
	        if (section) {
	            section.style.display = 'block';
	        }

	        updateSelectionInfo();
	    }

	    function abcdSeat(buttonElement) {
	        const isSelected = buttonElement.classList.contains('selected');
	        
	        if (!isSelected && selectedSeats.length < totalCount) {
	            buttonElement.classList.add('selected');
	            selectedSeats.push(buttonElement.value);
	        } else if (isSelected) {
	            buttonElement.classList.remove('selected');
	            selectedSeats = selectedSeats.filter(seat => seat !== buttonElement.value);
	        }
	        
	        updateSelectionInfo();
	    }

	    function updateSelectionInfo() {
	        const seatCheck = document.getElementById('sitCheck');
	        const hocha = document.getElementById('sitHo');

	        if (selectedSeats.length > 0) {
	            seatCheck.innerText = selectedSeats.join(', ');
	            hocha.innerText = selectedHocha;
	            hocha.style.display = 'inline';
	        } else {
	            seatCheck.innerText = '';
	            hocha.innerText = '';
	            hocha.style.display = 'none';
	        }
	    }

	    function setFormValues() {
	        var startname = window.opener.document.getElementById('depplacename').value;
	        var endname = window.opener.document.getElementById('arrplacename').value;
	        var seatType = window.opener.document.getElementById('seatType').value;
	        var startdate = window.opener.document.getElementById('formattedDate').value;
	        var trainType = window.opener.document.querySelector('input[name="flexRadioDefault"]:checked').value;
	        var personnelCount = parseInt(window.opener.document.getElementById('hiddenPersonnel').value, 10) || 0;
	        var childCount = parseInt(window.opener.document.getElementById('hiddenChild').value, 10) || 0;
	        totalCount = personnelCount + childCount;

	        var queryString = window.location.search;
	        var urlParams = new URLSearchParams(queryString);

	        var trainno = urlParams.get('trainno');
	        var depTime = urlParams.get('depTime');
	        var arrTime = urlParams.get('arrTime');
	        var duration = urlParams.get('duration');
	        var userid = urlParams.get('userid');
	        var adultcharge = parseFloat(urlParams.get('adultcharge')) || 0;

	        totalAdultCharge = adultcharge * personnelCount;
	        var discountedAdultCharge = adultcharge * 0.9;
	        totalChildCharge = discountedAdultCharge * childCount;

	        var endCharge = totalAdultCharge + totalChildCharge;
	        totalDiscount = (adultcharge - discountedAdultCharge) * childCount;
	        var totalCharge = adultcharge * totalCount;

	        totalAdultCharge = isValidNumber(totalAdultCharge) ? totalAdultCharge : 0;
	        totalChildCharge = isValidNumber(totalChildCharge) ? totalChildCharge : 0;
	        endCharge = isValidNumber(endCharge) ? endCharge : 0;
	        totalCharge = isValidNumber(totalCharge) ? totalCharge : 0;
	        totalDiscount = isValidNumber(totalDiscount) ? totalDiscount : 0;

	        document.getElementById('startname').value = startname;
	        document.getElementById('endname').value = endname;
	        document.getElementById('seatType').value = seatType;
	        document.getElementById('startdate').value = startdate;
	        document.getElementById('trainType').value = trainType;
	        document.getElementById('personnelCount').value = personnelCount;
	        document.getElementById('childCount').value = childCount;
	        document.getElementById('trainno').value = trainno;
	        document.getElementById('depTime').value = depTime;
	        document.getElementById('arrTime').value = arrTime;
	        document.getElementById('duration').value = duration;
	        document.getElementById('totalAdultCharge').value = totalAdultCharge;
	        document.getElementById('totalChildCharge').value = totalChildCharge;
	        document.getElementById('endCharge').value = endCharge;
	        document.getElementById('totalCharge').value = totalCharge;
	        document.getElementById('totalDiscount').value = totalDiscount;
	        document.getElementById('userid').value = userid; // Add this line
			
			console.log('출발역:', startname);
			console.log('도착역:', endname);
			console.log('좌석타입:', seatType);
			console.log('열차종류:', trainType);
			console.log('성인인원:', personnelCount);
			console.log('아동인원:', childCount);
			console.log('열차번호:', trainno);
			console.log('출발시간:', depTime);
			console.log('도착시간:', arrTime);
			console.log('소요시간:', duration);
			console.log('성인요금:', totalAdultCharge);
			console.log('아동요금:', totalChildCharge);
			console.log('최종요금:', endCharge);
			console.log('총요금:', totalCharge);
			console.log('총할인요금:', totalDiscount);

	    }

	    function isValidNumber(value) {
	        return !isNaN(value) && isFinite(value);
	    }

	    window.addEventListener('load', function() {
	        setFormValues();
	    });

	    window.onload = function() {
	        const firstSectionButton = document.querySelector('.hocha[data-section="section1"]');
	        if (firstSectionButton) {
	            toggleSeat('section1', firstSectionButton);
	        }
	    };

	    function seatForm(event) {
	        updateSelectionInfo();
	        setFormValues();

	        if (selectedSeats.length < totalCount) {
	            alert('선택된 좌석이 인원수보다 적습니다. 인원수에 맞는 좌석을 선택해 주세요.');
	            if (event) {
	                event.preventDefault(); // 폼 제출을 방지합니다.
	            }
	            return;
	        }

	        document.getElementById('selectedSeats').value = selectedSeats.join(',');
	        document.getElementById('hocha').value = selectedHocha || '';

	        document.getElementById('seatForm').submit();
			    
			if (window.opener) {
			        window.opener.location.href = 'reservation.do?' + new URLSearchParams(new FormData(document.getElementById('seatForm'))).toString();
			        window.close(); // 자식 창을 닫습니다.
			    } else {
			        document.getElementById('seatForm').submit(); // 부모 창이 없는 경우 폼을 제출합니다.
			    }
			
	    }
	</script>



</head>
<body>
    <div class="seatTitle">    
        <h2>좌석 선택</h2>
    </div>
    <div class="seatAll">
        <ul class="tli">
            <li>요청하신 승객 명의 원하시는 좌석을 선택하여 주십시오.</li>
            <li>발매가 가능한 좌석을 선택하실 수 있습니다.</li>
            <li>원하시는 좌석을 선택 후 <strong>[선택좌석 예약하기]</strong> 버튼을 클릭하시면 예약이 완료됩니다.</li>
            <li>원하지 않는 좌석이 선택된 경우에는 좌석을 한번 더 클릭하시면 취소됩니다.</li>
        </ul>
        <div class="centered-container">
            <fieldset class="fie">
				<ul class="hoBa">
				    <li class="ho">
				        <button class="hocha" data-section="section1" value="1호차" onclick="toggleSeat('section1', this)">
				            <label>1호차</label>
				        </button>
				    </li>
				    <li class="ho">
				        <button class="hocha" data-section="section2" value="2호차" onclick="toggleSeat('section2', this)">
				            <label>2호차</label>
				        </button>
				    </li>
				    <li class="ho">
				        <button class="hocha" data-section="section3" value="3호차" onclick="toggleSeat('section3', this)">
				            <label>3호차</label>
				        </button>
				    </li>
				    <li class="ho">
				        <button class="hocha" data-section="section4" value="4호차" onclick="toggleSeat('section4', this)">
				            <label>4호차</label>
				        </button>
				    </li>
				    <li class="ho">
				        <button class="hocha" data-section="section5" value="5호차" onclick="toggleSeat('section5', this)">
				            <label>5호차</label>
				        </button>
				    </li>
				    <li class="ho">
				        <button class="hocha" data-section="section6" value="6호차" onclick="toggleSeat('section6', this)">
				            <label>6호차</label>
				        </button>
				    </li>
				</ul>
            </fieldset>
        </div>
        
        <br>
        <div class="inf">
            <span><span style="color: green;">■</span> 선택좌석</span> <span><span style="color: gray;">■</span> 선택불가</span> <span>□ 선택가능</span>
        </div>
        <br>
        
        <ul class="line"></ul>
        
        <div id="section1" class="section" style="display: block;">  
				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1A" onclick="abcdSeat(this)">
							<label>1A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2A" onclick="abcdSeat(this)">
							<label>2A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3A" onclick="abcdSeat(this)">
							<label>3A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4A" onclick="abcdSeat(this)">
							<label>4A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5A" onclick="abcdSeat(this)">
							<label>5A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6A" onclick="abcdSeat(this)">
							<label>6A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7A" onclick="abcdSeat(this)">
							<label>7A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8A" onclick="abcdSeat(this)">
							<label>8A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9A" onclick="abcdSeat(this)">
							<label>9A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10A" onclick="abcdSeat(this)">
							<label>10A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="11A" onclick="abcdSeat(this)">
							<label>11A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12A" onclick="abcdSeat(this)">
							<label>12A</label>
						</button>
					</li>
				</ul>

				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1B" onclick="abcdSeat(this)">
							<label>1B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2B" onclick="abcdSeat(this)">
							<label>2B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3B" onclick="abcdSeat(this)">
							<label>3B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4B" onclick="abcdSeat(this)">
							<label>4B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5B" onclick="abcdSeat(this)">
							<label>5B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6B" onclick="abcdSeat(this)">
							<label>6B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7B" onclick="abcdSeat(this)">
							<label>7B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8B" onclick="abcdSeat(this)">
							<label>8B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9B" onclick="abcdSeat(this)">
							<label>9B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10B" onclick="abcdSeat(this)">
							<label>10B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value= "11B" onclick="abcdSeat(this)">
							<label>11B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12B" onclick="abcdSeat(this)">
							<label>12B</label>
						</button>
					</li>
				</ul>

				<ul class="line2"><i class="cre bi bi-chevron-double-right"></i></ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1C" onclick="abcdSeat(this)">
								<label>1C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2C" onclick="abcdSeat(this)">
								<label>2C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3C" onclick="abcdSeat(this)">
								<label>3C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4C" onclick="abcdSeat(this)">
								<label>4C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5C" onclick="abcdSeat(this)">
								<label>5C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6C" onclick="abcdSeat(this)">
								<label>6C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7C" onclick="abcdSeat(this)">
								<label>7C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8C" onclick="abcdSeat(this)">
								<label>8C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9C" onclick="abcdSeat(this)">
								<label>9C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10C" onclick="abcdSeat(this)">
								<label>10C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11C" onclick="abcdSeat(this)">
								<label>11C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12C" onclick="abcdSeat(this)">
								<label>12C</label>
							</button>
						</li>
					</ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1D" onclick="abcdSeat(this)">
								<label>1D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2D" onclick="abcdSeat(this)">
								<label>2D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3D" onclick="abcdSeat(this)">
								<label>3D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4D" onclick="abcdSeat(this)">
								<label>4D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5D" onclick="abcdSeat(this)">
								<label>5D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6D" onclick="abcdSeat(this)">
								<label>6D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7D" onclick="abcdSeat(this)">
								<label>7D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8D" onclick="abcdSeat(this)">
								<label>8D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9D" onclick="abcdSeat(this)">
								<label>9D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10D" onclick="abcdSeat(this)">
								<label>10D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11D" onclick="abcdSeat(this)">
								<label>11D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12D" onclick="abcdSeat(this)">
								<label>12D</label>
							</button>
						</li>
					</ul>
					
					<ul class="line"></ul>
			</div>

        <div id="section2" class="section" style="display: none;"> 
				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1A" onclick="abcdSeat(this)">
							<label>1A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2A" onclick="abcdSeat(this)">
							<label>2A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3A" onclick="abcdSeat(this)">
							<label>3A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4A" onclick="abcdSeat(this)">
							<label>4A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5A" onclick="abcdSeat(this)">
							<label>5A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6A" onclick="abcdSeat(this)">
							<label>6A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7A" onclick="abcdSeat(this)">
							<label>7A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8A" onclick="abcdSeat(this)">
							<label>8A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9A" onclick="abcdSeat(this)">
							<label>9A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10A" onclick="abcdSeat(this)">
							<label>10A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="11A" onclick="abcdSeat(this)">
							<label>11A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12A" onclick="abcdSeat(this)">
							<label>12A</label>
						</button>
					</li>
				</ul>

				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1B" onclick="abcdSeat(this)">
							<label>1B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2B" onclick="abcdSeat(this)">
							<label>2B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3B" onclick="abcdSeat(this)">
							<label>3B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4B" onclick="abcdSeat(this)">
							<label>4B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5B" onclick="abcdSeat(this)">
							<label>5B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6B" onclick="abcdSeat(this)">
							<label>6B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7B" onclick="abcdSeat(this)">
							<label>7B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8B" onclick="abcdSeat(this)">
							<label>8B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9B" onclick="abcdSeat(this)">
							<label>9B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10B" onclick="abcdSeat(this)">
							<label>10B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value= "11B" onclick="abcdSeat(this)">
							<label>11B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12B" onclick="abcdSeat(this)">
							<label>12B</label>
						</button>
					</li>
				</ul>

				<ul class="line2"><i class="cre bi bi-chevron-double-right"></i></ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1C" onclick="abcdSeat(this)">
								<label>1C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2C" onclick="abcdSeat(this)">
								<label>2C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3C" onclick="abcdSeat(this)">
								<label>3C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4C" onclick="abcdSeat(this)">
								<label>4C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5C" onclick="abcdSeat(this)">
								<label>5C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6C" onclick="abcdSeat(this)">
								<label>6C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7C" onclick="abcdSeat(this)">
								<label>7C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8C" onclick="abcdSeat(this)">
								<label>8C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9C" onclick="abcdSeat(this)">
								<label>9C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10C" onclick="abcdSeat(this)">
								<label>10C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11C" onclick="abcdSeat(this)">
								<label>11C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12C" onclick="abcdSeat(this)">
								<label>12C</label>
							</button>
						</li>
					</ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1D" onclick="abcdSeat(this)">
								<label>1D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2D" onclick="abcdSeat(this)">
								<label>2D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3D" onclick="abcdSeat(this)">
								<label>3D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4D" onclick="abcdSeat(this)">
								<label>4D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5D" onclick="abcdSeat(this)">
								<label>5D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6D" onclick="abcdSeat(this)">
								<label>6D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7D" onclick="abcdSeat(this)">
								<label>7D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8D" onclick="abcdSeat(this)">
								<label>8D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9D" onclick="abcdSeat(this)">
								<label>9D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10D" onclick="abcdSeat(this)">
								<label>10D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11D" onclick="abcdSeat(this)">
								<label>11D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12D" onclick="abcdSeat(this)">
								<label>12D</label>
							</button>
						</li>
					</ul>
					
					<ul class="line"></ul>
			</div>

        <div id="section3" class="section" style="display: none;">
				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1A" onclick="abcdSeat(this)">
							<label>1A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2A" onclick="abcdSeat(this)">
							<label>2A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3A" onclick="abcdSeat(this)">
							<label>3A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4A" onclick="abcdSeat(this)">
							<label>4A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5A" onclick="abcdSeat(this)">
							<label>5A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6A" onclick="abcdSeat(this)">
							<label>6A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7A" onclick="abcdSeat(this)">
							<label>7A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8A" onclick="abcdSeat(this)">
							<label>8A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9A" onclick="abcdSeat(this)">
							<label>9A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10A" onclick="abcdSeat(this)">
							<label>10A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="11A" onclick="abcdSeat(this)">
							<label>11A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12A" onclick="abcdSeat(this)">
							<label>12A</label>
						</button>
					</li>
				</ul>

				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1B" onclick="abcdSeat(this)">
							<label>1B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2B" onclick="abcdSeat(this)">
							<label>2B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3B" onclick="abcdSeat(this)">
							<label>3B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4B" onclick="abcdSeat(this)">
							<label>4B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5B" onclick="abcdSeat(this)">
							<label>5B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6B" onclick="abcdSeat(this)">
							<label>6B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7B" onclick="abcdSeat(this)">
							<label>7B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8B" onclick="abcdSeat(this)">
							<label>8B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9B" onclick="abcdSeat(this)">
							<label>9B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10B" onclick="abcdSeat(this)">
							<label>10B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value= "11B" onclick="abcdSeat(this)">
							<label>11B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12B" onclick="abcdSeat(this)">
							<label>12B</label>
						</button>
					</li>
				</ul>

				<ul class="line2"><i class="cre bi bi-chevron-double-right"></i></ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1C" onclick="abcdSeat(this)">
								<label>1C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2C" onclick="abcdSeat(this)">
								<label>2C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3C" onclick="abcdSeat(this)">
								<label>3C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4C" onclick="abcdSeat(this)">
								<label>4C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5C" onclick="abcdSeat(this)">
								<label>5C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6C" onclick="abcdSeat(this)">
								<label>6C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7C" onclick="abcdSeat(this)">
								<label>7C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8C" onclick="abcdSeat(this)">
								<label>8C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9C" onclick="abcdSeat(this)">
								<label>9C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10C" onclick="abcdSeat(this)">
								<label>10C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11C" onclick="abcdSeat(this)">
								<label>11C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12C" onclick="abcdSeat(this)">
								<label>12C</label>
							</button>
						</li>
					</ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1D" onclick="abcdSeat(this)">
								<label>1D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2D" onclick="abcdSeat(this)">
								<label>2D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3D" onclick="abcdSeat(this)">
								<label>3D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4D" onclick="abcdSeat(this)">
								<label>4D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5D" onclick="abcdSeat(this)">
								<label>5D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6D" onclick="abcdSeat(this)">
								<label>6D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7D" onclick="abcdSeat(this)">
								<label>7D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8D" onclick="abcdSeat(this)">
								<label>8D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9D" onclick="abcdSeat(this)">
								<label>9D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10D" onclick="abcdSeat(this)">
								<label>10D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11D" onclick="abcdSeat(this)">
								<label>11D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12D" onclick="abcdSeat(this)">
								<label>12D</label>
							</button>
						</li>
					</ul>
					
					<ul class="line"></ul>
			</div>
		
		<div id="section4" class="section" style="display: none;">
				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1A" onclick="abcdSeat(this)">
							<label>1A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2A" onclick="abcdSeat(this)">
							<label>2A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3A" onclick="abcdSeat(this)">
							<label>3A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4A" onclick="abcdSeat(this)">
							<label>4A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5A" onclick="abcdSeat(this)">
							<label>5A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6A" onclick="abcdSeat(this)">
							<label>6A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7A" onclick="abcdSeat(this)">
							<label>7A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8A" onclick="abcdSeat(this)">
							<label>8A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9A" onclick="abcdSeat(this)">
							<label>9A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10A" onclick="abcdSeat(this)">
							<label>10A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="11A" onclick="abcdSeat(this)">
							<label>11A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12A" onclick="abcdSeat(this)">
							<label>12A</label>
						</button>
					</li>
				</ul>

				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1B" onclick="abcdSeat(this)">
							<label>1B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2B" onclick="abcdSeat(this)">
							<label>2B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3B" onclick="abcdSeat(this)">
							<label>3B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4B" onclick="abcdSeat(this)">
							<label>4B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5B" onclick="abcdSeat(this)">
							<label>5B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6B" onclick="abcdSeat(this)">
							<label>6B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7B" onclick="abcdSeat(this)">
							<label>7B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8B" onclick="abcdSeat(this)">
							<label>8B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9B" onclick="abcdSeat(this)">
							<label>9B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10B" onclick="abcdSeat(this)">
							<label>10B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value= "11B" onclick="abcdSeat(this)">
							<label>11B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12B" onclick="abcdSeat(this)">
							<label>12B</label>
						</button>
					</li>
				</ul>

				<ul class="line2"><i class="cre bi bi-chevron-double-right"></i></ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1C" onclick="abcdSeat(this)">
								<label>1C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2C" onclick="abcdSeat(this)">
								<label>2C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3C" onclick="abcdSeat(this)">
								<label>3C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4C" onclick="abcdSeat(this)">
								<label>4C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5C" onclick="abcdSeat(this)">
								<label>5C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6C" onclick="abcdSeat(this)">
								<label>6C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7C" onclick="abcdSeat(this)">
								<label>7C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8C" onclick="abcdSeat(this)">
								<label>8C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9C" onclick="abcdSeat(this)">
								<label>9C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10C" onclick="abcdSeat(this)">
								<label>10C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11C" onclick="abcdSeat(this)">
								<label>11C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12C" onclick="abcdSeat(this)">
								<label>12C</label>
							</button>
						</li>
					</ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1D" onclick="abcdSeat(this)">
								<label>1D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2D" onclick="abcdSeat(this)">
								<label>2D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3D" onclick="abcdSeat(this)">
								<label>3D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4D" onclick="abcdSeat(this)">
								<label>4D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5D" onclick="abcdSeat(this)">
								<label>5D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6D" onclick="abcdSeat(this)">
								<label>6D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7D" onclick="abcdSeat(this)">
								<label>7D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8D" onclick="abcdSeat(this)">
								<label>8D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9D" onclick="abcdSeat(this)">
								<label>9D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10D" onclick="abcdSeat(this)">
								<label>10D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11D" onclick="abcdSeat(this)">
								<label>11D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12D" onclick="abcdSeat(this)">
								<label>12D</label>
							</button>
						</li>
					</ul>
					
					<ul class="line"></ul>
			</div>
		
		<div id="section5" class="section" style="display: none;">
				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1A" onclick="abcdSeat(this)">
							<label>1A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2A" onclick="abcdSeat(this)">
							<label>2A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3A" onclick="abcdSeat(this)">
							<label>3A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4A" onclick="abcdSeat(this)">
							<label>4A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5A" onclick="abcdSeat(this)">
							<label>5A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6A" onclick="abcdSeat(this)">
							<label>6A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7A" onclick="abcdSeat(this)">
							<label>7A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8A" onclick="abcdSeat(this)">
							<label>8A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9A" onclick="abcdSeat(this)">
							<label>9A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10A" onclick="abcdSeat(this)">
							<label>10A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="11A" onclick="abcdSeat(this)">
							<label>11A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12A" onclick="abcdSeat(this)">
							<label>12A</label>
						</button>
					</li>
				</ul>

				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1B" onclick="abcdSeat(this)">
							<label>1B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2B" onclick="abcdSeat(this)">
							<label>2B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3B" onclick="abcdSeat(this)">
							<label>3B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4B" onclick="abcdSeat(this)">
							<label>4B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5B" onclick="abcdSeat(this)">
							<label>5B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6B" onclick="abcdSeat(this)">
							<label>6B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7B" onclick="abcdSeat(this)">
							<label>7B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8B" onclick="abcdSeat(this)">
							<label>8B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9B" onclick="abcdSeat(this)">
							<label>9B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10B" onclick="abcdSeat(this)">
							<label>10B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value= "11B" onclick="abcdSeat(this)">
							<label>11B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12B" onclick="abcdSeat(this)">
							<label>12B</label>
						</button>
					</li>
				</ul>

				<ul class="line2"><i class="cre bi bi-chevron-double-right"></i></ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1C" onclick="abcdSeat(this)">
								<label>1C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2C" onclick="abcdSeat(this)">
								<label>2C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3C" onclick="abcdSeat(this)">
								<label>3C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4C" onclick="abcdSeat(this)">
								<label>4C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5C" onclick="abcdSeat(this)">
								<label>5C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6C" onclick="abcdSeat(this)">
								<label>6C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7C" onclick="abcdSeat(this)">
								<label>7C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8C" onclick="abcdSeat(this)">
								<label>8C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9C" onclick="abcdSeat(this)">
								<label>9C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10C" onclick="abcdSeat(this)">
								<label>10C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11C" onclick="abcdSeat(this)">
								<label>11C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12C" onclick="abcdSeat(this)">
								<label>12C</label>
							</button>
						</li>
					</ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1D" onclick="abcdSeat(this)">
								<label>1D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2D" onclick="abcdSeat(this)">
								<label>2D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3D" onclick="abcdSeat(this)">
								<label>3D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4D" onclick="abcdSeat(this)">
								<label>4D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5D" onclick="abcdSeat(this)">
								<label>5D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6D" onclick="abcdSeat(this)">
								<label>6D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7D" onclick="abcdSeat(this)">
								<label>7D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8D" onclick="abcdSeat(this)">
								<label>8D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9D" onclick="abcdSeat(this)">
								<label>9D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10D" onclick="abcdSeat(this)">
								<label>10D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11D" onclick="abcdSeat(this)">
								<label>11D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12D" onclick="abcdSeat(this)">
								<label>12D</label>
							</button>
						</li>
					</ul>
					
					<ul class="line"></ul>
			</div>
		
		<div id="section6" class="section" style="display: none;">
				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1A" onclick="abcdSeat(this)">
							<label>1A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2A" onclick="abcdSeat(this)">
							<label>2A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3A" onclick="abcdSeat(this)">
							<label>3A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4A" onclick="abcdSeat(this)">
							<label>4A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5A" onclick="abcdSeat(this)">
							<label>5A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6A" onclick="abcdSeat(this)">
							<label>6A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7A" onclick="abcdSeat(this)">
							<label>7A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8A" onclick="abcdSeat(this)">
							<label>8A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9A" onclick="abcdSeat(this)">
							<label>9A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10A" onclick="abcdSeat(this)">
							<label>10A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="11A" onclick="abcdSeat(this)">
							<label>11A</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12A" onclick="abcdSeat(this)">
							<label>12A</label>
						</button>
					</li>
				</ul>

				<ul class="uall">
					<li class="seat-container">
						<button class="seat-button" value="1B" onclick="abcdSeat(this)">
							<label>1B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="2B" onclick="abcdSeat(this)">
							<label>2B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="3B" onclick="abcdSeat(this)">
							<label>3B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="4B" onclick="abcdSeat(this)">
							<label>4B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="5B" onclick="abcdSeat(this)">
							<label>5B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="6B" onclick="abcdSeat(this)">
							<label>6B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="7B" onclick="abcdSeat(this)">
							<label>7B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="8B" onclick="abcdSeat(this)">
							<label>8B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="9B" onclick="abcdSeat(this)">
							<label>9B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="10B" onclick="abcdSeat(this)">
							<label>10B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value= "11B" onclick="abcdSeat(this)">
							<label>11B</label>
						</button>
					</li>
					<li class="seat-container">
						<button class="seat-button" value="12B" onclick="abcdSeat(this)">
							<label>12B</label>
						</button>
					</li>
				</ul>

				<ul class="line2"><i class="cre bi bi-chevron-double-right"></i></ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1C" onclick="abcdSeat(this)">
								<label>1C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2C" onclick="abcdSeat(this)">
								<label>2C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3C" onclick="abcdSeat(this)">
								<label>3C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4C" onclick="abcdSeat(this)">
								<label>4C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5C" onclick="abcdSeat(this)">
								<label>5C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6C" onclick="abcdSeat(this)">
								<label>6C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7C" onclick="abcdSeat(this)">
								<label>7C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8C" onclick="abcdSeat(this)">
								<label>8C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9C" onclick="abcdSeat(this)">
								<label>9C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10C" onclick="abcdSeat(this)">
								<label>10C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11C" onclick="abcdSeat(this)">
								<label>11C</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12C" onclick="abcdSeat(this)">
								<label>12C</label>
							</button>
						</li>
					</ul>

					<ul class="uall">
						<li class="seat-container">
							<button class="seat-button" value="1D" onclick="abcdSeat(this)">
								<label>1D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="2D" onclick="abcdSeat(this)">
								<label>2D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="3D" onclick="abcdSeat(this)">
								<label>3D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="4D" onclick="abcdSeat(this)">
								<label>4D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="5D" onclick="abcdSeat(this)">
								<label>5D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="6D" onclick="abcdSeat(this)">
								<label>6D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="7D" onclick="abcdSeat(this)">
								<label>7D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="8D" onclick="abcdSeat(this)">
								<label>8D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="9D" onclick="abcdSeat(this)">
								<label>9D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="10D" onclick="abcdSeat(this)">
								<label>10D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="11D" onclick="abcdSeat(this)">
								<label>11D</label>
							</button>
						</li>
						<li class="seat-container">
							<button class="seat-button" value="12D" onclick="abcdSeat(this)">
								<label>12D</label>
							</button>
						</li>
					</ul>
					
					<ul class="line"></ul>
			</div>
			<br>
		<div>
		    <span>현재 선택된 좌석:</span> <strong id="sitHo"></strong> <strong id="sitCheck"></strong>
		</div>
        
		
		<form id="seatForm" action="reservation.jsp" method="post">
		    <input type="hidden" id="startname" name="startname" />
		    <input type="hidden" id="endname" name="endname" />
		    <input type="hidden" id="seatType" name="seatType" />
		    <input type="hidden" id="startdate" name="startdate" />
		    <input type="hidden" id="trainType" name="trainType" />
		    <input type="hidden" id="personnelCount" name="personnelCount" />
		    <input type="hidden" id="childCount" name="childCount" />
		    <input type="hidden" id="trainno" name="trainno" />
		    <input type="hidden" id="depTime" name="depTime" />
		    <input type="hidden" id="arrTime" name="arrTime" />
		    <input type="hidden" id="duration" name="duration" />
		    <input type="hidden" id="selectedSeats" name="selectedSeats" />
		    <input type="hidden" id="hocha" name="hocha" />
		    <input type="hidden" id="totalAdultCharge" name="totalAdultCharge" />
		    <input type="hidden" id="totalChildCharge" name="totalChildCharge" />
		    <input type="hidden" id="endCharge" name="endCharge" />
		    <input type="hidden" id="totalCharge" name="totalCharge" />
		    <input type="hidden" id="totalDiscount" name="totalDiscount" />
		    <input type="hidden" id="userid" name="userid" />
		    
		    <!-- 버튼 클릭 시 폼을 제출합니다 -->
		    <button id="seatReservation" type="button" onclick="seatForm()">좌석 예매하기</button>
		</form>
		<br>
    </div>         
</body>
</html>
