package com.project.crx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class InfoControllerImpl {
    
    /********** 종합이용안내 **********/
    
    // 열차서비스
    @GetMapping("/trainService.do")
    public String trainService() {
    	return "trainService";
    }
    
    // 연계교통서비스
    @GetMapping("/linkService.do")
    public String linkService() {
    	return "linkService";
    }
    
    // 휠체어서비스
    @GetMapping("/wheelService.do")
    public String wheelService() {
    	return "wheelService";
    }
    
    /********** 승차권 이용안내 **********/
    
    // 승차권 구입/환불/분실
    @GetMapping("/ticketManagement.do")
    public String ticketManagement() {
    	return "ticketManagement";
    }
    
    // 열차지연/ 운행중지
    @GetMapping("/trainDelayStop.do")
    public String trainDelayStop() {
    	return "trainDelayStop";
    }
    
    // 열차운임 및 시간표
    @GetMapping("/trainFaresTime.do")
    public String trainFaresTime() {
    	return "trainFaresTime";
    }
    
    /********** 지연배상신청 **********/
    
    // 열차지연 시 교통비 지급 안내문
    @GetMapping("/trainDelayRefund.do")
    public String trainDelayRefund() {
    	return "trainDelayRefund";
    }
    
    // 지연료 계좌반환 신청
    @GetMapping("/delayCompensationRequest.do")
    public String delayCompensationRequest() {
    	return "delayCompensationRequest";
    }
    
    /********** 서비스 예약 **********/
    
    // 서비스 예약
    @GetMapping("/serviceReservation.do")
    public String serviceReservation() {
    	return "serviceReservation";
    }
}