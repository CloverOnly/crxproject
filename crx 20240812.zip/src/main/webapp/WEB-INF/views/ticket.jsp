<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>일반승차권 예매</title>
	<style>
	    .all {
	        width: 1200px;
	        margin: 0 auto; /* 중앙 정렬 */
	    }
	    .tiline {
	        display: inline;
	        border: solid 1px green;
	        border-radius: 8px;
	        padding: 5px;
	        color: green;
	        margin: 5px;
	    }
	    .mid {
	        height: 300px;
	        background: #f8f8f8;
			margin: 0 5px;
			padding: 5px;
	    }

	    .rt {
	        margin: 3px;
	    }
	    .search {
	        text-align: center;
	    }
	    .minititle a {
	        color: #000000;
	    }
	    table, th, td {
	        border: 2px solid white;
	        border-collapse: collapse;
	    }
	    #Date {
	        width: 140px;
	        display: inline;
	    }
	    .checkTrain {
	        border: 2px solid white;
	        border-collapse: collapse;
	        width: 100%;
	    }
	    #swapIcon {
	        font-size: 20px;
	        cursor: pointer; /* 클릭 가능성 추가 */
	    }
		#depplacename{
			background: white;
			color: black;
		}
		#arrplacename{
			background: white;
			color: black;
		}
		.seat-btn{
			font-size: 12px;
			background: green;
		}
		.checkTrain {
		    width: 100%;
		    border-collapse: collapse;
		}
		.checkTrain th, .checkTrain td {
		    border: 1px solid #ddd;
		    padding: 8px;
		    text-align: center;
		}
		.checkTrain th {
		    background-color: #f2f2f2;
		    color: black;
		}
		.checkTrain tr:nth-child(even) {
		    background-color: #f9f9f9;
		}
		.checkTrain tr:hover {
		    background-color: #ddd;
		}
	</style>
</head>
<body>
	<jsp:include page="header.jsp" />
    <div class="all">
        <div class="maintitle">
            <h1>일반승차권</h1>
            <hr>
        </div>

        <br>
        <div style="text-align:center;">
            <img src="../img/mark1.gif" style="width:500px">
        </div>

        <br>
        <div>
            <br>
            <ul class="nav nav-tabs">
                <li class="minititle nav-item">
                    <a class="nav-link active bg-light" aria-current="page" href="ticket.do">일반승차권 조회</a>
                </li>
                <li class="minititle nav-item">
                    <a class="nav-link" href="groupTicket.do">단체승차권 조회</a>
                </li>
            </ul>
        </div>
		<div class="mid">		   
            <br>
			<div class="rt" id="station">
			    <label for="depplacename">출발역</label>
			    <input id="depplacename" name="depplacename" type="text" class="inp200" title="출발역" disabled>
				<input type="hidden" id="depPlaceIdHidden">
				<input type="button" value="조회" onclick="openChild()">
			    &nbsp;&nbsp;
			    <i id="swapIcon" class="bi bi-arrow-repeat" onclick="swapStations()"></i>
			    &nbsp;&nbsp;
			    <label for="arrplacename">도착역</label>
			    <input id="arrplacename" name="arrplacename" type="text" class="inp200" title="도착역" disabled>
				<input type="hidden" id="arrPlaceIdHidden">
				<input type="button" value="조회" onclick="openChild2()">
			</div>

            <br>
			<div class="rt" id="arrplandtime">
			    <label for="Date">출발일</label>
			    <input type="date" id="Date" name="lostItemRegDate" onchange="formatDate()">
				<input type="hidden" id="formattedDate">
			
                &nbsp;&nbsp;
                <label for="timeSelect">시간</label>
                <select id="timeSelect">
                    <option value="08" selected="selected">08</option>
                    <option value="09">09</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                    <option value="13">13</option>
                    <option value="14">14</option>
                    <option value="15">15</option>
                    <option value="16">16</option>
                    <option value="17">17</option>
                    <option value="18">18</option>
                    <option value="19">19</option>
                    <option value="20">20</option>
                    <option value="21">21</option>
                    <option value="22">22</option>
                    <option value="23">23</option>
                    <option value="24">24</option>
                </select>
                <label id="listtime">시</label>
            </div>

            <br>
            <div class="rt">
                <div>
                    <label for="personnel">인원정보</label>
                    <select id="hiddenPersonnel">
                        <option value="0">어른(만13세 이상) 0명</option>
                        <option value="1" selected="selected">어른(만13세 이상) 1명</option>
                        <option value="2">어른(만13세 이상) 2명</option>
                        <option value="3">어른(만13세 이상) 3명</option>
                        <option value="4">어른(만13세 이상) 4명</option>
                        <option value="5">어른(만13세 이상) 5명</option>
                        <option value="6">어른(만13세 이상) 6명</option>
                        <option value="7">어른(만13세 이상) 7명</option>
                        <option value="8">어른(만13세 이상) 8명</option>
                        <option value="9">어른(만13세 이상) 9명</option>
                        <option value="10">어른(만13세 이상) 10명</option>
                    </select>
                    <label for="child">명</label>
                    &nbsp;&nbsp;
                    <select id="hiddenChild">
                        <option value="0" selected="selected">어린이(만6~12세) 0명</option>
                        <option value="1">어린이(만6~12세) 1명</option>
                        <option value="2">어린이(만6~12세) 2명</option>
                        <option value="3">어린이(만6~12세) 3명</option>
                        <option value="4">어린이(만6~12세) 4명</option>
                        <option value="5">어린이(만6~12세) 5명</option>
                        <option value="6">어린이(만6~12세) 6명</option>
                        <option value="7">어린이(만6~12세) 7명</option>
                        <option value="8">어린이(만6~12세) 8명</option>
                        <option value="9">어린이(만6~12세) 9명</option>
                        <option value="10">어린이(만6~12세) 10명</option>
                    </select>
                    <label for="child">명</label>
                </div>
            </div>

            <br>
            <div class="rt">
                <label id="seattype">좌석종류</label>
                <select>
                    <option value="일반" selected="selected">일반</option>
                    <option value="특실">특실</option>
                </select>
            </div>

            <br>
            <div class="rt">
                <label id="trainType">차종구분</label>
                &nbsp;
                <input class="form-check-input" type="radio" name="flexRadioDefault" id="" value="전체" checked>
                <label class="form-check-label" for="전체">전체</label>
                &nbsp;&nbsp;
				<input class="form-check-input" type="radio" name="flexRadioDefault" id="00" value="KTX">
				<label class="form-check-label" for="KTX">KTX</label>
				&nbsp;&nbsp;
                <input class="form-check-input" type="radio" name="flexRadioDefault" id="17" value="SRT">
                <label class="form-check-label" for="SRT">SRT</label>
            </div>

            <br>
            <div class="search">
                <button class="btn btn-success" onclick="fetchTicketInfo()">조회</button>
            </div>
            
			<br>
            <div id="results"></div>
            
			<br>
			<jsp:include page="sidemenu.jsp" />

		</div>			
	</div>	
		
	<a href="reservation.do">예약페이지 이동</a>

	<script>	
		//달력값 하이폰 제거후 불러오기 
		function formatDate() {
		       var dateInput = document.getElementById('Date').value;
		       if (dateInput) {
		           // 하이픈을 제거
		           var formattedDate = dateInput.replace(/-/g, '');
		           document.getElementById('formattedDate').value = formattedDate; 
		       } else {
		           document.getElementById('formattedDate').value = ''; 
		       }
		   }
		    
		   function fetchTicketInfo() {
		       var depPlaceId = document.getElementById('depplacename').value;
		       var arrPlaceId = document.getElementById('arrplacename').value;
		       var seatType = document.querySelector('select').value;
		       var formattedDate = document.getElementById('formattedDate').value;
		       var trainType = document.querySelector('input[name="flexRadioDefault"]:checked').id;
		       var start = document.getElementById('depPlaceIdHidden').value;
		       var end = document.getElementById('arrPlaceIdHidden').value;
			   // 인원 정보 가져오기
			   var personnelCount = document.getElementById('hiddenPersonnel').value;
			   var childCount = document.getElementById('hiddenChild').value;
			   var totalCount = parseInt(personnelCount) + parseInt(childCount);

		       var xhr = new XMLHttpRequest();
		       var serviceKey = 'KOyx/5iXteTdFA1wcSF1KvBTsEQcHMa8cFsrBwLTM6EGpTydPaVEtn4IjjQrwiIxqBvpc+qi4NM9izQQfHzT3w=='; // 서비스 키
		       var queryParams = '?' + encodeURIComponent('serviceKey') + '=' + encodeURIComponent(serviceKey) +
		           '&' + encodeURIComponent('pageNo') + '=' + encodeURIComponent('1') +
		           '&' + encodeURIComponent('numOfRows') + '=' + encodeURIComponent('10') +
		           '&' + encodeURIComponent('_type') + '=' + encodeURIComponent('json') +
		           '&' + encodeURIComponent('depPlaceId') + '=' + encodeURIComponent(start) +
		           '&' + encodeURIComponent('arrPlaceId') + '=' + encodeURIComponent(end) +
		           '&' + encodeURIComponent('depPlandTime') + '=' + encodeURIComponent(formattedDate) +
		           '&' + encodeURIComponent('trainGradeCode') + '=' + encodeURIComponent(trainType);

		       console.log('출발역 코드:',start);    
		       console.log('도착역 코드:',end);
			   console.log('어른 인원 수:', personnelCount);
			   console.log('아이 인원 수:',childCount);
		       console.log('출발일:',formattedDate);
		       console.log('열차 넘버:',trainType);

		       xhr.open('GET', 'https://apis.data.go.kr/1613000/TrainInfoService/getStrtpntAlocFndTrainInfo' + queryParams);
		       xhr.onreadystatechange = function () {
		           if (this.readyState == 4) {
		               if (this.status == 200) {
		                   try {
		                       var response = JSON.parse(this.responseText);
		                       var items = response.response.body.items.item || [];
		                       if (items.length > 0) {
		                           var table = '<table class="checkTrain">' +
		                               '<thead>' +
		                               '<tr>' +
		                               '<th>열차종류</th>' +
		                               '<th>열차번호</th>' +
		                               '<th>출발역</th>' +
		                               '<th>도착역</th>' +
		                               '<th>좌석종류</th>' +
		                               '<th>출발시간</th>' +
		                               '<th>도착시간</th>' +
		                               '<th>소요시간</th>' +
		                               '</tr>' +
		                               '</thead>' +
		                               '<tbody>';
		                           items.forEach(function(item) {
		                               var depTime = String(item.depplandtime); 
		                               var arrTime = String(item.arrplandtime);

		                               // 문자열을 Date 객체로 변환
		                               var startDate = new Date(
		                                   depTime.substring(0, 4), 
		                                   depTime.substring(4, 6) - 1, 
		                                   depTime.substring(6, 8),
		                                   depTime.substring(8, 10),
		                                   depTime.substring(10, 12)
		                               );
		                               var endDate = new Date(
		                                   arrTime.substring(0, 4), 
		                                   arrTime.substring(4, 6) - 1, 
		                                   arrTime.substring(6, 8),
		                                   arrTime.substring(8, 10),
		                                   arrTime.substring(10, 12)
		                               );

		                               // HH:mm 형식으로 변환
		                               var formattedTime = startDate.toTimeString().substring(0, 5);
		                               var formatted2Time = endDate.toTimeString().substring(0, 5);

		                               // 소요시간 계산
		                               var durationMinutes = Math.round((endDate - startDate) / 60000); // 밀리초를 분으로 변환
		                               var hours = Math.floor(durationMinutes / 60);
		                               var minutes = durationMinutes % 60;
		                               
		                               table += '<tr>' +
		                                   '<td>' + (item.traingradename || 'N/A') + '</td>' +
		                                   '<td>' + (item.trainno || 'N/A') + '</td>' +
		                                   '<td>' + (item.depplacename || 'N/A') + '</td>' +
		                                   '<td>' + (item.arrplacename || 'N/A') + '</td>' +
		                                   '<td><button class="seat-btn" onclick="seatTicket(\'' + seatType + '\')">좌석 선택</button></td>' +
		                                   '<td>' + formattedTime + '</td>' +
		                                   '<td>' + formatted2Time + '</td>' +
		                                   '<td>' + hours + '시간' + minutes + '분</td>' +
		                                   '</tr>';
		                           });

		                           table += '</tbody></table>';
		                           document.getElementById('results').innerHTML = table;
		                       } else {
		                           document.getElementById('results').innerText = '검색된 결과가 없습니다.';
		                       }
		                   } catch (e) {
		                       console.error('JSON 파싱 오류:', e);
		                       document.getElementById('results').innerText = '서버 응답을 처리하는 동안 오류가 발생했습니다.';
		                   }
		               } else {
		                   console.error('API 요청 실패:', this.status, this.statusText);
		                   document.getElementById('results').innerText = '서버 응답 오류: ' + this.statusText;
		               }
		           }
		       };

		       xhr.onerror = function () {
		           console.error('네트워크 오류 발생:', this.statusText);
		           document.getElementById('results').innerText = '네트워크 오류가 발생했습니다.';
		       };

		       xhr.send();
		   }

		   
		//시간 구분 
		function formatTime(timestamp) {
		    if (typeof timestamp === 'string') {
		        var hour = timestamp.substring(8, 10); 

		        var minute = timestamp.substring(10, 12); 
		        return `${hour}:${minute}`; 
		    } else {
		        console.error('Invalid timestamp:', timestamp);
		        return 'N/A';
		    }
		}

		
		//오늘 이전으로 선택되지 않도록 설정
		var now_utc = Date.now()
		var timeOff = new Date().getTimezoneOffset()*60000;
		var today = new Date(now_utc-timeOff).toISOString().split("T")[0];		
		document.getElementById("Date").setAttribute("min", today);
				
		//출발역 도착역 바꾸기 히든값도 바꾸기
		function swapStations() {
		    var arrPlace = document.getElementById('arrplacename').value;
		    var depPlace = document.getElementById('depplacename').value;
			var start = document.getElementById('depPlaceIdHidden').value;
			var end = document.getElementById('arrPlaceIdHidden').value; 
		    document.getElementById('arrplacename').value = depPlace;
	        document.getElementById('depplacename').value = arrPlace;
			document.getElementById('arrPlaceIdHidden').value = start;
			document.getElementById('depPlaceIdHidden').value = end;
		}
		
		// 역 조회
		let openWin1, openWin2;

		function openChild() {
		    window.name = "parentForm";
		    openWin1 = window.open("lookUp.do", "lookUpForm", "width=570, height=350, resizable=no, scrollbars=no");
		}

		function openChild2() {
		    window.name = "parentForm";
		    openWin2 = window.open("lookUp2.do", "lookUp2Form", "width=570, height=350, resizable=no, scrollbars=no");
		}


		function setChildValue() {
		    if (openWin1 && !openWin1.closed) {
		        openWin1.document.getElementById("cInput").value = document.getElementById("arrplacename").value;
		        updateStartValue(); 
		    } else {
		        alert("창이 닫혔거나 열리지 않았습니다.");
		    }
		}

		function setChildValue2() {
		    if (openWin2 && !openWin2.closed) {
		        openWin2.document.getElementById("ccInput").value = document.getElementById("depplacename").value;
		    } else {
		        alert("창이 닫혔거나 열리지 않았습니다.");
		    }
		}

		//좌석 조회
		let seat
		function seatTicket() {
		    window.name = "parentForm";
		    openWin3 = window.open("seat.do", "seat", "width=1000, height=850, resizable=no, scrollbars=no");
		}
		function seatTicketValue() {
		    if (seat && !seat.closed) {
		        seat.document.getElementById("seatInput").value = document.getElementById("seatname").value;
		    } else {
		        alert("창이 닫혔거나 열리지 않았습니다.");
		    }
		}
	</script>

	<jsp:include page="footer.jsp" />
</body>
</html>