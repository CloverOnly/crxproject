<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <title>Child</title>
</head>
<body>
    <br>
    <b><font size="5" color="gray">역 명</font></b>
    <br><br>
 
	<input type="button" name="stationName" class="ccInput" onclick="setParentText(this)" value="대전" data-value="NAT011668">  
	<input type="button" name="stationName" class="ccInput" onclick="setParentText(this)" value="서울" data-value="NAT010000">  
	<input type="button" name="stationName" class="ccInput" onclick="setParentText(this)" value="부산" data-value="NAT014445">  
	<input type="button" name="stationName" class="ccInput" onclick="setParentText(this)" value="강원도" data-value="NAT023456">  
	<input type="button" name="stationName" class="ccInput" onclick="setParentText(this)" value="대천" data-value="NAT034567"> 

    <br><br>
    <script>
		function setParentText(buttonElement) {
		    if (opener && !opener.closed) { // 부모 창이 열려 있는지 확인
		        var parentInput = opener.document.getElementById("arrplacename");
		        var hiddenField = opener.document.getElementById("arrPlaceIdHidden");
		        
		        if (parentInput) {
		            parentInput.value = buttonElement.getAttribute('value'); // 버튼의 value 값을 부모 창의 입력 필드에 설정
		        }
		        
		        if (hiddenField) {
		            hiddenField.value = buttonElement.getAttribute('data-value'); // 버튼의 data-value 값을 hiddenField에 설정
		        }
		        
		        console.log('Selected data-value:', buttonElement.getAttribute('data-value')); // 클릭된 버튼의 data-value를 콘솔에 출력
		        
		        window.close(); // 자식 창 닫기
		    } else {
		        alert("부모 창을 찾을 수 없습니다.");
		    }
		}
    </script>
</body>
</html>
