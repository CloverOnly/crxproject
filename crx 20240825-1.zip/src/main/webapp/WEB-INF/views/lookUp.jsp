<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <title>역 명</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	<style>
	    .tab-content {
	        margin-top: 20px; 
	    }
		.tab-content>.active {
		    margin-top: 50px;
		    display: block;
		}
		.miniT{
			text-align: center;
			margin-bottom: -6px;
			margin-top: 13px;
		}
		.cInput{
			margin: 2px;
			background: green;
			color: white;
		}
	</style>
</head>
<body>
	<div class="container">
	    <div class="row">
		<div class="col-3">
	        <div class="nav nav-pills flex-column" id="v-pills-tab" role="tablist">
				<h4 class="miniT"><strong>KTX</strong></h4>
				<hr>
	            <button class="nav-link active" id="v-pills-Gyeongbu-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Gyeongbu" type="button" role="tab" aria-controls="v-pills-Gyeongbu" aria-selected="true">경부선</button>
	            <button class="nav-link" id="v-pills-Honame-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Honame" type="button" role="tab" aria-controls="v-pills-Honame" aria-selected="false">호남선</button>
	            <button class="nav-link" id="v-pills-Gyeonjeon-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Gyeonjeon" type="button" role="tab" aria-controls="v-pills-Gyeonjeon" aria-selected="false">경전선</button>
	            <button class="nav-link" id="v-pills-Jeolla-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Jeolla" type="button" role="tab" aria-controls="v-pills-Jeolla" aria-selected="false">전라선</button>
	            <button class="nav-link" id="v-pills-Gangneung-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Gangneung" type="button" role="tab" aria-controls="v-pills-Gangneung" aria-selected="true">강릉선</button>
	            <button class="nav-link" id="v-pills-jungang-tab" data-bs-toggle="pill" data-bs-target="#v-pills-jungang" type="button" role="tab" aria-controls="v-pills-jungang" aria-selected="false">중앙선</button>
	            <button class="nav-link" id="v-pills-Jungbunaeryuk-tab" data-bs-toggle="pill" data-bs-target="#v-pills-Jungbunaeryuk" type="button" role="tab" aria-controls="v-pills-Jungbunaeryuk" aria-selected="false">중부내륙선</button>
	        </div>
		</div>
		
		<div class="col-9">	
	    	<div class="tab-content" id="v-pills-tabContent">
	  			<div class="tab-pane fade show active" id="v-pills-Gyeongbu" role="tabpanel" aria-labelledby="v-pills-Gyeongbu-tab" tabindex="0">
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="행신역" data-value="NAT110147">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서울역" data-value="NAT010000">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="영등포역" data-value="NAT010091">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="광명역" data-value="NATH10219">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="수원역" data-value="NAT010415">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="대전역" data-value="NAT011668">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="김천역" data-value="NAT012546">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="동대구역" data-value="NAT013271">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서대구역" data-value="NAT013189">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="밀양역" data-value="NAT013841">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="포항역" data-value="NAT8B0351">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="경주역" data-value="NAT023821">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="울산역" data-value="NATH13717">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="구포역" data-value="NAT014281">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="부산역" data-value="NAT014445">
				</div>
			    <div class="tab-pane fade" id="v-pills-Honame" role="tabpanel" aria-labelledby="v-pills-Honame-tab" tabindex="0">
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="행신역" data-value="NAT110147">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="용산역" data-value="NAT010032">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="광명역" data-value="NATH10219">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="공주역" data-value="NATH20438">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서대전역" data-value="NAT030057">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="논산역" data-value="NAT030508">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="계룡역" data-value="NAT030254">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="익산역" data-value="NAT030879">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="정읍역" data-value="NAT031314">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="광주송정역" data-value="NAT031857">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="나주역" data-value="NAT031998">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="목포역" data-value="NAT032563">
		
				</div>
			    <div class="tab-pane fade" id="v-pills-Gyeonjeon" role="tabpanel" aria-labelledby="v-pills-Gyeonjeon-tab" tabindex="0">
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="행신역" data-value="NAT110147">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서울역" data-value="NAT010000">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="광명역" data-value="NATH10219">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="대전역" data-value="NAT011668">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="김천역" data-value="NAT012546">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="동대구역" data-value="NAT013271">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서대구역" data-value="NAT013189">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="밀양역" data-value="NAT013841">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="진영역" data-value="NAT880177">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="창원중앙역" data-value="NAT880281">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="창원역" data-value="NAT880310">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="마산역" data-value="NAT880345">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="진주역" data-value="NAT881014">
		
				</div>
			    <div class="tab-pane fade" id="v-pills-Jeolla" role="tabpanel" aria-labelledby="v-pills-Jeolla-tab" tabindex="0">
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="행신역" data-value="NAT110147">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="용산역" data-value="NAT010032">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="광명역" data-value="NATH10219">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="공주역" data-value="NATH20438">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="논산역" data-value="NAT030508">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서대전역" data-value="NAT030057">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="계룡역" data-value="NAT030254">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="익산역" data-value="NAT030879">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="전주역" data-value="NAT040257">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="남원역" data-value="NAT040868">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="곡성역" data-value="NAT041072">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="구례구역" data-value="NAT041285">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="순천역" data-value="NAT041595">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="여천역" data-value="NAT041866">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="여수엑스포역" data-value="NAT041993">
				</div>
				<div class="tab-pane fade" id="v-pills-Gangneung" role="tabpanel" aria-labelledby="v-pills-Gangneung-tab" tabindex="0">
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="행신역" data-value="NAT110147">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서울역" data-value="NAT010000">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="덕소역" data-value="NAT020178">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="청량리역" data-value="NAT130126">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="양평역" data-value="NAT020524">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="상봉역" data-value="NAT020040">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="진부역" data-value="NATN10787">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="횡성역" data-value="NATN10230">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="만종역" data-value="NAT021033">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="둔내역" data-value="NATN10428">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="평창역" data-value="NATN10625">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="강릉역" data-value="NAT601936">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="정동진역" data-value="NAT601774">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="묵호역" data-value="NAT601545">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="동해역" data-value="NAT601485">
		
				</div>
				<div class="tab-pane fade" id="v-pills-jungang" role="tabpanel" aria-labelledby="v-pills-jungang-tab" tabindex="0">
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서울역" data-value="NAT010000">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="청량리역" data-value="NAT130126">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="양평역" data-value="NAT020524">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서원주역" data-value="NAT020864">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="원주역" data-value="NAT020947">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="제천역" data-value="NAT021549">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="단양역" data-value="NAT021784">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="풍기역" data-value="NAT022053">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="영주역" data-value="NAT022053">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="안동역" data-value="NAT022558">
		
				</div>
				<div class="tab-pane fade" id="v-pills-Jungbunaeryuk" role="tabpanel" aria-labelledby="v-pills-Jungbunaeryuk-tab" tabindex="0">
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="판교역" data-value="NAT250007">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="부발역" data-value="NAT250428">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="가남역" data-value="NAT280090">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="감곡장호원역" data-value="NAT280212">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="앙성온천역" data-value="NAT280358">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="충주역" data-value="NAT050827">
				</div>
	  		</div>
		</div>
		</div>	
	</div>

    <script>
        function setParentText(buttonElement) {
            if (opener && !opener.closed) { // 부모 창이 열려 있는지 확인
                var parentInput = opener.document.getElementById("depplacename");
                var hiddenField = opener.document.getElementById("depPlaceIdHidden");
                
                if (parentInput) {
                    parentInput.value = buttonElement.getAttribute('value'); // 버튼의 value 값을 부모 창의 입력 필드에 설정
                }
                
                if (hiddenField) {
                    hiddenField.value = buttonElement.getAttribute('data-value'); // 버튼의 data-value 값을 hiddenField에 설정
                }
                
                console.log('Selected data-value:', buttonElement.getAttribute('data-value')); // 클릭된 버튼의 data-value를 콘솔에 출력
                
                window.close(); // 자식 창 닫기
            } else {
                alert("부모 창을 찾을 수 없습니다.");
            }
        }
    </script>
</body>
</html>
