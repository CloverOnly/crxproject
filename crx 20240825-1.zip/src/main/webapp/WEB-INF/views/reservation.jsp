<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <title>예약</title>
    <style>
        .all {
            width: 1200px;    
            margin: 0 auto; /* 중앙 정렬 */
        }
        .tiline {
            display: inline;
            border: solid 1px green;
            border-radius: 8px;
            padding: 5px;
            color: green;
            margin: 5px;
        }
        .guide {
            width: 1200px;
            height: auto;
            background-color: #f8f8f8;
            margin: 2px;
            padding: 5px;
            font-size: 12px;
        }
        .guidep {
            margin-bottom: 3px;
        }
        .payment {
            text-align: center;
        }    
    </style>
    <script>
        // 페이지 로드 시 콘솔 로그를 출력
        window.addEventListener('load', function() {
            // JSP에서 서버 측 변수를 자바스크립트 변수로 설정
            var startname = '${param.startname}';
            var endname = '${param.endname}';
            var seatType = '${param.seatType}';
            var trainType = '${param.trainType}';
            var personnelCount = parseInt('${param.personnelCount}', 10) || 0;
            var childCount = parseInt('${param.childCount}', 10) || 0;
            var trainno = '${param.trainno}';
            var depTime = '${param.depTime}';
            var arrTime = '${param.arrTime}';
            var duration = '${param.duration}';
            var totalAdultCharge = parseFloat('${param.totalAdultCharge}') || 0;
            var totalChildCharge = parseFloat('${param.totalChildCharge}') || 0;
            var endCharge = parseFloat('${param.endCharge}') || 0;
            var totalCharge = parseFloat('${param.totalCharge}') || 0;
            var totalDiscount = parseFloat('${param.totalDiscount}') || 0;

            console.log('출발역:', startname);
            console.log('도착역:', endname);
            console.log('좌석타입:', seatType);
            console.log('열차종류:', trainType);
            console.log('성인인원:', personnelCount);
            console.log('아동인원:', childCount);
            console.log('열차번호:', trainno);
            console.log('출발시간:', depTime);
            console.log('도착시간:', arrTime);
            console.log('소요시간:', duration);
            console.log('성인요금:', totalAdultCharge);
            console.log('아동요금:', totalChildCharge);
            console.log('최종요금:', endCharge);
            console.log('총요금:', totalCharge);
            console.log('총할인요금:', totalDiscount);

            // 폼에 값을 설정
            document.getElementById('startname').value = startname;
            document.getElementById('endname').value = endname;
            document.getElementById('seatType').value = seatType;
            document.getElementById('startdate').value = '${param.startdate}';
            document.getElementById('trainType').value = trainType;
            document.getElementById('personnelCount').value = personnelCount;
            document.getElementById('childCount').value = childCount;
            document.getElementById('trainno').value = trainno;
            document.getElementById('depTime').value = depTime;
            document.getElementById('arrTime').value = arrTime;
            document.getElementById('duration').value = duration;
            document.getElementById('selectedSeats').value = '${param.selectedSeats}';
            document.getElementById('hocha').value = '${param.hocha}';
            document.getElementById('totalAdultCharge').value = totalAdultCharge;
            document.getElementById('totalChildCharge').value = totalChildCharge;
            document.getElementById('endCharge').value = endCharge;
            document.getElementById('totalCharge').value = totalCharge;
            document.getElementById('totalDiscount').value = totalDiscount;
            document.getElementById('userid').value = '${param.userid}';
        });

        // 폼 제출 함수
        function reservationForm() {
            document.getElementById('seatForm').submit();
        }
		
		function tBack() {
		    // 페이지를 ticket.do로 이동
		    window.location.href = '${contextPath}/ticket.do';
		}
    </script>
</head>
<body>
    <jsp:include page="header.jsp" />
    <div class="all">    
        <div class="maintitle">
            <h1>예약</h1>
            <hr>
        </div>
            
        <br>
        <div style="text-align:center;">
            <img src="../img/mark2.gif" style="width:500px">
        </div>
        
        <br>
        <div class="guide">
            <p class="guidep">10분 내에 결제하지 않으면 취소됩니다.</p>
            <p class="guidep">내용</p>
            <p class="guidep">내용</p>
        </div>
        
        <br>
        <div>
            <table class="table">
                <thead class="table-success">
                    <tr>
                        <th>승차일자</th>
                        <th>열차종류</th>
                        <th>열차번호</th>
                        <th>출발역</th>
                        <th>도착역</th>
                        <th>출발시간</th>
                        <th>도착시간</th>
                        <th>인원</th>
                        <th>결제금액</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>${param.startdate}</td>
                        <td>${param.trainType}</td>
                        <td>${param.trainno}</td>
                        <td>${param.startname}</td>
                        <td>${param.endname}</td>
                        <td>${param.depTime}</td>
                        <td>${param.arrTime}</td>
                        <td>${param.personnelCount + param.childCount}</td>
                        <td>${param.endCharge}원</td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <br>
        <div>
            <table class="table">
                <thead class="table-success">
                    <tr>
                        <th>열차번호</th>
                        <th>객실등급</th>
                        <th>좌석정보</th>    
                        <th>운임요금</th>
                        <th>할인금액</th>
                        <th>영수금액</th>
                    </tr>    
                </thead>
                <tbody>
                    <tr>
                        <td>${param.trainno}</td>
                        <td>${param.seatType}</td>
                        <td>${param.selectedSeats}</td>                
                        <td>${param.totalCharge}원</td>
                        <td>${param.totalDiscount}원</td>
                        <td>${param.endCharge}원</td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <br>
        <div class="guide">
            <p class="guidep">내용내용내용내용내용내용내용내용내용내용내용내용</p>
            <p class="guidep">내용내용내용내용내용내용내용내용내용내용내용내용</p>
            <p class="guidep">내용내용내용내용내용내용내용내용내용내용내용내용</p>
        </div>
        
        <br><br><br>
        <div class="payment">
			<form id="reservationForm" action="${pageContext.request.contextPath}/reservation.do" method="post">
                <input type="hidden" id="startname" name="startname" />
                <input type="hidden" id="endname" name="endname" />
                <input type="hidden" id="seatType" name="seatType" />
                <input type="hidden" id="startdate" name="startdate" />
                <input type="hidden" id="trainType" name="trainType" />
                <input type="hidden" id="personnelCount" name="personnelCount" />
                <input type="hidden" id="childCount" name="childCount" />
                <input type="hidden" id="trainno" name="trainno" />
                <input type="hidden" id="depTime" name="depTime" />
                <input type="hidden" id="arrTime" name="arrTime" />
                <input type="hidden" id="duration" name="duration" />
                <input type="hidden" id="selectedSeats" name="selectedSeats" />
                <input type="hidden" id="hocha" name="hocha" />
                <input type="hidden" id="totalAdultCharge" name="totalAdultCharge" />
                <input type="hidden" id="totalChildCharge" name="totalChildCharge" />
                <input type="hidden" id="endCharge" name="endCharge" />
                <input type="hidden" id="totalCharge" name="totalCharge" />
                <input type="hidden" id="totalDiscount" name="totalDiscount" />
                <input type="hidden" id="userid" name="userid" />
                
                <!-- 버튼 클릭 시 폼을 제출합니다 -->
                <input type="submit" id="seatReservation" value="결제하기">
            </form>
            <button type="button" class="btn btn-success" onclick="tBack()">되돌아가기</button>
        </div>    
    </div>

    <jsp:include page="sidemenu.jsp" />
    <jsp:include page="footer.jsp" />
</body>
</html>
