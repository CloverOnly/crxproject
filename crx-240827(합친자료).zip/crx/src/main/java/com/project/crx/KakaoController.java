package com.project.crx;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;

@Controller
public class KakaoController {

	@Autowired
	private KakaoService kakaoService;

	@Autowired
	private UserService userService;

	@GetMapping("kakaoTerms")
	public String kakaoConnect() {
		StringBuffer url = new StringBuffer();
		url.append("https://kauth.kakao.com/oauth/authorize?");
		url.append("client_id=b40dbabe21f0e38eb1ca7cc8451a819c"); // 실제 클라이언트 아이디로 변경
		url.append("&redirect_uri=http://localhost:8080/kakaologin.do"); // 리디렉션 URI 설정
		url.append("&response_type=code");
		url.append("&prompt=login");

		return "redirect:" + url.toString();
	}

	@RequestMapping(value = "/kakaologin.do")
	public String kakaoLogin(@RequestParam("code") String code, Model model, HttpSession session) throws Exception {
		String accessToken = kakaoService.getToken(code);
		ArrayList<Object> list = kakaoService.getUserInfo(accessToken);

		String usermail = (String) list.get(1);
		String username = (String) list.get(2);

		session.setAttribute("usermail", usermail);
		session.setAttribute("username", username);
		session.setAttribute("isLogOn", true);

		User user = userService.findByUsermail(usermail);
		if (user != null) {
			session.setAttribute("userid", user.getUserid());

			// 세션에 level과 status 저장
			session.setAttribute("level", user.getLevel());
			session.setAttribute("status", user.getStatus());

			if (user.getUserpwd() == null || user.getUserpwd().trim().isEmpty()) {
				return "kakaologin";
			} else {
				return "main";
			}
		}
		return "redirect:/";
	}

	@RequestMapping("/setPassword.do")
	public String setPassword(@RequestParam("password") String password, @RequestParam("usermail") String usermail,
			@RequestParam("level") String level, @RequestParam("status") String status, HttpSession session) { // HttpSession
																												// 객체 추가
		if (usermail != null && password != null && !password.isEmpty()) {
			User user = userService.findByUsermail(usermail);
			if (user != null) {
				user.setUserpwd(password);
				user.setLevel(level); // 'user'로 설정
				user.setStatus(status); // 'kakao'로 설정

				userService.updatePwdByMail(user);

				// 세션에 사용자 정보 저장
				session.setAttribute("usermail", usermail);
				session.setAttribute("level", level);
				session.setAttribute("status", status);

			} else {
				System.out.println("사용자를 찾을 수 없습니다: " + usermail);
			}
		} else {
			System.out.println("비밀번호 또는 이메일이 유효하지 않습니다.");
		}

		return "main"; // 비밀번호 설정 후 메인 페이지로 리디렉션
	}

}