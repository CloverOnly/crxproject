package com.project.crx.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.project.crx.vo.TicketVO;

@Mapper
public interface TicketDAO {
    void insertSeat(TicketVO seat) throws Exception;
	List<TicketVO> getReservation();
	List<TicketVO> getPayment();
	void insertPayment(TicketVO payment);
	List<TicketVO> getTicketing(int applyNum);	
}

