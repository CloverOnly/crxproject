package com.project.crx.service;

import java.util.List;

import com.project.crx.vo.TicketVO;

public interface TicketService {
    void saveSeat(TicketVO seat) throws Exception;
    List<TicketVO> getReservation();
	List<TicketVO> getPayment();
	boolean savePayment(TicketVO payment);
	List<TicketVO> getTicketing(int applyNum);
}
