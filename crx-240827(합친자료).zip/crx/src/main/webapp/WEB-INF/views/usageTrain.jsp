<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<title>이용내역</title>
<style>
	.all{
		width: 1200px;
		margin: 0 auto;  <!-- 중앙 정렬 -->
	}
	.rt{
		margin: 3px;
	}	
	.search{
		text-align: center;
	}
	.minititle a{
		color: #000000;
	}
	.guide{
		width: 1200px;
		height: auto;
		background-color: #f8f8f8;
		margin: 2px;
		padding: 5px;
		font-size: 12px;
	}
	.guidep{
		margin-bottom: 3px;
	}
	table, .th, .td {
		border: 2px solid white;
	    border-collapse: collapse;
	}
	 ud table, .th{
		background-color: #2e7d32;
		width: 100px;
		height: 70px;
	}
	 ud table, .td{
		background-color: #a5d6a7;
		width: 1100px;
		height: 70px;
	}
	
</style>
<script>
	function changePage() {
		const selectedOption = document.querySelector('input[name="reservationType"]:checked').value;
		if (selectedOption === 'train') {
			location.href = 'usageTrain.do?userid=${userid}';
		} else if (selectedOption === 'tour') {
			location.href = 'usageTour.do?userid=${userid}';
		}
	}
</script>
</head>
<body>	 
	<jsp:include page="header.jsp" />
	<div class="all">
		<div class="maintitle">
			<h1>이용내역</h1>
			<hr>
		</div>
		<br>  
		<div>
			<br>
			<ul class="nav nav-tabs">
				<li class="minititle nav-item">
					<a class="nav-link" href="mgmtTrain.do?userid=${userid}">예매관리</a>
				</li>
				<li class="minititle nav-item">
					<a class="nav-link active bg-light" aria-current="page" href="usageDetails.do?userid=${userid}">이용내역</a>
				</li>
			</ul>
		</div>
		
		<!-- 설명 -->
		<div class="guide">
			<br>
			<h5 style="text-align: center;">${username} 고객님의 발권 및 환불 내역을 확인하실 수 있습니다.</h5>
			<br>
		</div>
		<br>

		<!-- 라디오 버튼 추가 -->
		<div class="text-center">
			<label>
				<input type="radio" name="reservationType" value="train" checked onchange="changePage()">기차예매 조회
			</label>
			&nbsp;
			&nbsp;
			<label>
				<input type="radio" name="reservationType" value="tour" onchange="changePage()">관광상품 조회
			</label>
		</div>
		<br>
		
		<!-- 테이블 -->
		<form action="${contextPath}/trainSearch" method="get">
		    <input type="hidden" name="userid" value="${userid}" />
		    <table class="ud">        
		        <th class="th" style="text-align: center; color: white">승차 일자</th>
		        <td class="td" style="text-align: center;">
		            <input type="date" name="startDate" required> ~ 
		            <input type="date" name="endDate" required>
					&nbsp;
					<button type="submit" class="btn btn-success">조회</button>			
		        </td>                 
		    </table>
		</form>
		<c:if test="${not empty trainSearch}">
		    <table class="table ">
		        <thead class="table-success">
					<tr>
					    <th scope="col" style="text-align: center;">승차시간</th>
					    <th scope="col" style="text-align: center;">출발역</th>
					    <th scope="col" style="text-align: center;">도착역</th>
					    <th scope="col" style="text-align: center;">예약인원</th>
					    <th scope="col" style="text-align: center;">결제금액</th>
					    <th scope="col" style="text-align: center;">결제번호</th>
					    <th scope="col" style="text-align: center;">환불상태</th>
					</tr>
		        </thead>
		        <tbody>
		            <c:forEach var="train" items="${trainSearch}">
						<tr>
						    <td style="text-align: center;">${train.startdate}<br>${train.depTime}</td>
						    <td style="text-align: center;">${train.startname}</td>
						    <td style="text-align: center;">${train.endname}</td>
						    <td style="text-align: center;">성인:${train.personnelCount}<br>아동:${train.childCount}</td>
						    <td style="text-align: center;">${train.endCharge}</td>
						    <td style="text-align: center;">${train.apply_num}</td>
						    <td style="text-align: center;">
						        <c:choose>
						            <c:when test="${train.refund == null}">						                
						            </c:when>
						            <c:otherwise>
						                환불완료
						            </c:otherwise>
						        </c:choose>								
							</th>
		                </tr>
		            </c:forEach>
		        </tbody>
		    </table>
		</c:if>
		<c:if test="${empty trainSearch}">
		    <p>조회된 이용내역이 없습니다.</p>
		</c:if>
	</div>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<jsp:include page="sidemenu.jsp" />
	<jsp:include page="footer.jsp" />
</body>
</html>