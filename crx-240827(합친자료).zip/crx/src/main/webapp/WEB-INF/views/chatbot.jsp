<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>
<title>챗봇</title>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sockjs-client/1.4.0/sockjs.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/stomp.js/2.3.3/stomp.min.js"></script>
<link href="../css/chatbot.css" rel="stylesheet">
<script src="../js/chatbot.js"></script>

</head>
<body>
    <div id="username-page">
        <div>
            <i class="fas fa-robot chatbot-icon"></i>
            <input type="text" id="name" placeholder="이름을 입력해주세요"/>
            <button onclick="connect()">챗봇 연결</button>
        </div>
    </div>
    <div id="chat-page" style="display:none;">
        <div id="chat">
            <ul id="messageArea"></ul>
        </div>
        <input type="text" id="message" placeholder="메시지를 입력해주세요."/>
        <button onclick="sendMessage()">전송</button>        
    </div>
	
    <div class="title">
        <img src="../img/logo.gif" style="width:60px"><p>챗봇</p>
		<button onclick="handleConsultationRequest()" class="counselor">상담사<br>요청</button>
    </div>
</body>
</html>
