<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn"%>

<!DOCTYPE html>
<html>
<head>
<title>장바구니</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<link href="../css/cart.css" rel="stylesheet">
<script src="../js/cart.js"></script>

</head>
<body>
<jsp:include page="header.jsp" />
<jsp:include page="sidemenu.jsp" />
<div class="cart">
    <h1 style="text-align:center;">장바구니</h1>
    <div class="carttitle">
        
    <!-- 기차표 예매 폼 -->
    <h3>기차예매</h3>        
	<form id="trainForm" action="trainDelete" method="post" onsubmit="return validatetrainForm();">
	    <input type="hidden" name="userid" id="userid" value="${userid}">
	    <table class="tourcart">
	        <thead>
	            <tr>
	                <td>예매내역</td>
	                <td style="width:20%">예매날짜</td>
	                <td style="width:12%">금액</td>
	                <td style="width:10%">선택</td>
	            </tr>
	        </thead>
	        <tbody>
	            <c:forEach var="trainList" items="${trainList}" varStatus="status">
	            <tr>
	                <td>
	                    <h4 class="trainlist">${trainList.trainType}</h4>
	                    <small class="trainlist">출발시간 : ${trainList.startdate} ${trainList.depTime}  출발지 : ${trainList.startname}</small>
	                    <small class="trainlist">도착시간 : ${trainList.startdate} ${trainList.arrTime}  도착지 : ${trainList.endname}</small>
	                    <small class="trainlist">열차번호 : ${trainList.trainno}</small>
						<small class="trainlist">좌석번호 : ${trainList.selectedSeats}</small>
	                    <small class="trainlist">성인 : ${trainList.personnelCount}명</small>
	                    <small class="trainlist">아동 : ${trainList.childCount}명</small>	                  
	                    <input type="hidden" name="reservno" value="${trainList.reservno}">
	                </td>
	                <td>${trainList.startdate}</td>
	                <td><script>document.write(Number(${trainList.endCharge}).toLocaleString('ko-KR'));</script>원</td>
	                <td>
	                    <input type="checkbox" name="selectTrain" value="${trainList.reservno}" class="trainCheckbox" data-price="${trainList.endCharge}">
	                </td>
	            </tr>
	            </c:forEach>
	        </tbody>    
	    </table>
	    <p>총 금액 : <span id="trainTotalAmount">0</span>원</p>
	    <div class="cartbutton">
			<button class="btn btn-success" id="trainCheckoutButton" type="button">결제하기</button>                
			<button class="btn btn-secondary" type="submit">선택삭제</button>
	    </div>
	</form> 

    
    <!-- 관광상품 예매 폼 -->
    <h3>관광상품 예매</h3>        
    <form id="tourForm" action="tourDelete" method="post" onsubmit="return validatetourForm();">
       <input type="hidden" name="userid" id="userid" value="${userid}">
        <table class="tourcart">
            <thead>
                <tr>
                    <td>예매내역</td>
                    <td style="width:20%">예매날짜</td>
                    <td style="width:12%">금액</td>
                    <td style="width:10%">선택</td>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="tourcart" items="${cartList}" varStatus="status">
                <tr>
                    <td>
                        <h4 class="tourlist">${tourcart.tourtitle}</h4>
                        <small class="tourlist">상품번호 : ${tourcart.tourno}</small>
                        <small class="tourlist">상품명 : ${tourcart.tourname}</small>
                        <small class="tourlist">예약인원 : ${tourcart.tourcount}명</small>
                        <input type="hidden" name="reservno" value="${tourcart.reservno}">
                    </td>
                    <td>${tourcart.tourdate}</td>
                    <td><script>document.write(Number(${tourcart.totalcoin}).toLocaleString('ko-KR'));</script>원</td>
                    <td>
						<input type="checkbox" name="selectTour" value="${tourcart.reservno}" class="tourCheckbox" data-price="${tourcart.totalcoin}">
                    </td>
                </tr>
                </c:forEach>
            </tbody>    
        </table>
        <p>총 금액 : <span id="tourTotalAmount">0</span>원</p>
        <div class="cartbutton">
            <button class="btn btn-success" id="tourCheckoutButton" type="button">결제하기</button>                
            <button class="btn btn-secondary" type="submit">선택삭제</button>
        </div>
    </form>      
    </div>
</div>
<jsp:include page="footer.jsp" />
</body>
</html>