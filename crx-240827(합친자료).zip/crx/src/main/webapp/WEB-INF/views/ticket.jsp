<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
    Integer userid = (Integer) session.getAttribute("userid");

    // main.jsp에서 전달된 폼 데이터를 받습니다.
	String depplacename = request.getParameter("depplacename") != null ? request.getParameter("depplacename") : "";
	String depPlaceId = request.getParameter("depPlaceId") != null ? request.getParameter("depPlaceId") : "";
	String arrplacename = request.getParameter("arrplacename") != null ? request.getParameter("arrplacename") : "";
	String arrPlaceId = request.getParameter("arrPlaceId") != null ? request.getParameter("arrPlaceId") : "";
	String startdate = request.getParameter("startdate") != null ? request.getParameter("startdate") : "";
	String starttime = request.getParameter("starttime") != null ? request.getParameter("starttime") : "";
	String adultcount = request.getParameter("adultcount") != null ? request.getParameter("adultcount") : "1";
	String childcount = request.getParameter("childcount") != null ? request.getParameter("childcount") : "0";
	String trainType = request.getParameter("trainType") != null ? request.getParameter("trainType") : "";
	String seatType = request.getParameter("seatType") != null ? request.getParameter("seatType") : "일반";
%>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>일반승차권 예매</title>
    <style>
        .all {
            width: 1200px;
            margin: 0 auto; /* 중앙 정렬 */
        }
        .tiline {
            display: inline;
            border: solid 1px green;
            border-radius: 8px;
            padding: 5px;
            color: green;
            margin: 5px;
        }
        .mid {
            height: 300px;
            background: #f8f8f8;
            padding: 5px;
        }

        .rt {
            margin: 3px;
        }
        .search {
            text-align: center;
        }
        .minititle a {
            color: #000000;
        }
        table, th, td {
            border: 2px solid white;
            border-collapse: collapse;
        }
        #Date {
            width: 140px;
            display: inline;
        }
        .checkTrain {
            border: 2px solid white;
            border-collapse: collapse;
            width: 100%;
        }
        #swapIcon {
            font-size: 20px;
            cursor: pointer; /* 클릭 가능성 추가 */
        }
        #depplacename{
            background: white;
            color: black;
        }
        #arrplacename{
            background: white;
            color: black;
        }
        .seat-btn{
            font-size: 12px;
            background: green;
			color: white;
        }
        .checkTrain {
            width: 100%;
            border-collapse: collapse;
        }
        .checkTrain th, .checkTrain td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        .checkTrain th {
            background-color: #f2f2f2;
            color: black;
        }
        .checkTrain tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .checkTrain tr:hover {
            background-color: #ddd;
        }
        /* .page-link 클래스를 재정의하여 색상을 녹색으로 변경 */
        .pagination .page-link {
            color: green;
        }

        /* 활성화된 페이지의 링크 색상도 변경 */
        .pagination .page-item.active .page-link {
            background-color: green;
            border-color: green;
            color: white; /* 텍스트 색상을 흰색으로 변경 */
        }

        /* 마우스 오버 시 링크 색상 변경 */
        .pagination .page-link:hover {
            color: darkgreen;
        }

    </style>
</head>
<body>
    <jsp:include page="header.jsp" />
    <div class="all">
        <div class="maintitle">
            <h1>일반승차권</h1>
            <hr>
        </div>

        <br>
        <div style="text-align:center;">
            <img src="../img/mark1.gif" style="width:500px">
        </div>

        <br>
<!--        <div>-->
<!--            <br>-->
<!--            <ul class="nav nav-tabs">-->
<!--                <li class="minititle nav-item">-->
<!--                    <a class="nav-link active bg-light" aria-current="page" href="ticket.do">일반승차권 조회</a>-->
<!--                </li>-->
<!--                <li class="minititle nav-item">-->
<!--                    <a class="nav-link" href="groupTicket.do">단체승차권 조회</a>-->
<!--                </li>-->
<!--            </ul>-->
<!--        </div>-->
        <div class="mid">           
            <br>
            <div class="rt">
                <label id="trainType">열차구분</label>
                &nbsp;
				<input class="form-check-input" type="radio" name="trainType" id="00" value="KTX" <%= "KTX".equals(trainType) ? "checked" : "" %>>
				<label class="form-check-label" for="KTX">KTX</label>
				&nbsp;&nbsp;
                <input class="form-check-input" type="radio" name="trainType" id="17" value="SRT" <%= "SRT".equals(trainType) ? "checked" : "" %>>
                <label class="form-check-label" for="SRT">SRT</label>
            </div>

            <br>
            <div class="rt" id="ktxStation">
                <label for="depplacename">출발역</label>
                <input id="depplacename" name="depplacename" type="text" class="inp200" title="출발역" value="<%= depplacename %>" readonly>
                <input type="hidden" id="depPlaceIdHidden" name="depPlaceId" value="<%= depPlaceId %>">
                <input type="button" value="조회" onclick="openChild('dep')">
                &nbsp;&nbsp;
                <i id="swapIcon" class="bi bi-arrow-repeat" onclick="swapStations()"></i>
                &nbsp;&nbsp;
                <label for="arrplacename">도착역</label>
                <input id="arrplacename" name="arrplacename" type="text" class="inp200" title="도착역" value="<%= arrplacename %>" readonly>
                <input type="hidden" id="arrPlaceIdHidden" name="arrPlaceId" value="<%= arrPlaceId %>">
                <input type="button" value="조회" onclick="openChild('arr')">
            </div>

            <br>
            <div class="rt" id="arrplandtime">
                <label for="Date">출발일</label>
                <input type="date" id="Date" name="startdate" value="<%= startdate != "null" ? startdate : "" %>" onchange="formatDate()">
                <input type="hidden" id="formattedDate" value="<%= startdate != null ? startdate.replaceAll("-", "") : "" %>">
            
                &nbsp;&nbsp;
                <label for="timeSelect">시간</label>
                <select id="timeSelect" name="starttime">
                    <option value="00" <%= "000000".equals(starttime) ? "selected" : "" %>>00:00</option>
                    <option value="01" <%= "010000".equals(starttime) ? "selected" : "" %>>01:00</option>
                    <option value="02" <%= "020000".equals(starttime) ? "selected" : "" %>>02:00</option>
					<option value="03" <%= "030000".equals(starttime) ? "selected" : "" %>>03:00</option>
                    <option value="04" <%= "040000".equals(starttime) ? "selected" : "" %>>04:00</option>
                    <option value="05" <%= "050000".equals(starttime) ? "selected" : "" %>>05:00</option>
					<option value="06" <%= "060000".equals(starttime) ? "selected" : "" %>>06:00</option>
                    <option value="07" <%= "070000".equals(starttime) ? "selected" : "" %>>07:00</option>
                    <option value="08" <%= "080000".equals(starttime) ? "selected" : "" %>>08:00</option>
					<option value="09" <%= "090000".equals(starttime) ? "selected" : "" %>>09:00</option>
                    <option value="10" <%= "100000".equals(starttime) ? "selected" : "" %>>10:00</option>
                    <option value="11" <%= "110000".equals(starttime) ? "selected" : "" %>>11:00</option>
					<option value="12" <%= "120000".equals(starttime) ? "selected" : "" %>>12:00</option>
                    <option value="13" <%= "130000".equals(starttime) ? "selected" : "" %>>13:00</option>
                    <option value="14" <%= "140000".equals(starttime) ? "selected" : "" %>>14:00</option>
					<option value="15" <%= "150000".equals(starttime) ? "selected" : "" %>>15:00</option>
                    <option value="16" <%= "160000".equals(starttime) ? "selected" : "" %>>16:00</option>
                    <option value="17" <%= "170000".equals(starttime) ? "selected" : "" %>>17:00</option>
					<option value="18" <%= "180000".equals(starttime) ? "selected" : "" %>>18:00</option>
                    <option value="19" <%= "190000".equals(starttime) ? "selected" : "" %>>19:00</option>
                    <option value="20" <%= "200000".equals(starttime) ? "selected" : "" %>>20:00</option>
					<option value="21" <%= "210000".equals(starttime) ? "selected" : "" %>>21:00</option>
                    <option value="22" <%= "220000".equals(starttime) ? "selected" : "" %>>22:00</option>
                    <option value="23" <%= "230000".equals(starttime) ? "selected" : "" %>>23:00</option>
					<option value="24" <%= "240000".equals(starttime) ? "selected" : "" %>>24:00</option>
                </select>
                <label id="listtime">시</label>
            </div>

            <br>
            <div class="rt">
                <div>
					<label for="adultcount">어른(만 13세 이상)</label>
					<select id="adultcount" name="adultcount">
					    <option value="0" <%= "0".equals(adultcount) ? "selected" : "" %>>어른 0명</option>
					    <option value="1" <%= "1".equals(adultcount) ? "selected" : "" %>>어른 1명</option>
					    <option value="2" <%= "2".equals(adultcount) ? "selected" : "" %>>어른 2명</option>
					    <option value="3" <%= "3".equals(adultcount) ? "selected" : "" %>>어른 3명</option>
						<option value="4" <%= "4".equals(adultcount) ? "selected" : "" %>>어른 4명</option>
					    <option value="5" <%= "5".equals(adultcount) ? "selected" : "" %>>어른 5명</option>
					    <option value="6" <%= "6".equals(adultcount) ? "selected" : "" %>>어른 6명</option>
					    <option value="7" <%= "7".equals(adultcount) ? "selected" : "" %>>어른 7명</option>
						<option value="8" <%= "8".equals(adultcount) ? "selected" : "" %>>어른 8명</option>
						<option value="9" <%= "9".equals(adultcount) ? "selected" : "" %>>어른 9명</option>
						<option value="10" <%= "10".equals(adultcount) ? "selected" : "" %>>어른 10명</option>
					</select>
					&nbsp;&nbsp;
					
                    <label for="childcount">어린이(만 6~12세)</label>                    
                    <select id="childcount" name="childcount">
                        <option value="0" <%= "0".equals(childcount) ? "selected" : "" %>>어린이 0명</option>
                        <option value="1" <%= "1".equals(childcount) ? "selected" : "" %>>어린이 1명</option>
                        <option value="2" <%= "2".equals(childcount) ? "selected" : "" %>>어린이 2명</option>
						<option value="3" <%= "3".equals(childcount) ? "selected" : "" %>>어린이 3명</option>
                        <option value="4" <%= "4".equals(childcount) ? "selected" : "" %>>어린이 4명</option>
                        <option value="5" <%= "5".equals(childcount) ? "selected" : "" %>>어린이 5명</option>
						<option value="6" <%= "6".equals(childcount) ? "selected" : "" %>>어린이 6명</option>
                        <option value="7" <%= "7".equals(childcount) ? "selected" : "" %>>어린이 7명</option>
                        <option value="8" <%= "8".equals(childcount) ? "selected" : "" %>>어린이 8명</option>
						<option value="9" <%= "9".equals(childcount) ? "selected" : "" %>>어린이 9명</option>
                        <option value="10" <%= "10".equals(childcount) ? "selected" : "" %>>어린이 10명</option>
                    </select>                    
                </div>
            </div>

            <br>
            <div class="rt">
                <label>좌석종류</label>
                <select id="seatType" name="seatType">
                    <option value="일반" <%= "일반".equals(seatType) ? "selected" : "" %>>일반</option>
                    <option value="특실" <%= "특실".equals(seatType) ? "selected" : "" %>>특실</option>
                </select>
            </div>

            <br>

            <div class="search">
                <button class="btn btn-success" onclick="fetchTicketInfo()">조회</button>
            </div>
            
            <br>
            <div id="results"></div>
            <div id="pagination"></div>
            
            <br>
            <jsp:include page="sidemenu.jsp" />
        </div>          
    </div>  

    <script>
        let currentPage = 1;
        const itemsPerPage = 12;

        // 날짜 형식 변환 함수
        function formatDate() {
            var dateInput = document.getElementById('Date').value;
            if (dateInput) {
                var formattedDate = dateInput.replace(/-/g, '');
                document.getElementById('formattedDate').value = formattedDate; 
            } else {
                document.getElementById('formattedDate').value = ''; 
            }
        }

        // 차종에 따라 역 선택 섹션 토글 함수
        function toggleStations(trainType) {
            if (trainType === 'ktx') {
                document.getElementById('ktxStation').style.display = 'block';
                document.getElementById('srtStation').style.display = 'none';
            } else if (trainType === 'srt') {
                document.getElementById('ktxStation').style.display = 'none';
                document.getElementById('srtStation').style.display = 'block';
            }
        }
        
        // 초기 로드 시 KTX 섹션을 보여줌
        window.onload = function() {
            toggleStations('<%= trainType %>');
        };
        
        // 출발역과 도착역 바꾸기
        function swapStations() {
            var arrPlace = document.getElementById('arrplacename').value;
            var depPlace = document.getElementById('depplacename').value;
            var start = document.getElementById('depPlaceIdHidden').value;
            var end = document.getElementById('arrPlaceIdHidden').value; 
            document.getElementById('arrplacename').value = depPlace;
            document.getElementById('depplacename').value = arrPlace;
            document.getElementById('arrPlaceIdHidden').value = start;
            document.getElementById('depPlaceIdHidden').value = end;
        }
        
        // 역 조회
        let openWin1, openWin2;

		function openChild(stationType) {
		    window.name = "parentForm";
		    const trainType = document.querySelector('input[name="trainType"]:checked').value;

		    let url, windowName;

		    if (trainType === 'KTX') {
		        url = stationType === 'dep' ? "lookUp.do" : "lookUp2.do";
		        windowName = stationType === 'dep' ? "lookUpForm" : "lookUp2Form";
		    } else if (trainType === 'SRT') {
		        url = stationType === 'dep' ? "lookUp3.do" : "lookUp4.do";
		        windowName = stationType === 'dep' ? "lookUp3Form" : "lookUp4Form";
		    }

		    openWin1 = window.open(url, windowName, "width=570, height=400, resizable=no, scrollbars=no");
		}


		//좌석 조회	
		function seatTicket(trainno, depPlace, arrPlace, depTime, arrTime, duration, adultcharge) {
		    var depPlaceId = document.getElementById('depPlaceIdHidden').value;
		    var arrPlaceId = document.getElementById('arrPlaceIdHidden').value;
		    var seatType = document.getElementById('seatType').value;
		    var formattedDate = document.getElementById('formattedDate').value;
		    var trainType = document.querySelector('input[name="trainType"]:checked').value;
		    var personnelCount = document.getElementById('adultcount').value;
		    var childCount = document.getElementById('childcount').value;
			
		    // 로그인 여부 확인
		    var userid = <%= userid != null ? "'" + userid + "'" : "null" %>;

		    if (!userid) {
				alert("로그인이 필요합니다. 로그인 후 이용 부탁드립니다.");
		        window.location.href = 'login.do'; // 로그인 페이지로 리디렉션
		        return;
		    }

		    var queryParams = '?' +
		        'depPlace=' + encodeURIComponent(depPlace) + '&' +
		        'arrPlace=' + encodeURIComponent(arrPlace) + '&' +
		        'trainno=' + encodeURIComponent(trainno) + '&' +
		        'depTime=' + encodeURIComponent(depTime) + '&' +
		        'arrTime=' + encodeURIComponent(arrTime) + '&' +
		        'duration=' + encodeURIComponent(duration) + '&' +
		        'seatType=' + encodeURIComponent(seatType) + '&' +
		        'formattedDate=' + encodeURIComponent(formattedDate) + '&' +
		        'trainType=' + encodeURIComponent(trainType) + '&' +
		        'personnelCount=' + encodeURIComponent(personnelCount) + '&' +
		        'childCount=' + encodeURIComponent(childCount) + '&' +
				'userid=' + encodeURIComponent(userid) + '&' +
		        'adultcharge=' + encodeURIComponent(adultcharge);

		    var openWin3 = window.open("seat.do" + queryParams, "seat", "width=1000, height=850, resizable=no, scrollbars=no");
		}

        // 데이터 페이징 및 표시 함수
        function displayPage(items, page) {
            const startIndex = (page - 1) * itemsPerPage;
            const endIndex = page * itemsPerPage;
            const paginatedItems = items.slice(startIndex, endIndex);

            if (paginatedItems.length > 0) {
                let table = '<table class="checkTrain">' +
                    '<thead>' +
                    '<tr>' +
                    '<th>열차종류</th>' +
                    '<th>열차번호</th>' +
                    '<th>출발역</th>' +
                    '<th>도착역</th>' +
                    '<th>좌석종류</th>' +
                    '<th>출발시간</th>' +
                    '<th>도착시간</th>' +
                    '<th>소요시간</th>' +
                    '</tr>' +
                    '</thead>' +
                    '<tbody>';
                paginatedItems.forEach(function(item) {
                    var depTime = String(item.depplandtime); 
                    var arrTime = String(item.arrplandtime);

                    var startDate = new Date(
                        depTime.substring(0, 4), 
                        depTime.substring(4, 6) - 1, 
                        depTime.substring(6, 8),
                        depTime.substring(8, 10),
                        depTime.substring(10, 12)
                    );
                    var endDate = new Date(
                        arrTime.substring(0, 4), 
                        arrTime.substring(4, 6) - 1, 
                        arrTime.substring(6, 8),
                        arrTime.substring(8, 10),
                        arrTime.substring(10, 12)
                    );

                    var formattedTime = startDate.toTimeString().substring(0, 5);
                    var formatted2Time = endDate.toTimeString().substring(0, 5);

                    var durationMinutes = Math.round((endDate - startDate) / 60000);
                    var hours = Math.floor(durationMinutes / 60);
                    var minutes = durationMinutes % 60;
                    
                    table += '<tr>' +
                        '<td>' + (item.traingradename || 'N/A') + '</td>' +
                        '<td>' + (item.trainno || 'N/A') + '</td>' +
                        '<td>' + (item.depplacename || 'N/A') + '</td>' +
                        '<td>' + (item.arrplacename || 'N/A') + '</td>' +
				       	'<td><button class="seat-btn" onclick="seatTicket(\'' + item.trainno + '\', \'' + item.depplacename + '\', \'' + item.arrplacename + '\', \'' + formattedTime + '\', \'' + formatted2Time + '\', \'' + hours + '시간 ' + minutes + '분\', \'' + item.adultcharge + '\')">좌석 선택</button></td>' +
                        '<td>' + formattedTime + '</td>' +
                        '<td>' + formatted2Time + '</td>' +
                        '<td>' + hours + '시간 ' + minutes + '</td>' +
                        '<input type="hidden" class="adultcharge" value="' + (item.adultcharge || 'N/A') + '">' +
                    '</tr>';
                });

                table += '</tbody></table><br>';
                document.getElementById('results').innerHTML = table;
            } else {
                document.getElementById('results').innerText = '해당 페이지에 데이터가 없습니다.';
            }

            displayPagination(items.length, page);
        }

        // 페이지네이션 버튼 생성 함수
        function displayPagination(totalItems, currentPage) {
            const totalPages = Math.ceil(totalItems / itemsPerPage);
            let paginationHTML = '<nav><ul class="pagination justify-content-center">';

            for (let i = 1; i <= totalPages; i++) {
                paginationHTML += '<li class="page-item ' + (i == currentPage ? 'active' : '') + '">'
                    + '<a class="page-link" href="#" onclick="goToPage(' + i + ')">' + i + '</a>'
                    + '</li>';
            }

            paginationHTML += '</ul></nav>';
            document.getElementById('pagination').innerHTML = paginationHTML;
        }

        // 페이지 이동 함수
        function goToPage(page) {
            currentPage = page;
            fetchTicketInfo();
        }

        // API 데이터를 가져오는 함수
		function fetchTicketInfo() {
		    // 유효성 검사
		    var depPlaceId = document.getElementById('depplacename').value.trim();
		    var arrPlaceId = document.getElementById('arrplacename').value.trim();
		    var formattedDate = document.getElementById('formattedDate').value.trim();
			var trainTypeElement = document.querySelector('input[name="trainType"]:checked');			

			if (!trainTypeElement) {
			    alert("열차를 선택하세요.");
			    return;
			}
			
		    if (depPlaceId === "") {
		        alert("출발역을 선택하세요.");
		        return;
		    }

		    if (arrPlaceId === "") {
		        alert("도착역을 선택하세요.");
		        return;
		    }

		    if (formattedDate === "") {
		        alert("출발일을 선택하세요.");
		        return;
		    }

		    // 출발일이 오늘 이전일 수 없음
		    var selectedDate = new Date(formattedDate);
		    var today = new Date();
		    today.setHours(0, 0, 0, 0); // 오늘 날짜의 시간을 00:00:00으로 설정

		    if (selectedDate < today) {
		        alert("출발일은 오늘 이전일 수 없습니다.");
		        return;
		    }

		    // 기존의 API 요청 및 데이터 처리 로직
		    var seatType = document.getElementById('seatType').value;
		    var selectedTime = document.getElementById('timeSelect').value;
		    var trainType = document.querySelector('input[name="trainType"]:checked').id;
		    var start = document.getElementById('depPlaceIdHidden').value;
		    var end = document.getElementById('arrPlaceIdHidden').value;

		    var depPlandTime = formattedDate;

		    var xhr = new XMLHttpRequest();
		    var serviceKey = 'KOyx/5iXteTdFA1wcSF1KvBTsEQcHMa8cFsrBwLTM6EGpTydPaVEtn4IjjQrwiIxqBvpc+qi4NM9izQQfHzT3w==';
		    var queryParams = '?' + encodeURIComponent('serviceKey') + '=' + encodeURIComponent(serviceKey) +
		        '&' + encodeURIComponent('pageNo') + '=' + encodeURIComponent('1') +
		        '&' + encodeURIComponent('numOfRows') + '=' + encodeURIComponent('50') +
		        '&' + encodeURIComponent('_type') + '=' + encodeURIComponent('json') +
		        '&' + encodeURIComponent('depPlaceId') + '=' + encodeURIComponent(start) +
		        '&' + encodeURIComponent('arrPlaceId') + '=' + encodeURIComponent(end) +
		        '&' + encodeURIComponent('depPlandTime') + '=' + encodeURIComponent(depPlandTime) +
		        '&' + encodeURIComponent('trainGradeCode') + '=' + encodeURIComponent(trainType);

		    xhr.open('GET', 'https://apis.data.go.kr/1613000/TrainInfoService/getStrtpntAlocFndTrainInfo' + queryParams);
		    xhr.onreadystatechange = function () {
		        if (this.readyState == 4) {
		            if (this.status == 200) {
		                try {
		                    var response = JSON.parse(this.responseText);
		                    var items = response.response.body.items.item || [];
		                    if (items.length > 0) {
		                        var filteredItems = items.filter(function(item) {
		                            var depTime = String(item.depplandtime); 
		                            var itemHour = depTime.substring(8, 10); 
		                            return parseInt(itemHour) >= parseInt(selectedTime);
		                        });

		                        displayPage(filteredItems, currentPage);
		                    } else {
		                        document.getElementById('results').innerText = '검색된 결과가 없습니다.';
		                    }
		                } catch (e) {
		                    console.error('JSON 파싱 오류:', e);
		                    document.getElementById('results').innerText = '서버 응답을 처리하는 동안 오류가 발생했습니다.';
		                }
		            } else {
		                console.error('API 요청 실패:', this.status, this.statusText);
		                document.getElementById('results').innerText = '서버 응답 오류: ' + this.statusText;
		            }
		        }
		    };

		    xhr.onerror = function () {
		        console.error('네트워크 오류 발생:', this.statusText);
		        document.getElementById('results').innerText = '네트워크 오류가 발생했습니다.';
		    };

		    xhr.send();
		}

        // 오늘 이전으로 날짜 선택 제한
        var now_utc = Date.now();
        var timeOff = new Date().getTimezoneOffset()*60000;
        var today = new Date(now_utc-timeOff).toISOString().split("T")[0];      
        document.getElementById("Date").setAttribute("min", today);
        
    </script>
</body>
</html>
