<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <title>KTX 역 선택</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .station-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
        }
        .station-button {
            width: 150px; /* 버튼 사이즈를 줄임 */
            margin: 5px;
        }
        .station-button button {
            width: 100%;
            height: 40px; /* 버튼 높이를 줄임 */
            font-size: 14px;
            font-weight: bold;
            background-color: #28a745; /* Bootstrap success 색상 */
            color: white;
            border: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .station-button button:hover {
            background-color: #218838; /* Success 색상 hover */
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .header h1 {
            color: #343a40;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>KTX 역 선택</h1>
        </div>
        <div class="station-list">
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="서울" data-value="NAT010000">서울</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="부산" data-value="NAT014445">부산</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="대전" data-value="NAT011668">대전</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="광명" data-value="NAT011762">광명</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="천안아산" data-value="NAT014172">천안아산</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="대구" data-value="NAT014278">대구</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="동대구" data-value="NAT014285">동대구</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="울산(통도사)" data-value="NAT034078">울산(통도사)</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="신경주" data-value="NAT014311">신경주</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="익산" data-value="NAT011949">익산</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="광주송정" data-value="NAT011952">광주송정</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="목포" data-value="NAT011954">목포</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="포항" data-value="NAT034185">포항</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="창원" data-value="NAT034098">창원</button>
            </div>
            <div class="station-button">
                <button name="stationName" onclick="setParentText(this)" value="마산" data-value="NAT034112">마산</button>
            </div>
        </div>
    </div>

    <script>
        function setParentText(buttonElement) {
            if (opener && !opener.closed) { // 부모 창이 열려 있는지 확인
                var parentInput = opener.document.getElementById("arrplacename");
                var hiddenField = opener.document.getElementById("arrPlaceIdHidden");
                
                if (parentInput) {
                    parentInput.value = buttonElement.getAttribute('value'); // 버튼의 value 값을 부모 창의 입력 필드에 설정
                }
                
                if (hiddenField) {
                    hiddenField.value = buttonElement.getAttribute('data-value'); // 버튼의 data-value 값을 hiddenField에 설정
                }
                
                console.log('Selected data-value:', buttonElement.getAttribute('data-value')); // 클릭된 버튼의 data-value를 콘솔에 출력
                
                window.close(); // 자식 창 닫기
            } else {
                alert("부모 창을 찾을 수 없습니다.");
            }
        }
    </script>
</body>
</html>
