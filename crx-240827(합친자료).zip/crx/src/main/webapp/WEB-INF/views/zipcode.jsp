<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>    

<script src="../js/zipcode.js"></script>
<!DOCTYPE html>
<html>
	<head>	  
	</head>
	<body>
	  <!-- 우편번호 입력란 -->
	  <input type="text" id="sample6_postcode" style="width:100px" placeholder="우편번호">
	  <input type="button" onclick="zipcode()" value="주소검색"><br>

	  <!-- 주소 입력란 -->
	  <input type="text" id="sample6_address" style="width:400px" placeholder="주소" onchange="updateUserAdd()"><br>
	  
	  <!-- 상세주소 입력란 -->
	  <input type="text" id="sample6_detailAddress" placeholder="상세주소" onchange="updateUserAdd()">
	  
	  <!-- 참고주소 (사용하지 않지만 필요 시 활성화 가능) -->
	  <input type="hidden" id="sample6_extraAddress" placeholder="참고주소">
	</body>

	<!-- 다음 우편번호 서비스 스크립트 -->
	<script src="//t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
	<script>
	  function updateUserAdd() {
	      var postcode = document.getElementById('sample6_postcode').value || '';
	      var address = document.getElementById('sample6_address').value || '';
	      var detailAddress = document.getElementById('sample6_detailAddress').value || '';
	      var fullAddress = address + ' ' + detailAddress || '';

	      // 사용자의 타입에 따라 우편번호와 주소를 설정
	      if ("${crxVO.userpost == null}" == "false") {
	          document.getElementById('userpost').value = postcode;
	          document.getElementById('useradd').value = fullAddress;
	      } else if ("${crxVO.mempost != null}" == "false") {
	          document.getElementById('mempost').value = postcode;
	          document.getElementById('memadd').value = fullAddress;
	      }
	  }

	  document.addEventListener("DOMContentLoaded", function() {
	      // 서버에서 가져온 기존 우편번호와 주소 값
	      var userPostcode = '${crxVO.userpost != null ? crxVO.userpost : crxVO.mempost}';
	      var userAdd = '${crxVO.useradd != null ? crxVO.useradd : crxVO.memadd}';

	      // 우편번호 입력란에 기존 우편번호 값 설정
	      if (userPostcode) {
	          document.getElementById('sample6_postcode').value = userPostcode;
	      }

	      // 주소 및 상세주소 입력란에 기존 주소 값 설정
	      if (userAdd) {
	          var addressParts = userAdd.split(' ');
	          var sample6Address = addressParts.slice(0, addressParts.length - 1).join(' ');
	          var sample6DetailAddress = addressParts[addressParts.length - 1];
	          
	          document.getElementById('sample6_address').value = sample6Address;
	          document.getElementById('sample6_detailAddress').value = sample6DetailAddress;
	      }
	  });
	</script>

	<style>
	  .wrong_text { 
		  font-size: 1rem; 
		  color: #f44e38; 
		  letter-spacing: -0.2px; 
		  font-weight: 300; 
		  margin: 8px 0 2px; 
		  line-height: 1em; 
		  display: none;
	  }
	</style>
</html>
