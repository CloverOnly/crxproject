<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
    String username = (String) session.getAttribute("username");
    String memname = (String) session.getAttribute("memname");
%>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script type="text/javascript" src="https://cdn.iamport.kr/js/iamport.payment-1.1.5.js"></script>
    <meta charset="UTF-8">
    <title>결제</title>
    <style>
        .all {
            width: 1200px;  
            margin: 0 auto;
        }
        .tiline {
            display: inline;
            border: solid 1px green;
            border-radius: 8px;
            padding: 5px;
            color: green;
            margin: 5px;
        }
        .guide {
            width: 1200px;
            height: auto;
            background-color: #f8f8f8;
            margin: 2px;
            padding: 5px;
            font-size: 12px;
        }
        .guidep {
            margin-bottom: 3px;
        }
        .payment {
            text-align: center;
        }
        table, th, td {
            border: 2px solid white;
            border-collapse: collapse;
        }
        th, td {
            background-color: #96D4D4;
        }
        .ta th {
            background-color: #96D4D4;
            width: 300px;
            text-align: center;
        }
        .ta td {
            background-color: #f9f9f9;
            width: 1000px;
            text-align: center;
        }
        .taa th {
            background-color: #96D4D4;
            width: 100px;
        }
        .taa td {
            background-color: #f9f9f9;
        }
        .amount {
            width: 300px;
            height: 40px;
        }
    </style>
</head>
<body>
    <jsp:include page="header.jsp" />  
    <div class="all">  
        <div class="maintitle">
            <h1>결제</h1>
            <hr>
        </div>
        
        <br>
        <div style="text-align:center;">
            <img src="../img/mark3.gif" style="width:500px">
        </div>
        
        <br>
        <div class="guide">
            <p class="guidep">결제방법은 신용카드, 간편결제, 실시간계좌이체, 가상계좌, 소액계좌 5가지가 있습니다.</p>
            <p class="guidep">간편결제의 경우 브라우저의 팝업 차단을 허용하신 후 이용해 주시기 바랍니다.</p>
        </div>
        
        <div>
            <table class="amount">
                <tr class="ta">
                    <td>결제 금액</td>
                    <td id="pay">100</td>
                </tr>
            </table>
        </div>
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">결제종류</button>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                <br>    
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="payment" id="card" value="card" checked>
                    <label class="form-check-label" for="card">
                        신용카드
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="payment" id="trans" value="trans">
                    <label class="form-check-label" for="trans">
                        실시간계좌이체
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="payment" id="vbank" value="vbank">
                    <label class="form-check-label" for="vbank">
                        가상계좌
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="payment" id="phone" value="phone">
                    <label class="form-check-label" for="phone">
                        소액결제
                    </label>
                </div>
                
                <br>
                <div class="guide">
                    <strong class="guidep">간편결제 관련 안내사항</strong>
                    <ul>
                        <li class="guidep">휴대폰과 카드 명의자가 동일해야 결제가 가능하며, 결제금액 제한은 없습니다.</li>
                        <li class="guidep">발권버튼을 누르시면 선택하신 간편결제 항목에 따른 결제 팝업창이 오픈됩니다.</li>
                        <li class="guidep">해당 간편결제 팝업창에서 결제정보를 입력하시고 결제완료버튼을 누르시면 결제가 처리됩니다.</li>
                    </ul>    
                </div>
                <br>
                <div class="guide">
                    <strong class="guidep">인터넷 익스플로러(IE)에서 간편결제 후 'opener를 찾을 수 없습니다.'라는 메시지가 나오는 경우</strong>    
                    <ul>
                        <li class="guidep">[인터넷 옵션]>[보안]탭에서 [신뢰할 수 있는 사이트]로 이동합니다.</li>
                        <li class="guidep">[사이트]버튼을 클릭한 후 '*.koko.com', '*.naver.com'을 추가한 다음 다시 시도해 주십시오.</li>                
                    </ul>    
                </div>
            </div>
        </div>
        
        <br>
        <c:forEach var="reservation" items="${payment}">
            <div class="payment">
                <input type="hidden" id="startname" name="startname" value="${reservation.startname}" />
                <input type="hidden" id="endname" name="endname" value="${reservation.endname}" />
                <input type="hidden" id="seatType" name="seatType" value="${reservation.seatType}" />
                <input type="hidden" id="startdate" name="startdate" value="${reservation.startdate}" />
                <input type="hidden" id="trainType" name="trainType" value="${reservation.trainType}" />
                <input type="hidden" id="personnelCount" name="personnelCount" value="${reservation.personnelCount}" />
                <input type="hidden" id="childCount" name="childCount" value="${reservation.childCount}" />
                <input type="hidden" id="trainno" name="trainno" value="${reservation.trainno}" />
                <input type="hidden" id="depTime" name="depTime" value="${reservation.depTime}" />
                <input type="hidden" id="arrTime" name="arrTime" value="${reservation.arrTime}" />
                <input type="hidden" id="duration" name="duration" value="${reservation.duration}" />
                <input type="hidden" id="selectedSeats" name="selectedSeats" value="${reservation.selectedSeats}" />
                <input type="hidden" id="hocha" name="hocha" value="${reservation.hocha}" />
                <input type="hidden" id="totalAdultCharge" name="totalAdultCharge" value="${reservation.totalAdultCharge}" />
                <input type="hidden" id="totalChildCharge" name="totalChildCharge" value="${reservation.totalChildCharge}" />
                <input type="hidden" id="endCharge" name="endCharge" value="${reservation.endCharge}" />
                <input type="hidden" id="totalCharge" name="totalCharge" value="${reservation.totalCharge}" />
                <input type="hidden" id="totalDiscount" name="totalDiscount" value="${reservation.totalDiscount}" />
                <input type="hidden" id="userid" name="userid" value="${reservation.userid}" />             
            </div>
        </c:forEach>
        
        <br>
        <div class="payment">
            <button type="button" class="n_payment btn btn-success">결제</button>
            <button type="button" class="btn btn-secondary" onclick="location.href='main.jsp'">취소</button>
        </div>
    </div>

	<script>
	    $(".n_payment").click(function() {
	        IMP.init("imp10351001");

	        var paymentMethod = $("input[name='payment']:checked").val();
	        var amountText = $("#pay").text();
	        var amount = amountText.replace(/[^0-9]/g, '');

	        // 결제 데이터를 정의
	        var paymentData = {
	            startname: $("input[name='startname']").val(),
	            endname: $("input[name='endname']").val(),
	            seatType: $("input[name='seatType']").val(),
	            startdate: $("input[name='startdate']").val(),
	            trainType: $("input[name='trainType']").val(),
	            personnelCount: $("input[name='personnelCount']").val(),
	            childCount: $("input[name='childCount']").val(),
	            trainno: $("input[name='trainno']").val(),
	            depTime: $("input[name='depTime']").val(),
	            arrTime: $("input[name='arrTime']").val(),
	            duration: $("input[name='duration']").val(),
	            selectedSeats: $("input[name='selectedSeats']").val(),
	            hocha: $("input[name='hocha']").val(),
	            totalAdultCharge: $("input[name='totalAdultCharge']").val(),
	            totalChildCharge: $("input[name='totalChildCharge']").val(),
	            endCharge: $("input[name='endCharge']").val(),
	            totalCharge: $("input[name='totalCharge']").val(),
	            totalDiscount: $("input[name='totalDiscount']").val(),
	            userid: $("input[name='userid']").val()
	        };

	        IMP.request_pay({
	            pg: 'html5_inicis',
	            merchant_uid: 'merchant_' + new Date().getTime(),
	            pay_method: paymentMethod,
	            name: '주문명: ',
	            amount: amount,
	            buyer_email: 'iamport@siot.do',
	            buyer_name: 'dd',
	            buyer_tel: '010-1234-5678',
	            buyer_addr: '서울특별시 강남구 삼성동',
	            buyer_postcode: '123-456'
	        }, function(rsp) {
	            if (rsp.success) {
	                // rsp 객체에서 paid_amount와 apply_num을 추출하여 paymentData에 추가
	                paymentData.paid_amount = rsp.paid_amount;
	                paymentData.apply_num = rsp.apply_num;

	                // 서버에 AJAX 요청을 보냅니다.
	                $.ajax({
	                    url: '/ticketPay',
	                    type: 'POST',
	                    contentType: 'application/json',
	                    data: JSON.stringify(paymentData),
	                    success: function(response) {
	                        if (response === "Success") {
	                            alert("결제가 완료되었습니다.");
								window.location.href = 'ticketing.do?apply_num=' + rsp.apply_num;
	                        } else {
	                            alert("결제를 실패했습니다.");
	                        }
	                    },
	                    error: function(xhr, status, error) {
	                        console.error("서버 요청 오류:", error);
	                    }
	                });
	            } else {
	                alert("결제에 실패했습니다.");
	            }
	        });
	    });
	</script>



</body>
</html>

