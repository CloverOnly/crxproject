<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
    Integer userid = (Integer) session.getAttribute("userid");
    String username = (String) session.getAttribute("username");
%>
<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta charset="UTF-8">
    <title>유실물 안내</title>
    <style>
        .con {
            margin: auto;
            width: 1200px;
        }
        .lost-table {
            margin: auto;
            width: 100%;
            max-width: 1200px;
            border-radius: 5px;
            border-collapse: collapse;
            border-top: none;
            table-layout: fixed;
        }
        .header {
            background-color: rgb(226, 240, 217);
            text-align: center;
        }
        .lost-table td, .lost-table th {
            height: 30px;
            font-size: 14px;
            padding: 10px;
            text-align: center;
        }
        .lostNo {
            width: 10%;
        }
        .lostTitle {
            width: 40%;
        }
        .lostPlace {
            width: 15%;
        }
        .lostWriter {
            width: 15%;
        }
        .lostRegDate {
            width: 10%;
        }
        .lostHit {
            width: 10%;
        }
        .body {
            text-align: center;
        }
        .body .title {
            text-align: left;
        }
        button {
            width: auto;
            font-size: 15px;
            border: 0;
            outline: 1.5px gray solid;
            border-radius: 5px;
            padding-left: 10px;
        }
        .atag {
            text-decoration: none;
        }
        .atag:hover {
            text-decoration: underline;
        }
        .typeBox {
            height: 40px;
            font-size: 16px;
        }
        .inputSearch {
            width: 200px;
            height: 40px;
            font-size: 16px;
        }
        .submitBtn {
            font-size: 16px;
            width: 60px;
            height: 40px;
        }
        .submitBtn:hover {
            background-color: rgb(21, 115, 71) !important;
        }
    </style>
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />
    <div class="con">
        <h1>유실물 안내</h1>
        <br>
        <div class="position-relative m-3 lost-search">
            <form action="${contextPath}/lostList.do" method="get" id="search" name="search" class="d-flex align-items-center">
                <select class="form-select me-2" id="searchType" name="searchType" style="width: 150px;">
                    <option value="title" ${search.searchType == 'title' ? 'selected' : ''}>품목</option>
                    <option value="writer" ${search.searchType == 'writer' ? 'selected' : ''}>작성자</option>
                    <option value="content" ${search.searchType == 'content' ? 'selected' : ''}>내용</option>
					<option value="place" ${search.searchType == 'place' ? 'selected' : ''}>보관장소</option>
                </select>
                <input type="text" class="form-control me-2" name="keyword" value="${search.keyword}" placeholder="검색어를 입력해주세요." style="width: 300px;">
                <button type="submit" class="btn btn-success">검색</button>
            </form>
        </div>
        
        <table class="lost-table">
            <tr class="header text-center">
                <td class="lostNo">번호</td>
                <td class="lostTitle">품목</td>
                <td class="lostPlace">보관장소</td>
                <td class="lostWriter">작성자</td>
                <td class="lostRegDate">등록일자</td>
                <td class="lostHit">조회수</td>
            </tr>
            <c:forEach items="${lostList}" var="lost">
                <tr class="text-center">
                    <td>${lost.lostno}</td>
                    <td class="text-start"><a href="${contextPath}/lostDetail.do?lostno=${lost.lostno}" class="atag text-black">${lost.losttitle}</a></td>
                    <td>${lost.lostplace}</td>
                    <td>${lost.memname}</td>
                    <td>${lost.lostdate}</td>
                    <td>${lost.losthit}</td>
                </tr>
            </c:forEach>
        </table>
        <br>
        
        <div id="paginationBox" class="pagination1">
            <ul class="pagination justify-content-center">
                <li class="page-item ${pagination.page == 1 || pagination.totalPage == 0 ? 'disabled' : ''}">
                    <a class="page-link btn btn-success mx-1" href="?page=1&searchType=${search.searchType}&keyword=${search.keyword}">처음</a>
                </li>

                <li class="page-item ${pagination.page == 1 || pagination.totalPage == 0 ? 'disabled' : ''}">
                    <a class="page-link btn btn-success mx-1" href="?page=${pagination.page - 1}&searchType=${search.searchType}&keyword=${search.keyword}">이전</a>
                </li>

                <c:forEach begin="${pagination.startPage}" end="${pagination.endPage}" var="i">
                    <li class="page-item ${pagination.page == i ? 'active' : ''}">
                        <c:if test="${pagination.page == i}">
                            <a class="page btn btn-secondary mx-1 disabled" href="#">${i}</a>
                        </c:if>
                        <c:if test="${pagination.page != i}">
                            <a class="page btn btn-success mx-1" href="?page=${i}&searchType=${search.searchType}&keyword=${search.keyword}">${i}</a>
                        </c:if>
                    </li>
                </c:forEach>

                <li class="page-item ${pagination.page == pagination.totalPage || pagination.totalPage == 0 ? 'disabled' : ''}">
                    <a class="page-link btn btn-success mx-1" href="?page=${pagination.page + 1}&searchType=${search.searchType}&keyword=${search.keyword}">다음</a>
                </li>

                <li class="page-item ${pagination.page == pagination.totalPage || pagination.totalPage == 0 ? 'disabled' : ''}">
                    <a class="page-link btn btn-success mx-1" href="?page=${pagination.totalPage}&searchType=${search.searchType}&keyword=${search.keyword}">끝</a>
                </li>
            </ul>
        </div>

        <div>    
            <c:if test="${(divname == '고객안내' || divname == '통합관리') && (level == 'master' || level == 'admin')}">
                <button class="btn btn-success buttonAdd" onclick="location.href='${contextPath}/lostAdd.do?userid=${userid}'">등록</button>
            </c:if>
        </div>
    </div>
    <jsp:include page="footer.jsp" />
</body>
</html>
