<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <title>SRT 역 선택</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	<style>
		html, body {
		    width: 695px;
		    height: 630px;
		    margin: 0;
		    padding: 0;
		    overflow: hidden;
			position: fixed;
		}
		* {
			margin: 0;
			padding: 0;
		}
		.mapList {
			padding: 10px;
		}
		.map {
			position: relative;
		    height: 100%;
		    padding: 10px;
		}
		.mapGyeongbu {		
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -2%);
			width: 399px;
		    height: 495px;
			margin: 0;
			padding: 0;
			z-index: 1;
		}
		.mapHonam {		
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -2%);
			width: 399px;
		    height: 495px;
			margin: 0;
			padding: 0;
			z-index: 1;
		}
		.mapJeolla {		
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -2%);
			width: 399px;
		    height: 495px;
			margin: 0;
			padding: 0;
			z-index: 1;
		}
		.mapGyeongjeon {		
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -2%);
			width: 399px;
		    height: 478px;
			margin: 0;
			padding: 0;
			z-index: 1;
		}
		.mapDonghae {		
			position: absolute;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -2%);
			width: 399px;
		    height: 491px;
			margin: 0;
			padding: 0;
			z-index: 1;
		}
		.contanierMap {
			border: 10px solid rgb(122, 37, 92);
			border-top: 20px solid rgb(122, 37, 92);
			height: 629px;
		}
        .header {
            text-align: center;
			background-color: rgb(122, 37, 92);
			padding-bottom: 5px;
        }
		.header h1 {
			color: white;
		}
		.mapGyeongbu, .mapHonam, .mapJeolla, .mapGyeongjeon, .mapDonghae {
		    display: none;
		}

		.tab-pane.show .mapGyeongbu,
		.tab-pane.show .mapHonam,
		.tab-pane.show .mapJeolla,
		.tab-pane.show .mapGyeongjeon,
		.tab-pane.show .mapDonghae {
		    display: block;
		}
		.nav-tabs {
			width: 100%
		}
		.nav-tabs .nav-link {
			width: 20%;
			text-align: center;
			color: black;
		}
		.nav-tabs .nav-link.active {
			color: rgb(122, 37, 92);
			font-weight: bold;
		}
	    .station-list {			
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			gap: 10px;
	        position: relative;
			width: 100%;
			height: 485px; /* 지도의 높이에 맞게 설정 */
	    }
		/* 경부선 */
		.station-button {
			position: absolute;         
            margin: 5px;
			z-index: 2;
        }
        .station-button button {
            font-size: 14px;
            font-weight: bold;
            background-color: rgb(122, 37, 92);			
            color: white;
            border: none;            
            transition: background-color 0.3s ease;
        }
        .station-button button:hover {
            background-color: rgb(86, 27, 65);
        }
	   	.station-button:nth-child(2) {
			top: 237px;
		    left: 294px;
	    }
	    .station-button:nth-child(3) {
			top: 267px;
		    left: 283px;
	    }
	    .station-button:nth-child(4) {
			top: 294px;
			left: 281px;
	    }
	    .station-button:nth-child(5) {
			top: 321px;
		    left: 291px;
	    }
	    .station-button:nth-child(6) {
			top: 348px;
		    left: 313px;
	    }
		.station-button:nth-child(7) {
			top: 373px;
		    left: 316px;
	    }
		.station-button:nth-child(8) {
			top: 391px;
			left: 370px;
	    }
		.station-button:nth-child(9) {
			top: 437px;
			left: 315px;
	    }
		.station-button:nth-child(10) {
			top: 416px;
			left: 388px;
	    }
		.station-button:nth-child(11) {
			top: 416px;
			left: 455px;
	    }
		.station-button:nth-child(12) {
			top: 463px;
		    left: 354px;
	    }
		.station-button:nth-child(13) {
			top: 494px;
			left: 382px;
	    }
		/* 호남선 */
		.station-button2 {
			position: absolute;         
            margin: 5px;
			z-index: 2;
        }
        .station-button2 button {
            font-size: 14px;
            font-weight: bold;
            background-color: rgb(122, 37, 92);			
            color: white;
            border: none;            
            transition: background-color 0.3s ease;
        }
        .station-button2 button:hover {
            background-color: rgb(86, 27, 65);
        }
		.station-button2:nth-child(2) {
			top: 233px;
			left: 293px;
	    }
	    .station-button2:nth-child(3) {
			top: 263px;
			left: 281px;
	    }
	    .station-button2:nth-child(4) {
			top: 291px;
			left: 279px;
	    }
	    .station-button2:nth-child(5) {
			top: 319px;
		    left: 289px;
	    }
	    .station-button2:nth-child(6) {
			top: 347px;
			left: 309px;
	    }
		.station-button2:nth-child(7) {
			top: 361px;
			left: 218px;
	    }
		.station-button2:nth-child(8) {
			top: 416px;
		    left: 265px;
	    }
		.station-button2:nth-child(9) {
			top: 452px;
		    left: 264px;
	    }
		.station-button2:nth-child(10) {
			top: 489px;
		    left: 262px;
	    }
		.station-button2:nth-child(11) {
			top: 514px;
		    left: 250px;
	    }
		.station-button2:nth-child(12) {
			top: 539px;
			left: 226px;
	    }
		/* 전라선 */
		.station-button3 {
			position: absolute;         
            margin: 5px;
			z-index: 2;
        }
        .station-button3 button {
            font-size: 14px;
            font-weight: bold;
            background-color: rgb(122, 37, 92);			
            color: white;
            border: none;            
            transition: background-color 0.3s ease;
        }
        .station-button3 button:hover {
            background-color: rgb(86, 27, 65);
        }
		.station-button3:nth-child(2) {
			top: 237px;
			left: 292px;
	    }
	    .station-button3:nth-child(3) {
			top: 267px;
		    left: 280px;
	    }
	    .station-button3:nth-child(4) {
			top: 294px;
			left: 278px;
	    }
	    .station-button3:nth-child(5) {
			top: 322px;
		    left: 289px;
	    }
	    .station-button3:nth-child(6) {
			top: 349px;
			left: 308px;
	    }
		.station-button3:nth-child(7) {
			top: 361px;
		    left: 217px;
	    }
		.station-button3:nth-child(8) {
			top: 413px;
		    left: 265px;
	    }
		.station-button3:nth-child(9) {
			top: 436px;
		    left: 290px;
	    }
		.station-button3:nth-child(10) {
			top: 461px;
			left: 293px;
	    }
		.station-button3:nth-child(11) {
			top: 488px;
		    left: 297px;
	    }
		.station-button3:nth-child(12) {
			top: 513px;
		    left: 233px;
	    }
		.station-button3:nth-child(13) {
			top: 537px;
		    left: 247px;
	    }
		.station-button3:nth-child(14) {
			top: 561px;
		    left: 271px;
	    }
		.station-button3:nth-child(15) {
			top: 551px;
			left: 351px;
	    }
		/* 경전선 */
		.station-button4 {
			position: absolute;         
            margin: 5px;
			z-index: 2;
        }
        .station-button4 button {
            font-size: 14px;
            font-weight: bold;
            background-color: rgb(122, 37, 92);			
            color: white;
            border: none;            
            transition: background-color 0.3s ease;
        }
        .station-button4 button:hover {
            background-color: rgb(86, 27, 65);
        }
		.station-button4:nth-child(2) {
			top: 231px;
		    left: 292px;
	    }
	    .station-button4:nth-child(3) {
			top: 261px;
			left: 280px;
	    }
	    .station-button4:nth-child(4) {
			top: 287px;
			left: 278px;
	    }
	    .station-button4:nth-child(5) {
			top: 314px;
		    left: 289px;
	    }
	    .station-button4:nth-child(6) {
			top: 339px;
			left: 308px;
	    }
		.station-button4:nth-child(7) {
			top: 364px;
		    left: 312px;
	    }
		.station-button4:nth-child(8) {
			top: 381px;
			left: 367px;
	    }
		.station-button4:nth-child(9) {
			top: 424px;
			left: 313px;
	    }
		.station-button4:nth-child(10) {
			top: 408px;
			left: 407px;
	    }
		.station-button4:nth-child(11) {
			top: 442px;
		    left: 415px;
	    }
		.station-button4:nth-child(12) {
			top: 467px;
			left: 426px;
	    }
		.station-button4:nth-child(13) {
			top: 496px;
		    left: 424px;
	    }
		.station-button4:nth-child(14) {
			top: 467px;
			left: 347px;
	    }
		.station-button4:nth-child(15) {
			top: 508px;
			left: 366px;
	    }
		.station-button4:nth-child(16) {
			top: 495px;
			left: 297px;
	    }
		/* 동해선 */
		.station-button5 {
			position: absolute;         
            margin: 5px;
			z-index: 2;
        }
        .station-button5 button {
            font-size: 14px;
            font-weight: bold;
            background-color: rgb(122, 37, 92);			
            color: white;
            border: none;            
            transition: background-color 0.3s ease;
        }
        .station-button5 button:hover {
            background-color: rgb(86, 27, 65);
        }
		.station-button5:nth-child(2) {
			top: 237px;
			left: 292px;
	    }
	    .station-button5:nth-child(3) {
			top: 264px;
			left: 281px;
	    }
	    .station-button5:nth-child(4) {
			top: 291px;
		    left: 279px;
	    }
	    .station-button5:nth-child(5) {
			top: 318px;
			left: 289px;
	    }
	    .station-button5:nth-child(6) {
			top: 344px;
			left: 308px;
	    }
		.station-button5:nth-child(7) {
			top: 371px;
		    left: 313px;
	    }
		.station-button5:nth-child(8) {
			top: 387px;
			left: 366px;
	    }
		.station-button5:nth-child(9) {
			top: 434px;
			left: 313px;
	    }
		.station-button5:nth-child(10) {
			top: 414px;
		    left: 403px;
	    }
		.station-button5:nth-child(11) {
			top: 370px;
			left: 453px;
	    }
    </style>
</head>
<body>
    <div class="contanierMap">
        <div class="header">
            <h1><strong>SRT</strong></h1>
        </div>
		<div class="mapList">
			<nav>
				<div class="nav nav-tabs" id="nav-tab" role="tablist">
			    	<button class="nav-link active" id="nav-Gyeongbu-tab" data-bs-toggle="tab" data-bs-target="#nav-Gyeongbu" type="button" role="tab" aria-controls="nav-Gyeongbu" aria-selected="true">경부선</button>
			    	<button class="nav-link" id="nav-Honam-tab" data-bs-toggle="tab" data-bs-target="#nav-Honam" type="button" role="tab" aria-controls="nav-Honam" aria-selected="false">호남선</button>
					<button class="nav-link" id="nav-Jeolla-tab" data-bs-toggle="tab" data-bs-target="#nav-Jeolla" type="button" role="tab" aria-controls="nav-Jeolla" aria-selected="false">전라선</button>
					<button class="nav-link" id="nav-Gyeongjeon-tab" data-bs-toggle="tab" data-bs-target="#nav-Gyeongjeon" type="button" role="tab" aria-controls="nav-Gyeongjeon" aria-selected="false">경전선</button>
					<button class="nav-link" id="nav-Donghae-tab" data-bs-toggle="tab" data-bs-target="#nav-Donghae" type="button" role="tab" aria-controls="nav-Donghae" aria-selected="false">동해선</button>
				</div>
			</nav>
			
			<div class="tab-content" id="nav-tabContent">
				<!-- 경부선 -->
			    <div class="Gyeongbu tab-pane fade show active" id="nav-Gyeongbu" role="tabpanel" aria-labelledby="nav-Gyeongbu-tab" tabindex="0">
					<div>
						<div class="map">
							<img src="../img/mapGyeongbu.jpg" alt="경부선" class="mapGyeongbu">
						</div>
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="수서" data-value="NATH30000">수서역</button>
			            </div>
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="동탄" data-value="NATH30326">동탄역</button>
			            </div>  
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="평택지제" data-value="NATH30536">평택지제역</button>
			            </div>
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="천안아산" data-value="NATH10960">천안아산역</button>
			            </div>
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="오송" data-value="NAT050044">오송역</button>
			            </div>
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="대전" data-value="NAT011668">대전역</button>
			            </div>  
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="김천구미" data-value="NATH12383">김천구미역</button>
			            </div>
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="서대구" data-value="NAT013189">서대구역</button>
			            </div>
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="동대구" data-value="NAT013271">동대구역</button>
			            </div>
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="경주" data-value="NATH13421">경주역</button>
			            </div>
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="울산(통도사)" data-value="NATH13717">울산(통도사)역</button>
			            </div>
						<div class="station-button">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="부산" data-value="NAT014445">부산역</button>
			            </div>
					</div>	
				</div>
				<!-- 호남선 -->
				<div class="tab-pane fade" id="nav-Honam" role="tabpanel" aria-labelledby="nav-Honam-tab" tabindex="0">
					<div>
						<div class="map">
							<img src="../img/mapHonam.jpg" alt="호남선" class="mapHonam">
						</div>
						<div class="station-button2">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="수서" data-value="NATH30000">수서역</button>
			            </div>
						<div class="station-button2">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="동탄" data-value="NATH30326">동탄역</button>
			            </div>  
						<div class="station-button2">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="평택지제" data-value="NATH30536">평택지제역</button>
			            </div>
						<div class="station-button2">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="천안아산" data-value="NATH10960">천안아산역</button>
			            </div>
						<div class="station-button2">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="오송" data-value="NAT050044">오송역</button>
			            </div>
						<div class="station-button2">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="공주" data-value="NATH20438">공주역</button>
			            </div>
						<div class="station-button2">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="익산" data-value="NAT030879">익산역</button>
			            </div>
						<div class="station-button2">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="정읍" data-value="NAT031314">정읍역</button>
			            </div>
						<div class="station-button2">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="광주송정" data-value="NAT031857">광주송정역</button>
			            </div>
						<div class="station-button2">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="나주" data-value="NAT031998">나주역</button>
			            </div>
						<div class="station-button2">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="목포" data-value="NAT032563">목포역</button>
			            </div>
					</div>	
				</div>
				<!-- 전라선 -->
			    <div class="tab-pane fade" id="nav-Jeolla" role="tabpanel" aria-labelledby="nav-Jeolla-tab" tabindex="0">
					<div>
						<div class="map">
							<img src="../img/mapJeolla.jpg" alt="전라선" class="mapJeolla">
						</div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="수서" data-value="NATH30000">수서역</button>
			            </div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="동탄" data-value="NATH30326">동탄역</button>
			            </div>  
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="평택지제" data-value="NATH30536">평택지제역</button>
			            </div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="천안아산" data-value="NATH10960">천안아산역</button>
			            </div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="오송" data-value="NAT050044">오송역</button>
			            </div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="공주" data-value="NATH20438">공주역</button>
			            </div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="익산" data-value="NAT030879">익산역</button>
			            </div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="전주" data-value="NAT040257">전주역</button>
			            </div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="남원" data-value="NAT040868">남원역</button>
			            </div>  
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="곡성" data-value="NAT041072">곡성역</button>
			            </div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="구례구" data-value="NAT041285">구례구역</button>
			            </div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="순천" data-value="NAT041595">순천역</button>
			            </div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="여천" data-value="NAT041866">여천역</button>
			            </div>
						<div class="station-button3">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="여수EXPO" data-value="NAT041993">여수EXPO역</button>
			            </div>
					</div>
				</div>
				<!-- 경전선 -->
				<div class="tab-pane fade" id="nav-Gyeongjeon" role="tabpanel" aria-labelledby="nav-Gyeongjeon-tab" tabindex="0">
					<div>
						<div class="map">
							<img src="../img/mapGyeongjeon.jpg" alt="경전선" class="mapGyeongjeon">
						</div>	
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="수서" data-value="NATH30000">수서역</button>
			            </div>
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="동탄" data-value="NATH30326">동탄역</button>
			            </div>  
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="평택지제" data-value="NATH30536">평택지제역</button>
			            </div>
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="천안아산" data-value="NATH10960">천안아산역</button>
			            </div>
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="오송" data-value="NAT050044">오송역</button>
			            </div>
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="대전" data-value="NAT011668">대전역</button>
			            </div>  
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="김천구미" data-value="NATH12383">김천구미역</button>
			            </div>
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="서대구" data-value="NAT013189">서대구역</button>
			            </div>
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="동대구" data-value="NAT013271">동대구역</button>
			            </div>
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="밀양" data-value="NAT013841">밀양역</button>
			            </div>
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="진영" data-value="NAT880177">진영역</button>
			            </div>
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="창원중앙" data-value="NAT880281">창원중앙역</button>
			            </div>  
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="창원" data-value="NAT880310">창원역</button>
			            </div>
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="마산" data-value="NAT880345">마산역</button>
			            </div>
						<div class="station-button4">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="진주" data-value="NAT881014">진주역</button>
			            </div>
					</div>
				</div>
				<!-- 동해선 -->
				<div class="tab-pane fade" id="nav-Donghae" role="tabpanel" aria-labelledby="nav-Donghae-tab" tabindex="0">
					<div>
						<div class="map">
							<img src="../img/mapDonghae.jpg" alt="동해선" class="mapDonghae">
						</div>	
						<div class="station-button5">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="수서" data-value="NATH30000">수서역</button>
			            </div>
						<div class="station-button5">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="동탄" data-value="NATH30326">동탄역</button>
			            </div>  
						<div class="station-button5">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="평택지제" data-value="NATH30536">평택지제역</button>
			            </div>
						<div class="station-button5">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="천안아산" data-value="NATH10960">천안아산역</button>
			            </div>
						<div class="station-button5">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="오송" data-value="NAT050044">오송역</button>
			            </div>
						<div class="station-button5">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="대전" data-value="NAT011668">대전역</button>
			            </div>  
						<div class="station-button5">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="김천구미" data-value="NATH12383">김천구미역</button>
			            </div>
						<div class="station-button5">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="서대구" data-value="NAT013189">서대구역</button>
			            </div>
						<div class="station-button5">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="동대구" data-value="NAT013271">동대구역</button>
			            </div>
						<div class="station-button5">
			                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="포항" data-value="NAT8B0351">포항역</button>
			            </div>
					</div>
				</div>
			</div>
		</div>
    </div>
	<script>
		function setParentText(buttonElement) {
		    if (opener && !opener.closed) { // 부모 창이 열려 있는지 확인
		        var parentInput = opener.document.getElementById("arrplacename");
		        var hiddenField = opener.document.getElementById("arrPlaceIdHidden");
		        
		        if (parentInput) {
		            parentInput.value = buttonElement.getAttribute('value'); // 버튼의 value 값을 부모 창의 입력 필드에 설정
		        }
		        
		        if (hiddenField) {
		            hiddenField.value = buttonElement.getAttribute('data-value'); // 버튼의 data-value 값을 hiddenField에 설정
		        }
		        
		        console.log('Selected data-value:', buttonElement.getAttribute('data-value')); // 클릭된 버튼의 data-value를 콘솔에 출력
		        
		        window.close(); // 자식 창 닫기
		    } else {
		        alert("부모 창을 찾을 수 없습니다.");
		    }
		}
	</script>
</body>
</html>