<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>회원가입</title>
<style>
    #wrapper {
        text-align: center;
        width: 1200px;
        margin: auto;
        padding: 20px;
		overflow: hidden;
    }
    
    .hrline {
        position: relative;
        right: -15%;
        width: 70%;
    }
    
    .centerTable td {
        padding-bottom: 12px;
        vertical-align: middle;
    }
    
    #sample6_postcode_user, 
    #sample6_address_user, 
    #sample6_detailAddress_user, 
    #sample6_extraAddress_user {
        margin-bottom: 8px;
    }
	
	#sample6_address_user{
		position: relative;
		left: 107px;
		margin-bottom: -10px;
	}

	#sample6_detailAddress_user{
		margin-top: 14px;
	}

    .alert {
        margin-bottom: 20px;
    }
	
	.star{
		color: red;
	}
</style>
<script>
	function checkForm(event) {
	    var userpwd = document.getElementById("userpwd");
	    var checkuserpwd = document.getElementById("checkuserpwd");
	    var username = document.getElementById("username");
	    var userbirth = document.getElementById("userbirth");
	    var usertel = document.getElementById("usertel");
	    var parenttel = document.getElementById("parenttel");
	    var usermail = document.getElementById("usermail");
	    var postcode = document.getElementById("sample6_postcode_user");
	    var address = document.getElementById("sample6_address_user");
	    var detailAddress = document.getElementById("sample6_detailAddress_user");

		// 필수 입력 항목 검사
		if (!userpwd.value || !checkuserpwd.value || !username.value || !userbirth.value || !usertel.value || !parenttel.value || !postcode.value || !address.value || !detailAddress.value) {
		    alert("모든 필수 항목을 입력해주세요.");
		    return false;
		}

	    // 비밀번호와 비밀번호 확인 일치 여부 검사
	    if (userpwd.value !== checkuserpwd.value) {
	        alert("비밀번호가 일치하지 않습니다.");
	        return false;
	    }
	
	    // 비밀번호 복잡성 검사 (8자리 이상, 특수문자 포함)
	    var pwdPattern = /^(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;
	    if (!pwdPattern.test(userpwd.value)) {
	        alert("비밀번호는 8자리 이상이며, 특수문자를 포함해야 합니다.");
	        return false;
	    }
	
	    // 휴대폰 번호 형식 검사
	    var phonePattern = /^010-\d{4}-\d{4}$/;
	    if (!phonePattern.test(usertel.value) || !phonePattern.test(parenttel.value)) {
	        alert("휴대폰 번호는 010-0000-0000 형식이어야 합니다.");
	        return false;
	    }
	
	    // 이메일 형식 검사
	    if (usermail && usermail.value !== "") {
	        var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
	        if (!emailPattern.test(usermail.value)) {
	            alert("올바른 이메일 형식을 입력해주세요.");
	            return false;
	        }
	    }

	    // 만 14세 미만 여부 확인
		var today = new Date();
		var birthDate = new Date(userbirth.value);
		if (isNaN(birthDate)) {
		    alert("올바른 생년월일을 입력해주세요.");
		    return false;
		}

		var age = today.getFullYear() - birthDate.getFullYear();
		var monthDiff = today.getMonth() - birthDate.getMonth();

		if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
		    age--;
		}

		if (age >= 14) {
		    alert("만 14세 이상 사용자는 가입할 수 없습니다. 만 14세 미만 사용자만 가입 가능합니다.");
		    return false;
		}

		return true;
	}
</script>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
	<jsp:include page="header.jsp" />
	<jsp:include page="sidemenu.jsp" />
	<div id="wrapper">
        
        <c:if test="${not empty errorMessage}">
            <div class="alert alert-danger" role="alert">
                ${errorMessage}
            </div>
        </c:if>
        
        <form method="post" name="update" action="${contextPath}/finishSignup.do" onsubmit="return checkForm();">
            <h1>회원가입</h1>
            <br><hr class="hrline">
            <span class="star">*</span>는 필수 입력 항목입니다.
            <table align="center" class="centerTable">
                <tr>
                    <td>비밀번호<span class="star">*</span></td>
                    <td ><input type="password" name="userpwd" id="userpwd"></td>
                </tr>
                <tr>
                    <td>비밀번호 확인<span class="star">*</span></td>
                    <td ><input type="password" name="checkuserpwd" id="checkuserpwd"></td>
                </tr>
                <tr>
                    <td>이름<span class="star">*</span></td>
                    <td ><input type="text" name="username" id="username"></td>
                </tr>
                <tr>
                    <td>생년월일<span class="star">*</span></td>
                    <td ><input type="date" name="userbirth" id="userbirth"></td>
                </tr>
                <tr>
                    <td>성별</td>
                    <td >
                        <select name="usergender" id="usergender">
                            <option value="남성">남성</option>
                            <option value="여성">여성</option>
                        </select>
                    </td>
                </tr>			
                <tr>
                    <td>휴대폰 번호<span class="star">*</span></td>
                    <td ><input type="text" name="usertel" id="usertel"></td>
                </tr>
                <tr>
                    <td>보호자 휴대폰 번호<span class="star">*</span></td>
                    <td ><input type="text" name="parenttel" id="parenttel"></td>
                </tr>
                <tr>
                    <td>이메일</td>
                    <td ><input type="text" name="usermail" id="usermail"></td>
                </tr>
                <tr>
                    <td>주소<span class="star">*</span></td>
                    <td><jsp:include page="userZip.jsp" /></td>								
                </tr>
                
                <input type="hidden" name="level" value="user">
            </table>
            
            <div style="text-align: center;">
                <button type="submit" class="btn btn-success">가입하기</button>
                <button type="reset" class="btn btn-secondary">다시입력</button>
            </div>
        </form>
    </div>
	<jsp:include page="footer.jsp" />
</body>
</html>