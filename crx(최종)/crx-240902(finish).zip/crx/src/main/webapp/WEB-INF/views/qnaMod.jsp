<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
    Integer userid = (Integer) session.getAttribute("userid");
%>
<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta charset="UTF-8">
    <title>Q&A</title>
    <style>
        .con {
            margin:auto;
            width: 1200px;
        }
        .qnaModForm {
            margin: 20px;
            border: 1px solid #ccc;
            padding: 30px;
            border-radius: 15px;
        }
        .button {
            margin: 10px;
            text-align:center;
        }
        button {
            width: auto;
            font-size: 15px;
            border: 0;
            outline: 1.5px gray solid;
            border-radius: 5px;
            padding-left: 10px;
        }
        button:active {
            background-color: rgb(84, 130, 53);
        }
    </style>
    <script>
        function checkForm() {
            var titleChk = document.Chkfm.qtitle.value.trim();
            var contentChk = document.Chkfm.qcontent.value.trim();
            
            if (titleChk === "") {
                alert("제목이 입력되지 않았습니다. 제목을 입력해 주세요.");
                document.Chkfm.qtitle.focus();
                return false;
            }
            
            if (contentChk === "") {
                alert("내용이 입력되지 않았습니다. 내용을 입력해 주세요.");
                document.Chkfm.qcontent.focus();
                return false;
            }
            return confirm("수정하시겠습니까?");
        }   
    </script>
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />
    <div class="con">
        <h1>Q&A</h1>
        <br>
        <form action="${contextPath}/qnaUpdate.do" method="post" name="Chkfm" onsubmit="return checkForm()">
            <input type="hidden" name="qno" value="${qnaMod.qno}">
            <div class="qnaModForm">
                <div class="qnaMod">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" id="qtitle" name="qtitle" value="${qnaMod.qtitle}" placeholder="qtitle" autofocus>
                        <label for="qtitle">변경할 제목을 입력해주세요</label>
                    </div>
                </div>
                <div class="form-floating">
                    <textarea class="form-control" id="qcontent" name="qcontent" placeholder="qcontent" style="height: 350px">${qnaMod.qcontent}</textarea>
                    <label for="qcontent">변경할 내용을 입력해주세요</label>
                </div>                     
            </div>
            <div class="button">
                <button type="submit" class="btn btn-success btn-sm" id="qnaRegist-btn">수정</button>
                <button type="button" class="btn btn-secondary btn-sm" id="qnaReset-btn" onclick="location.href='${contextPath}/qnaDetail.do?qno=${qnaMod.qno}'">취소</button>
            </div>          
        </form>
    </div>
    <jsp:include page="footer.jsp" />
</body>
</html>
