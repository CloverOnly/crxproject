<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
	Integer userid = (Integer) session.getAttribute("userid");
	String username = (String) session.getAttribute("username");
%>
<!DOCTYPE html>
<html>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<meta charset="UTF-8">
	<title>공지사항</title>
	<style>
        .con {
            margin: auto;
            width: 1200px;
        }
        .notice-table {
            margin: auto;
            width: 100%;
            max-width: 1200px;
            border-radius: 5px;
            border-collapse: collapse;
            border-top: none;
            table-layout: fixed; /* 테이블 레이아웃 고정 */
        }
        .header {
            background-color: rgb(226, 240, 217);
            text-align: center;
        }
        .notice-table td, .notice-table th {
            height: 30px;
            font-size: 14px;
            padding: 10px;
            text-align: center;
        }
        .noticeNo {
            width: 10%; /* 번호 열의 너비 고정 */
        }
        .noticeTitle {
            width: 50%; /* 제목 열의 너비 고정 */
        }
        .noticeWriter {
            width: 15%; /* 작성자 열의 너비 고정 */
        }
        .noticeRegDate {
            width: 15%; /* 등록일자 열의 너비 고정 */
        }
        .noticeHit {
            width: 10%; /* 조회수 열의 너비 고정 */
        }
        .body {
            text-align: center;
        }
        .body .title {
            text-align: left;
        }
        button {
            width: auto;
            font-size: 15px;
            border: 0;
            outline: 1.5px gray solid;
            border-radius: 5px;
            padding-left: 10px;
        }
        .atag {
            text-decoration: none;
        }
        .atag:hover {
            text-decoration: underline;
        }
        .typeBox {
            height: 40px;
            font-size: 16px;
        }
        .inputSearch {
            width: 200px;
            height: 40px;
            font-size: 16px;            
        }
        .submitBtn {
            font-size: 16px;
            width: 60px;
            height: 40px;
        }
        .submitBtn:hover {
            background-color: rgb(21, 115, 71) !important;
        }
    </style>
</head>
<body>
	<jsp:include page="header.jsp" />
	<jsp:include page="sidemenu.jsp" />
	<div class="con">
		<h1>공지사항</h1>
		<br>
		<!-- search -->
		<div class="position-relative m-3 notice-search">
		    <form action="${contextPath}/noticeList.do" method="get" id="search" name="search" class="d-flex align-items-center">
		        <select class="form-select me-2" id="searchType" name="searchType" style="width: 150px;">
		            <option value="title" ${search.searchType == 'title' ? 'selected' : ''}>제목</option>
		            <option value="writer" ${search.searchType == 'writer' ? 'selected' : ''}>작성자</option>
		            <option value="content" ${search.searchType == 'content' ? 'selected' : ''}>내용</option>
		        </select>
		        <input type="text" class="form-control me-2" name="keyword" value="${search.keyword}" placeholder="검색어를 입력해주세요." style="width: 300px;">
		        <button type="submit" class="btn btn-success">검색</button>
		    </form>
		</div>	
		
		<table class="notice-table">
		    <tr class="header text-center">
		        <td class="noticeNo">번호</td>
		        <td class="noticeTitle">제목</td>
		        <td class="noticeWriter">작성자</td>
		        <td class="noticeRegDate">등록일자</td>
		        <td class="noticeHit">조회수</td>
		    </tr>
		    <c:forEach items="${noticeList}" var="notice">
		        <tr class="text-center">
		            <td>${notice.nono}</td>
		            <td class="text-start"><a href="${contextPath}/noticeDetail.do?nono=${notice.nono}" class="atag text-black">${notice.notitle}</a></td>
		            <td>${notice.memname}</td>
		            <td>${notice.nodate}</td>
		            <td>${notice.nohit}</td>
		        </tr>
		    </c:forEach>
		</table>
		<br>
		
		<!-- pagination -->
		<div id="paginationBox" class="pagination1">
		    <ul class="pagination justify-content-center">
		        <!-- 처음 -->
		        <li class="page-item ${pagination.page == 1 || pagination.totalPage == 0 ? 'disabled' : ''}">
		            <a class="page-link btn btn-success mx-1" href="?page=1&searchType=${search.searchType}&keyword=${search.keyword}">처음</a>
		        </li>

		        <!-- 이전 -->
		        <li class="page-item ${pagination.page == 1 || pagination.totalPage == 0 ? 'disabled' : ''}">
		            <a class="page-link btn btn-success mx-1" href="?page=${pagination.page - 1}&searchType=${search.searchType}&keyword=${search.keyword}">이전</a>
		        </li>

		        <!-- 페이지 번호 -->
				<c:forEach begin="${pagination.startPage}" end="${pagination.endPage}" var="i">
				    <li class="page-item ${pagination.page == i ? 'active' : ''}">
				        <c:if test="${pagination.page == i}">
				            <!-- 현재 페이지인 경우 비활성화 및 스타일 변경 -->
				            <a class="page btn btn-secondary mx-1 disabled" href="#">${i}</a>
				        </c:if>
				        <c:if test="${pagination.page != i}">
				            <!-- 현재 페이지가 아닌 경우 -->
				            <a class="page btn btn-success mx-1" href="?page=${i}&searchType=${search.searchType}&keyword=${search.keyword}">${i}</a>
				        </c:if>
				    </li>
				</c:forEach>

		        <!-- 다음 -->
		        <li class="page-item ${pagination.page == pagination.totalPage || pagination.totalPage == 0 ? 'disabled' : ''}">
		            <a class="page-link btn btn-success mx-1" href="?page=${pagination.page + 1}&searchType=${search.searchType}&keyword=${search.keyword}">다음</a>
		        </li>

		        <!-- 끝 -->
		        <li class="page-item ${pagination.page == pagination.totalPage || pagination.totalPage == 0 ? 'disabled' : ''}">
		            <a class="page-link btn btn-success mx-1" href="?page=${pagination.totalPage}&searchType=${search.searchType}&keyword=${search.keyword}">끝</a>
		        </li>
		    </ul>
		</div>

		<!-- 등록 Btn if test 조건에 맞는 경우만 출력 -->
		<div>	
			<c:if test="${(divname == '고객안내' || divname == '통합관리') && (level == 'master' || level == 'admin')}">
				<button class="btn btn-success buttonAdd" onclick="location.href='${contextPath}/noticeAdd.do?userid=${userid}'">등록</button>
			</c:if>
		</div>
	</div>
	<jsp:include page="footer.jsp" />
</body>
</html>