<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
    Integer userid = (Integer) session.getAttribute("userid");
%>
<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <meta charset="UTF-8">
    <title>유실물 안내</title>
    <style>
        .con {
            margin:auto;
            width: 100%;
            max-width: 1200px;
        }
        .lost-table {
            margin: auto;
            width: 100%;
            border-radius: 5px;
            border-collapse: collapse;
            border-top: none;
        }
        .header {
            background-color: rgb(226, 240, 217);
            text-align: center;
        }
        .lost-table td, .lost-table th {
            height: 30px;
            font-size: 14px;
        }
        .lostDetail {
            width: 100%;
            margin: 0 auto;
        }
        .lostHeader {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            border-top: 2px solid green;
            border-bottom: 2px solid green;
        }
        .attachment {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            border-bottom: 2px solid green;
            margin-bottom: 15px;
            min-height: 50px;
        }
        .attachment div {
            display: flex;
            align-items: center;
        }
        .lostContent {
            padding: 10px 20px;
            border-bottom: 2px solid green;
            margin-bottom: 15px;
            min-height: 100px;
            white-space: pre-wrap;
        }
        .buttonSet {
            display: flex;
            justify-content: space-between;
            padding: 10px 20px;
        }
        .buttonSet .left-buttons, .buttonSet .right-buttons {
            display: flex;
            gap: 10px;
        }
        .atag {
            text-decoration: none;
        }
    </style>
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />
    <div class="con">
        <h1>유실물 안내</h1>
        <br>
        <div class="lostDetail">
            <div class="lostHeader">
                <div>
                    <span class="bg-success-subtle">&nbsp품목&nbsp</span>
                    <span>${lostDetail.losttitle}</span>
                </div>
                <div>
                    <span class="bg-success-subtle">&nbsp등록일자&nbsp</span>
                    <span>${lostDetail.lostdate}</span>
                </div>
            </div>
            <div class="attachment">
                <div>
                    <span class="bg-success-subtle">&nbsp보관장소&nbsp</span>&nbsp
                    <span>${lostDetail.lostplace}</span>
                </div>
            </div>
            <div class="lostContent">
                <p>${lostDetail.lostcontent}</p>
            </div>
        </div>
        <div class="buttonSet">
            <div class="left-buttons">
                <c:if test="${(divname == '고객안내' || divname == '통합관리') && (level == 'master' || level == 'admin')}">
                    <form action="/lostDelete.do?lostno=${lostDetail.lostno}" method="get" onsubmit="return confirm('정말로 삭제하시겠습니까?');" style="display:inline;">
                        <input type="hidden" name="lostno" value="${lostDetail.lostno}">
                        <button type="submit" class="btn btn-danger">삭제</button>
                    </form>
                </c:if>
            </div>
            <div class="right-buttons">
                <button type="button" class="btn btn-success" onclick="location.href='${contextPath}/lostList.do'">목록</button>
            </div>
        </div>
    </div>
    <jsp:include page="footer.jsp" />
</body>
</html>
