<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>

<%
    Integer userId = (Integer) session.getAttribute("userid");
    String userid = (userId != null) ? userId.toString() : "Guest";
%>

<!DOCTYPE html>
<html>
<head>
<title>관광열차</title>
<style>
    .title{
        position: relative;
        margin-left: 19%;
        margin-bottom: 50px;
    }
    .tourregister input{
        position: relative;
        left: 70%;
        margin:10px;
    }
    .tourregister input:active{
        background-color: green;
    }
    .tourtable {
        margin: auto;
        width: 1200px;
        border-radius: 5px;
        border-collapse: collapse;
        border-top: none;
    }
    .tourheader {
        background-color: rgb(226, 240, 217);
        text-align: center;
    }
    .tourtable tr {
        border-bottom: 1px lightgray solid; 
        height: 30px;
        font-size: 14px;
    }
    .tourlist a{
        text-decoration: none;
        color: black;
    }
    .tourlist a:hover{
        color: green;
    }
    .dlttrain{
        margin: 20px 20px 20px 0px;
        width:200px;
        height:120px;
        background-size: cover;
        border:0px;
    }
    .dlttrain:hover{
        transform: scale(1.2);
    }
    .tourlist img:hover{
        transform: scale(1.2);
    }
</style>
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />
    
    <div class="title">
        <h1>관광열차</h1>
    </div>
    
	<table class="tourtable">
	    <thead>
	        <tr class="tourheader">
	            <td class="local" style="width: 200px;"><b>상품</b></td>
	            <td class="locallist"><b>상품명</b></td>
	            <td></td>
	        </tr>
	    </thead>
	    <tbody>
			<c:forEach var="tour" items="${tourList}" varStatus="status">
			    <c:set var="filePath" value="${fn:replace(tour.file1, '\\\\', '/')}"/>
			    <c:set var="file1" value="${fn:replace(filePath, 'src/main/webapp/', '../')}"/>
				
			    <tr class="tourlist">
			        <td>
			            <div class="dlttrain" style="background-image: url('${file1}');" 
			                 onclick="window.open('${contextPath}/tourDetail.do?tournum=${tournum}&index=${status.index}&userid=<%= userid %>', '_blank', 'width=1200, height=1000, top=50, left=50, scrollbars=yes')"></div>
			        </td>
			        <td>
			            <a href="javascript:;" onclick="window.open('${contextPath}/tourDetail.do?tournum=${tour.tournum}&index=${status.index}&userid=<%= userid %>', '_blank', 'width=1200, height=1000, top=50, left=50, scrollbars=yes')">
			                <h2>${tour.tourtitle}</h2>${tour.tourcomment}
			            </a>
			        </td>
			        <td>
			            <a href="javascript:;" onclick="window.open('${contextPath}/tourDetail.do?tournum=${tour.tournum}&index=${status.index}&userid=<%= userid %>', '_blank', 'width=1200, height=1000, top=50, left=50, scrollbars=yes')">
			                <img src="../img/search.png" alt="돋보기" style="width:50px">
			            </a>
			        </td>
			    </tr>
			</c:forEach>
	    </tbody>
	</table>
<c:if test="${(divname == '여행상품' || divname == '통합관리') && (level == 'master' || level == 'admin')}">
    <div class="tourregister">
        <input type="button" class="btn btn-success" value="등록" onclick="location.href='tourRegister.do';">
    </div>
</c:if>

<jsp:include page="footer.jsp" />
</body>
</html>
