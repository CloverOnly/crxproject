<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<%-- 현재 시간 설정 --%>
<%
    String currentDateTime = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm").format(new java.util.Date());
    pageContext.setAttribute("currentDateTime", currentDateTime);
%>

<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<title>예매관리</title>
<style>
	.all{
		width: 1200px;
		margin: 0 auto;  <!-- 중앙 정렬 -->
	}
	.search{
		text-align: center;
	}
	.minititle a{
		color: #000000;
	}
	.guide{
		width: 1200px;
		height: auto;
		background-color: #f8f8f8;
		margin: 2px;
		padding: 5px;
		font-size: 12px;
	}
	.guidep{
		margin-bottom: 3px;
	}
	table, th, td {
	    border: 2px solid white;
	    border-collapse: collapse;
		
	}
	td{
		background-color: rgb(226, 240, 217);
	}
	th{
		background-color: #f8f8f8;
	}
</style>
<script>
	function changePage() {
		const selectedOption = document.querySelector('input[name="reservationType"]:checked').value;
		if (selectedOption === 'train') {
			location.href = 'mgmtTrain.do?userid=${userid}';
		} else if (selectedOption === 'tour') {
			location.href = 'mgmtTour.do?userid=${userid}';
		}
	}
</script>
</head>
<body>	 
<jsp:include page="header.jsp" />
<div class="all">
	<div class="maintitle">
		<h1>예매관리</h1>
		<hr>
	</div>
	
	<!-- 소제목 -->
	<div>
		<br>
		<ul class="nav nav-tabs">
			<li class="minititle nav-item">
				<a class="nav-link active bg-light" aria-current="page" href="mgmtTrain.do?userid=${userid}">예매관리</a>
			</li>
			<li class="minititle nav-item">
				<a class="nav-link" href="usageTrain.do?userid=${userid}">이용내역</a>
			</li>
		</ul>
	</div>
	<!-- 설명 -->
	<div class="guide">
		<p class="guidep">${username} 고객님의 발권내역은 아래와 같습니다.</p>
		<p class="guidep">승차시간이 지난 경우 환불이 불가하며, 미탑승으로 환불이 필요시 고객센터로 연락부탁드립니다.</p>
	</div>
	<br>
	
	<!-- 라디오 버튼 추가 -->
	<div class="text-center">
		<label>
			<input type="radio" name="reservationType" value="train" onchange="changePage()"> 기차예매 조회
		</label>
		&nbsp;
		&nbsp;
		<label>
			<input type="radio" name="reservationType" value="tour" checked onchange="changePage()"> 관광상품 조회
		</label>
	</div>
	<br>
	<!-- 테이블 -->
	<div>
		<table border="1" width ="1200" align = "center">
		    <tr align = "center">
					<td>승차일</td>
					<td>상품명</td>
					<td>상품번호</td>
					<td>예약인원</td>
					<td>결제금액</td>
					<td>결제번호</td>
					<td>환불</td>
		    </tr>
			<c:forEach var="Tour" items="${mgmtTour}">
			    <c:set var="tourDateTime" value="${Tour.tourdatepay} 14:00"/>
			    <c:if test="${currentDateTime le tourDateTime}">
			        <tr align = "center">
			            <th>${Tour.tourdatepay}</th>
			            <th>${Tour.tourname}</th>
			            <th>${Tour.tourno}</th>
			            <th>${Tour.count}</th>
			            <th>${Tour.coin}</th>
			            <th>${Tour.apply_num}</th>
			            <th>
			                <c:choose>
			                    <c:when test="${Tour.refund == null}">
			                        <c:if test="${currentDateTime lt tourDateTime}">
			                            <button type="button" class="btn btn-danger btn-sm" onclick="location.href='refundTour.do?apply_num=${Tour.apply_num}'">환불</button>
			                        </c:if>
			                    </c:when>
			                    <c:otherwise>
			                        환불완료
			                    </c:otherwise>
			                </c:choose>
			            </th>                                    
			        </tr>
			    </c:if>
			</c:forEach>

		    </tr>
		</table>
	</div>			
</div>  
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<jsp:include page="sidemenu.jsp" />
<jsp:include page="footer.jsp" />
</body>
</html>
