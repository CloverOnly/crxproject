<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
    Integer userid = (Integer) session.getAttribute("userid");
%>
<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <meta charset="UTF-8">
    <title>공지사항</title>
    <style>
        .con {
            margin:auto;
            width: 100%;
            max-width: 1200px;
        }
        .notice-table {
            margin: auto;
            width: 100%;
            border-radius: 5px;
            border-collapse: collapse;
            border-top: none;
        }
        .header {
            background-color: rgb(226, 240, 217);
            text-align: center;
        }
        .notice-table td, .notice-table th {
            height: 30px;
            font-size: 14px;
        }
        .noticeDetail {
            width: 100%;
            margin: 0 auto;
        }
        .noticeHeader {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            border-top: 2px solid green;
            border-bottom: 2px solid green;
        }
        .attachment {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            border-bottom: 2px solid green;
            margin-bottom: 15px;
            min-height: 50px; /* 높이를 지정하여 가운데 정렬 효과 */
        }
        .attachment div {
            display: flex;
            align-items: center; /* 높이 가운데 정렬 */
        }
        .noticeContent {
            padding: 10px 20px;
            border-bottom: 2px solid green;
            margin-bottom: 15px;
            min-height: 100px;
            white-space: pre-wrap;
        }
        .buttonSet {
            display: flex;
            justify-content: space-between;
            padding: 10px 20px;
        }
        .buttonSet .left-buttons, .buttonSet .right-buttons {
            display: flex;
            gap: 10px;
        }
		.atag {
			text-decoration: none;
			color: green;
		}
    </style>
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />
    <div class="con">
        <h1>공지사항</h1>
        <br>
        <div class="noticeDetail">
            <div class="noticeHeader">
                <div>
                    <span class="bg-success-subtle">&nbsp제목&nbsp</span>
                    <span>${noticeDetail.notitle}</span>
                </div>
                <div>
                    <span class="bg-success-subtle">&nbsp등록일자&nbsp</span>
                    <span>${noticeDetail.nodate}</span>
                </div>
            </div>
            <c:if test="${noticeDetail.filename != null}">
                <div class="attachment">
                    <div>
                        <span class="bg-success-subtle">&nbsp첨부파일&nbsp</span>&nbsp
                         <a href="/downloadFile?filename=${fn:escapeXml(noticeDetail.filename)}" class="atag">${noticeDetail.filename}</a>
                    </div>
                </div>
            </c:if>
            <div class="noticeContent">
                <p>${noticeDetail.nocontent}</p>
            </div>
        </div>
        <div class="buttonSet">
            <div class="left-buttons">
                <c:if test="${(divname == '고객안내' || divname == '통합관리') && (level == 'master' || level == 'admin')}">
                    <button type="button" class="btn btn-success" onclick="location.href='${contextPath}/noticeMod.do?nono=${noticeDetail.nono}'">수정</button>
                    <form action="/noticeDelete.do?nono=${noticeDetail.nono}" method="get" onsubmit="return confirm('정말로 삭제하시겠습니까?');" style="display:inline;">
                        <input type="hidden" name="nono" value="${noticeDetail.nono}">
                        <button type="submit" class="btn btn-danger">삭제</button>
                    </form>
                </c:if>
            </div>
            <div class="right-buttons">
                <button type="button" class="btn btn-success" onclick="location.href='${contextPath}/noticeList.do'">목록</button>
            </div>
        </div>
    </div>
    <jsp:include page="footer.jsp" />
</body>
</html>
