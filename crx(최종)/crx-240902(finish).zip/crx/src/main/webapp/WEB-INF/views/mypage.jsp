<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!DOCTYPE html>
<html>
<head>
<title>마이페이지</title>
<style>
    .box{
        width:800px;
        margin:auto;
    }
    
    .table{
        border-bottom:1px dotted gray;
    }
    button{
        color: black !important;
    }
	.leveltable {
	    width: 100%;
	    border-collapse: collapse;
	}

	.leveltable th, .leveltable td {
	    padding: 8px;
	    text-align: center;
	    border-bottom: 1px solid #ddd;
	    white-space: nowrap; /* 줄 바꿈 없이 한 줄로 유지 */
	}

	.leveltable thead {
	    background-color: #f2f2f2;
	}

	.leveltable td select {
	    width: 100%;
	    padding: 6px;
	    border: 1px solid #ddd;
	    border-radius: 4px;
	    background-color: #fff;
	    box-sizing: border-box; /* 패딩을 포함하여 전체 너비를 계산 */
	}

	.division{
		display: flex;
		justify-content: space-around;
	}
	.division a{
		color: black;
		text-decoration: none;
		border-bottom: 2px solid white;		
		
	}
	.division a:hover{
		border-bottom: 2px solid black;		
	}

</style>
<script>
	function confirmUnregister() {
	    return confirm("정말로 회원 탈퇴 하시겠습니까?");
	}
	
	function toggleTextarea() {
	    var selectElement = document.getElementById("selectlist");
	    var textareadisplay = document.getElementById("textareadisplay");
	    var textarea = document.getElementById("textarea");

	    if (selectElement.value === "기타(개선의견)") {
	        textareadisplay.style.display = "table-row"; // 테이블 로우로 변경
	        textarea.disabled = false; // 텍스트영역 활성화
	    } else {
	        textareadisplay.style.display = "none"; // 테이블 로우 숨기기
	        textarea.disabled = true; // 텍스트영역 비활성화
	    }
	}

	// 페이지 로드 시 초기 설정 및 이벤트 핸들러 설정
	document.addEventListener("DOMContentLoaded", function() {
	    toggleTextarea(); // 초기 설정을 위해 함수 호출

	    // 정보 수정 성공 시 알림
		if ("${updateSuccess}" === "true") {
            alert("정보가 수정되었습니다.");
        }
		
		// 직원 등록 성공 시 알림
        if ("${registerSuccess}" === "true") {
            alert("직원이 등록되었습니다.");
        }

	    // 비밀번호 변경 결과 메시지 알림
		var result = "${pwdChangeResult}";
       if (result !== "") {
           alert(result);
       }

	    // 확인 대화상자 설정
	    var confirmForms = document.querySelectorAll('form.updateConfirm');
	    confirmForms.forEach(function(form) {
	        form.addEventListener('submit', function(event) {
	            if (!confirm('정말로 변경하시겠습니까?')) {
	                event.preventDefault();
	            }
	        });
	    });

	    // 탭 활성화
		var urlParams = new URLSearchParams(window.location.search);
	    var tab = urlParams.get('tab');
	    if (tab) {
	        var tabElement = document.querySelector('[data-bs-target="#' + tab + '-tab-pane"]');
	        if (tabElement) {
	            var tabInstance = new bootstrap.Tab(tabElement);
	            tabInstance.show();
	        }
	    }

	    // 정보 수정 버튼 클릭 시 유효성 검사 및 폼 제출
	    $("#updateBtn").on("click", function() {
	        if (!validateForm()) {
	            return false; // 유효성 검사 실패 시 폼 제출 차단
	        }

	        var updateForm = $("#updateForm");
	        updateForm.attr("action", "updateUserInfo.do");
	        updateForm.attr("method", "post");

	        updateForm.submit(); // 유효성 검사 통과 후 폼 제출
	    });
	});

	// 정보수정 유효성 검사 함수
	function validateForm() {
	    var username = document.getElementsByName("username")[0] || document.getElementsByName("memname")[0];
	    var userbirth = document.getElementsByName("userbirth")[0] || document.getElementsByName("membirth")[0];
	    var usertel = document.getElementsByName("usertel")[0] || document.getElementsByName("memtel")[0];
	    var usermail = document.getElementsByName("usermail")[0];
	    var useradd = document.getElementsByName("useradd")[0] || document.getElementsByName("memadd")[0];
	    
	    // 이름 유효성 검사
	    if (username.value.trim() === "") {
	        alert("이름을 입력하세요.");
	        return false;
	    }

	    // 생년월일 유효성 검사
	    var birthPattern = /^\d{4}-\d{2}-\d{2}$/;
	    if (!birthPattern.test(userbirth.value)) {
	        alert("생년월일 형식이 올바르지 않습니다. YYYY-MM-DD 형태로 입력하세요.");
	        return false;
	    }

	    // 전화번호 유효성 검사
	    var phonePattern = /^\d{3}-\d{4}-\d{4}$/;
	    if (!phonePattern.test(usertel.value)) {
	        alert("전화번호 형식이 올바르지 않습니다. 000-0000-0000 형태로 입력하세요.");
	        return false;
	    }

	    // 이메일 유효성 검사
	    if (usermail && !/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/.test(usermail.value)) {
	        alert("이메일 형식이 올바르지 않습니다.");
	        return false;
	    }


	    return true;
	}

	// 비밀번호 변경 유효성 검사 함수
	function validatePwdForm() {
	    var currentpwd = document.getElementsByName("currentpwd")[0].value;
	    var newpwd = document.getElementsByName("newpwd")[0].value;
	    var confirmpwd = document.getElementsByName("confirmpwd")[0].value;

	    // 현재 비밀번호 공백 확인
	    if (currentpwd === "") {
	        alert("현재 비밀번호를 입력하세요.");
	        return false;
	    }

	    // 새 비밀번호와 새 비밀번호 확인의 일치 여부 확인
	    if (newpwd !== confirmpwd) {
	        alert("새 비밀번호와 새 비밀번호 확인이 일치하지 않습니다.");
	        return false;
	    }

	    // 비밀번호 형식 검사 (예: 최소 8자 이상, 특수문자 포함)
	    var pwdPattern = /^(?=.*[!@#$%^&*(),.?":{}|<>]).{8,}$/;
	    if (!pwdPattern.test(newpwd)) {
	        alert("비밀번호는 최소 8자 이상이어야 하며, 특수문자를 포함해야 합니다.");
	        return false;
	    }

	    return true;
	}
</script>
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />

    <div class="box mt-5">
        <div class="row">
            <div class="col-md-3">
                <ul class="nav flex-column nav nav-underline" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="mypage-tab" data-bs-toggle="pill" data-bs-target="#mypage-tab-pane" type="button" role="tab" aria-controls="mypage-tab-pane" aria-selected="true">개인정보</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="usermod-tab" data-bs-toggle="pill" data-bs-target="#usermod-tab-pane" type="button" role="tab" aria-controls="usermod-tab-pane" aria-selected="false">정보수정</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="userpwd-tab" data-bs-toggle="pill" data-bs-target="#userpwd-tab-pane" type="button" role="tab" aria-controls="userpwd-tab-pane" aria-selected="false">비밀번호 변경</button>
                    </li>
				<c:if test="${level == 'master' || level == 'user'}">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="unregister-tab" data-bs-toggle="pill" data-bs-target="#unregister-tab-pane" type="button" role="tab" aria-controls="unregister-tab-pane" aria-selected="false">회원탈퇴</button>
                    </li>
				</c:if>
				<c:if test="${level == 'master' || level == 'admin'}">
					<li class="nav-item" role="presentation">
						<button class="nav-link" id="memberjoin-tab" data-bs-toggle="pill" data-bs-target="#memberjoin-tab-pane" type="button" role="tab" aria-controls="memberjoin-tab-pane" aria-selected="false">직원등록</button>
					</li>
					<li class="nav-item" role="presentation">
					    <button class="nav-link" id="leveling-tab" data-bs-toggle="pill" data-bs-target="#leveling-tab-pane" type="button" role="tab" aria-controls="leveling-tab-pane" aria-selected="false">등급권한</button>
					</li>
				</c:if>
                </ul>
            </div>
            <div class="col-md-9">
                <div class="tab-content" id="myTabContent">
                    <!-- 기본정보 탭 -->
                    <div class="tab-pane fade show active" id="mypage-tab-pane" role="tabpanel" aria-labelledby="mypage-tab">
                        <h1>기본정보</h1>                        
                        <br>
                        <table class="table">
                            <tr>
                                <td>이름</td>
                                <td>${crxVO.username != null ? crxVO.username : crxVO.memname}</td>
                            </tr>
                            <tr>
                                <td>생년월일</td>
                                <td>${crxVO.userbirth != null ? crxVO.userbirth : crxVO.membirth}</td>                            
                            </tr>
                            <tr>
                                <td>전화번호</td>
                                <td>${crxVO.usertel != null ? crxVO.usertel : crxVO.memtel}</td>                                
                            </tr>
                            <tr>
                                <td>이메일</td>
                                <td>${crxVO.usermail != null ? crxVO.usermail : crxVO.memmail}</td>
                            </tr>
							<tr>
							    <td>주소</td>
							    <td>
									<c:choose>
									    <c:when test="${crxVO.userpost != null}">
									        <c:out value="(${crxVO.userpost}) " />
									    </c:when>
									    <c:when test="${crxVO.mempost != null}">
									        <c:out value="(${crxVO.mempost}) " />
									    </c:when>
									</c:choose>
									<c:out value="${crxVO.useradd != null ? crxVO.useradd : crxVO.memadd}"/>
							    </td>
							</tr>
                        </table>
                    </div>
                    
					<div class="tab-pane fade" id="usermod-tab-pane" role="tabpanel" aria-labelledby="usermod-tab">
                        <h1>정보수정</h1>                        
                        <br>
						<form id="updateForm">							
						    <table class="table">
						        <tr>
						            <td>이름</td>
						            <td><input type="text" name="${crxVO.level == 'user' ? 'username' : 'memname'}" value="${crxVO.username != null ? crxVO.username : crxVO.memname}"></td>
						        </tr>
						        <tr>
						            <td>생년월일</td>
						            <td><input type="date" name="${crxVO.level == 'user' ? 'userbirth' : 'membirth'}" value="${crxVO.userbirth != null ? crxVO.userbirth : crxVO.membirth}" readonly></td>                                
						        </tr>
						        <tr>
						            <td>전화번호</td>
						            <td><input type="text" name="${crxVO.level == 'user' ? 'usertel' : 'memtel'}" value="${crxVO.usertel != null ? crxVO.usertel : crxVO.memtel}"></td>                                
						        </tr>
						        <c:if test="${status != 'kakao'}">
						            <tr>
						                <td>이메일</td>
						                <td><input type="email" name="${crxVO.level == 'user' ? 'usermail' : 'memmail'}" value="${crxVO.usermail != null ? crxVO.usermail : crxVO.memmail}"></td>
						            </tr>
						        </c:if>
						        <c:if test="${status == 'kakao'}">
						            <input type="hidden" name="${crxVO.level == 'user' ? 'usermail' : 'memmail'}" value="${crxVO.usermail != null ? crxVO.usermail : crxVO.memmail}">
						        </c:if>
								<tr>
								    <td>주소</td>
								    <td>
										<jsp:include page="${crxVO.level == 'user' ? 'userZip.jsp' : 'memberZipEdit.jsp'}"/>
								    </td>                                
								</tr>
						    </table>
						    <div style="text-align:center">						        
						        <button id="updateBtn" type="button" class="btn btn-success text-white">수정</button>
						    </div>
						</form>
                    </div>
					<div class="tab-pane fade" id="userpwd-tab-pane" role="tabpanel" aria-labelledby="userpwd-tab">
					    <div>
					        <h1>비밀번호 변경</h1>
					        <br>
					        <form action="updateUserPwd.do" method="post" onsubmit="return validatePwdForm()">
					            <table class="table">
					                <tr>
					                    <td>현재 비밀번호</td>
					                    <td><input type="password" name="currentpwd"></td>
					                </tr>
					                <tr>
					                    <td>새 비밀번호</td>
					                    <td><input type="password" name="newpwd"></td>
					                </tr>
					                <tr>
					                    <td>새 비밀번호 확인</td>
					                    <td><input type="password" name="confirmpwd"></td>
					                </tr>
					            </table>
					            <div style="text-align:center">
					                <input type="submit" class="btn btn-secondary" value="변경">
					            </div>
					        </form>
					    </div>
					</div>

					<div class="tab-pane fade" id="unregister-tab-pane" role="tabpanel" aria-labelledby="unregister-tab">
					    <h1>회원탈퇴</h1>                        
					    <br>
						<c:if test="${not empty unregisterResult}">
						    <script>
						        alert("${unregisterResult}");
						        window.location.href = '/main.do';
						    </script>
						    <c:remove var="unregisterResult" scope="session" />
						</c:if>
						<c:if test="${not empty unregisterError}">
						    <script>
						        alert("${unregisterError}");
						        window.location.href = '/mypage.do?tab=unregister';
						    </script>
						    <c:remove var="unregisterError" scope="session" />
						</c:if>


					    <form action="/deleteUser.do" method="post" onsubmit="return confirmUnregister()">
					        <table class="table">
					            <c:choose>
					                <c:when test="${crxVO.status == 'kakao'}">
					                    <tr>
					                        <td>이름</td>
					                        <td><input type="text" name="username" required></td>
					                    </tr>
					                    <tr>
					                        <td>이메일</td>
					                        <td><input type="email" name="usermail" required></td>
					                    </tr>
					                </c:when>
					                <c:otherwise>
					                    <tr>
					                        <td>비밀번호</td>
					                        <td><input type="password" name="password" required></td>
					                    </tr>
					                    <tr>
					                        <td>비밀번호 확인</td>
					                        <td><input type="password" name="confirmPassword" required></td>
					                    </tr>
					                </c:otherwise>
					            </c:choose>
					            <tr>
					                <td>탈퇴사유</td>
					                <td>
					                    <select id="selectlist" onchange="toggleTextarea()">
					                        <option>이용빈도 낮음</option>
					                        <option>개인정보 및 보안 우려</option>
					                        <option>CRX 홈페이지 이용 불편</option>
					                        <option>CRX 열차 이용 불편</option>
					                        <option>기타(개선의견)</option>
					                    </select>
					                </td>    
					            </tr>
					            <tr id="textareadisplay" style="display: none;">
					                <td>기타(개선의견)</td>
					                <td><textarea id="textarea"></textarea></td>
					            </tr>
					        </table>
					        <div style="text-align:center">
					            <input type="submit" class="btn btn-danger" value="탈퇴">
					        </div>
					    </form>
					</div>

					<div class="tab-pane fade" id="memberjoin-tab-pane" role="tabpanel" aria-labelledby="memberjoin-tab">
					    <h1>직원등록</h1>						
					    <br>
					    <form action="/updateMember.do" method="post">
					        <table class="table">
					            <tr>
					                <td>사원번호</td>
					                <td>
					                    <select name="memid">
					                        <c:forEach var="mem" items="${totalList}">
					                            <c:if test="${mem.memname == null}">
					                                <option value="${mem.memid}">${mem.memid}</option>
					                            </c:if>
					                        </c:forEach>
					                    </select>
					                </td>
					            </tr>
					            <tr>
					                <td>이름</td>
					                <td><input type="text" name="memname"></td>
					            </tr>						
					            <tr>
					                <td>생년월일</td>
					                <td><input type="date" name="membirth"></td>								
					            </tr>
					            <tr>
					                <td>성별</td>
					                <td>
					                    <select name="memgender">
					                        <option>남성</option>
					                        <option>여성</option>	
					                    </select>
					                </td>
					            </tr>
					            <tr>
					                <td>전화번호</td>
					                <td><input type="text" name="memtel"></td>								
					            </tr>
					            <tr>
					                <td>입사일</td>
					                <td><input type="date" name="memdate" value="<%= new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()) %>"></td>                                
					            </tr>
					            <tr>
					                <td>이메일</td>
					                <td><input type="email" name="memmail"></td>
					            </tr>
					            <tr>
					                <td>주소</td>
					                <td><jsp:include page="memberZipReg.jsp" /></td>								
					            </tr>
					            <tr>
					                <td>부서명</td>
					                <td>
					                    <select name="division_divno">
					                        <c:if test="${divname == '통합관리'}">
					                            <option value="CRX00">통합관리</option>
					                        </c:if>
					                        <c:if test="${divname == '통합관리' || divname == '예매관리'}">
					                            <option value="CRX01">예매관리</option>
					                        </c:if>
					                        <c:if test="${divname == '통합관리' || divname == '고객안내'}">
					                            <option value="CRX02">고객안내</option>
					                        </c:if>
					                        <c:if test="${divname == '통합관리' || divname == '이용안내'}">
					                            <option value="CRX03">이용안내</option>
					                        </c:if>
					                        <c:if test="${divname == '통합관리' || divname == '여행상품'}">
					                            <option value="CRX04">여행상품</option>
					                        </c:if>
					                    </select>
					                </td>
					            </tr>
					            <tr>
					                <td>직급</td>
					                <td>
					                    <select name="memgrade">
					                        <option>처장</option>
					                        <option>부장</option>
					                        <option>과장</option>
					                        <option>사원</option>
					                    </select>
					                </td>
					            </tr>
					        </table>
					        
					        <div style="text-align:center">
					            <input type="submit" class="btn btn-success" value="등록하기">
					        </div>
					    </form>			
					</div>

					<div class="tab-pane fade" id="leveling-tab-pane" role="tabpanel" aria-labelledby="leveling-tab">
					    <h1>등급관리</h1>						
					    <br>
						<br>
						<br>
					    
						<div class="division">
							<c:if test="${divname == '통합관리'}">
						    	<a href="#master" class="scroll-link"><h5>통합관리팀</h5></a>
							</c:if>
							<c:if test="${divname == '통합관리' || divname == '예매관리'}">
						    	<a href="#reservation" class="scroll-link"><h5>예매관리팀</h5></a>
							</c:if>
							<c:if test="${divname == '통합관리' || divname == '고객안내'}">
							    <a href="#customer" class="scroll-link"><h5>고객안내팀</h5></a>
							</c:if>
							<c:if test="${divname == '통합관리' || divname == '이용안내'}">
							    <a href="#usage" class="scroll-link"><h5>이용안내팀</h5></a>
							</c:if>
							<c:if test="${divname == '통합관리' || divname == '여행상품'}">
							    <a href="#tour" class="scroll-link"><h5>여행상품팀</h5></a>
							</c:if>
						</div>
						<br>
						<br>
					<c:if test="${divname == '통합관리'}">
						<!-- 통합관리팀 테이블 -->
						<h6 id="master"><b>통합관리팀</b></h6>
						<table class="leveltable">
						    <tr>
						        <td>이름</td>
						        <td>생년월일</td>
						        <td>부서명</td>
						        <td>직급</td>
						        <td>현재등급</td>
						        <td>변경등급</td>
						        <td></td>
						    </tr>
						    <c:forEach var="mem" items="${masterList}">
								<c:if test="${mem.memname != null}">
						        <tr>
						            <form class="updateConfirm" action="gradeUp" method="post">
						                <input type="hidden" name="userid" value="${mem.userid}"/>
						                <td>${mem.memname}</td>
						                <td>${mem.membirth}</td>
						                <td>${mem.divname}</td>
						                <td>${mem.memgrade}</td>
						                <td>${mem.level}</td>
						                <td>
						                    <select name="level">
						                        <option value="admin">admin</option>
						                        <option value="member">member</option>
												<option value="master">master</option>
						                    </select>
						                </td>
						                <td><input type="submit" class="btn btn-success" value="변경"></td>
						            </form>
						        </tr>
								</c:if>
						    </c:forEach>
						</table>
						<br>
					</c:if>

					<c:if test="${divname == '통합관리' || divname == '예매관리'}">
						<!-- 예매관리팀 테이블 -->
						<h6 id="reservation"><b>예매관리팀</b></h6>
						<table class="leveltable">
						    <tr>
						        <td>이름</td>
						        <td>생년월일</td>
						        <td>부서명</td>
						        <td>직급</td>
						        <td>현재등급</td>
						        <td>변경등급</td>
						        <td></td>
						    </tr>
						    <c:forEach var="mem" items="${reservList}">
								<c:if test="${mem.memname != null}">
						        <tr>
						            <form class="updateConfirm" action="gradeUp" method="post">
						                <input type="hidden" name="userid" value="${mem.userid}"/>
						                <td>${mem.memname}</td>
						                <td>${mem.membirth}</td>
						                <td>${mem.divname}</td>
						                <td>${mem.memgrade}</td>
						                <td>${mem.level}</td>
						                <td>
						                    <select name="level">
						                        <option value="admin">admin</option>
						                        <option value="member">member</option>
						                    </select>
						                </td>
						                <td><input type="submit" class="btn btn-success" value="변경"></td>
						            </form>
						        </tr>
								</c:if>
						    </c:forEach>
						</table>
						<br>
						<!-- // 예매관리팀 테이블 끝 -->
					</c:if>

					<c:if test="${divname == '통합관리' || divname == '고객안내'}">
						<!-- 고객안내팀 테이블 -->
						<h6 id="customer"><b>고객안내팀</b></h6>
						<table class="leveltable">
						    <tr>
						        <td>이름</td>
						        <td>생년월일</td>
						        <td>부서명</td>
						        <td>직급</td>
						        <td>현재등급</td>
						        <td>변경등급</td>
						        <td></td>
						    </tr>
						    <c:forEach var="mem" items="${customerList}">
								<c:if test="${mem.memname != null}">
						        <tr>
						            <form class="updateConfirm" action="gradeUp" method="post">
						                <input type="hidden" name="userid" value="${mem.userid}"/>
						                <td>${mem.memname}</td>
						                <td>${mem.membirth}</td>
						                <td>${mem.divname}</td>
						                <td>${mem.memgrade}</td>
						                <td>${mem.level}</td>
						                <td>
						                    <select name="level">
						                        <option value="admin">admin</option>
						                        <option value="member">member</option>
						                    </select>
						                </td>
						                <td><input type="submit" class="btn btn-success" value="변경"></td>
						            </form>
						        </tr>
								</c:if>
						    </c:forEach>
						</table>
						<br>
						<!-- // 고객안내팀 테이블 끝 -->
					</c:if>

					<c:if test="${divname == '통합관리' || divname == '이용안내'}">
						<!-- 이용안내팀 테이블 -->
						<h6 id="usage"><b>이용안내팀</b></h6>
						<table class="leveltable">
						    <tr>
						        <td>이름</td>
						        <td>생년월일</td>
						        <td>부서명</td>
						        <td>직급</td>
						        <td>현재등급</td>
						        <td>변경등급</td>
						        <td></td>
						    </tr>
						    <c:forEach var="mem" items="${usageList}">
								<c:if test="${mem.memname != null}">
						        <tr>
						            <form class="updateConfirm" action="gradeUp" method="post">
						                <input type="hidden" name="userid" value="${mem.userid}"/>
						                <td>${mem.memname}</td>
						                <td>${mem.membirth}</td>
						                <td>${mem.divname}</td>
						                <td>${mem.memgrade}</td>
						                <td>${mem.level}</td>
						                <td>
						                    <select name="level">
						                        <option value="admin">admin</option>
						                        <option value="member">member</option>
						                    </select>
						                </td>
						                <td><input type="submit" class="btn btn-success" value="변경"></td>
						            </form>
						        </tr>
								</c:if>
						    </c:forEach>
						</table>
						<br>
						<!-- // 이용안내팀 테이블 끝 -->
					</c:if>

					<c:if test="${divname == '통합관리' || divname == '여행상품'}">
						<!-- 여행상품팀 테이블 -->
						<h6 id="tour"><b>여행상품팀</b></h6>
						<table class="leveltable">
						    <tr>
						        <td>이름</td>
						        <td>생년월일</td>
						        <td>부서명</td>
						        <td>직급</td>
						        <td>현재등급</td>
						        <td>변경등급</td>
						        <td></td>
						    </tr>
						    <c:forEach var="mem" items="${tourList}">
								<c:if test="${mem.memname != null}">
						        <tr>
						            <form class="updateConfirm" action="gradeUp" method="post">
						                <input type="hidden" name="userid" value="${mem.userid}"/>
						                <td>${mem.memname}</td>
						                <td>${mem.membirth}</td>
						                <td>${mem.divname}</td>
						                <td>${mem.memgrade}</td>
						                <td>${mem.level}</td>
						                <td>
						                    <select name="level">
						                        <option value="admin">admin</option>
						                        <option value="member">member</option>
						                    </select>
						                </td>
						                <td><input type="submit" class="btn btn-success" value="변경"></td>
						            </form>
						        </tr>
								</c:if>
						    </c:forEach>
						</table>
						<!-- // 여행상품팀 테이블 끝 -->
					</c:if>					
					</div>
                </div>
            </div>
        </div>
    </div>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
    <jsp:include page="footer.jsp" />
</body>
</html>
