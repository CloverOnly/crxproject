<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <meta charset="UTF-8">
    <title>지연료 계좌반환 신청</title>
    <style>
        .con {
            margin: auto;
            width: 1200px;
        }
        .header {
            background-color: rgb(226, 240, 217);
            text-align: center;
        }
        .CSMainImg {
            width: 1200px;
            height: 500px;
            background-image: url('../img/CSImg.jpg');
            background-size: cover;
        }
        .line {
            margin: 10px 0;
            width:50px;
            height: 50px;
            border-bottom: 5px solid rgb(84, 130, 53);
        }
        .line2 {
            margin: 10px 0;
            width:50px;
            height: 10px;
            border-bottom: 3px solid rgb(84, 130, 53);
        }
        li::marker {
            color: rgb(84, 130, 53);            
        }
        hr {
            width: 1200px;
        }
        .subMenu {
            width: 1200px;
        }
        .subMenu2 {
            background-color: rgb(84, 130, 53);
        }
        .atag {
            display: block;
            text-decoration: none;
            color: white;
        }
        li {
            list-style: none;
        }
        .refundBox {
            width: 1200px;
            display: flex;
            justify-content: center;
        }
        .refundImg {
            width: 800px;
            height:350px;
            background-image: url("../img/trainDelayRefund.jpg");
            background-size: cover;
        }
        .Box {
            width: 1200px;
        }
        .dpb {
            font-size: 12px;
        }
        .box2 {
            width: 1200px;
        }
        .ticketTable {
            width: 1200px;
        }
        .table {
            width: 1200px;
        }
        .fSize {
            font-size: 12px;
        }
        .ticketNo {
            width: 85%;
        }
        .tableTitle {
            width: 15%;
        }
        .wx250 {
            width: 250px;
        }
        .wx60 {
            width: 60px;
        }
    </style>
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />
    <div class="con">
        <h1>지연료 계좌반환 신청</h1>
        <br>
        <hr>
        <div class="subMenu subtle text-center px-2">
            <div class="row">
                <div class="subMenu1 col border border-white bg-secondary"><a href="trainDelayRefund.do" class="atag fs-5">열차지연 시 교통비 지급 안내문</a></div>
                <div class="subMenu2 col border border-white"><a href="delayRequest.do" class="atag fs-5">지연료 계좌반환 신청</a></div>
             </div>
        </div>
        <div class="Box">
            <ul class="border my-3 p-3">
                <li><i class="bi bi-dash"></i> 지연료 계좌반환 신청은 현금으로 승차권을 구매하신 고객 대상입니다.</li>
                <li><i class="bi bi-dash"></i> 지연배상 환급 신청 가능 기간 : 열차지연 발생일로부터 1년이내</li>
                <li><i class="bi bi-dash"></i> 지연료 계좌반환 신청 완료 후 최대 1개월 이내 고객님께서 입력하신 계좌번호로 반환 될 예정입니다.</li>
                <li><i class="bi bi-dash"></i> 승차자명, 반환 신청자명, 환불 계좌의 예금주명은 동일해야 합니다.(불일치할 경우 별도의 확인 절차가 필요할 수 있습니다.)</li>
            </ul>
        </div>
        <div class="gap"></div>
        
        <!-- 지연료 계좌반환 신청을 위한 개인정보 수집·이용 동의서 -->
        <form id="ticketForm" onsubmit="return false;">
            <div class="box2 border p-3">
                <h2 style="font-size: 20px;font-weight: bold;text-align: center;">지연료 계좌반환 신청을 위한 개인정보 수집·이용 동의서</h2>
                <p class="dpb">&lt;씨알엑스&gt;는 지연료 계좌반환 신청을 위하여 아래와 같이 개인정보를 수집·이용하고자 합니다. 내용을 자세히 읽으신 후 동의 여부를 결정하여 주십시오.<br></p>
                <div class="line2"></div>
                <h5 class="h6 lefttopbg">개인정보 수집 및 이용에 대한 안내(필수)</h5>
                <div class="tbl_wrap tbody_td_tal_l th_all td_val_t mgt10">
                    <table class="table-border" style="width:100%">
                        <thead>
                            <tr class="border-top text-center">
                                <th class="fSize bg-light border-end">개인정보 항목</th>
                                <th class="fSize bg-light border-end">수집·이용 목적</th>
                                <th class="fSize bg-light">보유·이용기간</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="fSize border-end">성명, 휴대전화번호, 계좌번호</td>
                                <td class="fSize border-end">지연료 계좌반환 신청 및 처리 안내</td>
                                <td class="fSize fColorRed ulfwbold" style="color: #8f0349;">목적 달성 시 까지(목적 달성 이후 즉시 파기)<br>※ 결제 정보는 ‘전자상거래 등에서의 소비자보호에 관한 법률’에 따라 5년 보관</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <span class="dpb">※위의 개인정보 수집·이용 필수항목에 대한 동의를 거부할 권리가 있습니다. 그러나 동의를 거부할 경우 지연료 계좌반환 신청 및 처리 안내에 제한을 받을 수 있습니다.</span>
            </div>
            <div class="tal_r val_m text-start">
                &nbsp;☞ 위와 같이 개인정보를 수집·이용하는데 동의하십니까?<strong>(필수)</strong>
                <label for="agreeY">동의</label>
                <input type="radio" name="agree" id="agreeY" class="checkForm checkbox" value="Y" option="{isMust : true, message : '개인정보 수집 및 이용 동의 여부를 선택하십시오.'}" checked>&nbsp;
                <label for="agreeN">미동의</label>
                <input type="radio" name="agree" id="agreeN" class="checkForm checkbox" value="N" option="{isMust : true, message : '개인정보 수집 및 이용 동의 여부를 선택하십시오.'}">
            </div>
            <div class="tbl_wrap tbl6">
				<!-- 승차권 정보 -->
                <table class="table-bordered my-5 align-middle">
                    <colgroup>
                        <col class="wx150">
                        <col>
                    </colgroup>
                    <tbody>                         
                        <tr>
                            <th class="text-center bg-light" colspan="6"><label for="">승차권 정보</label></th>
                        </tr>
                        <tr>
                            <th class="tableTitle p-1" colspan="2"><label for="ptkNm">이름</label></th>
                            <td colspan="5">
                                <input type="text" name="ptkNm" id="ptkNm" class="wx250 input_midium checkForm" maxlength="20" option="{isMust : true, message : '이름을 입력해주세요.'}" value="${param.ptkNm}">
                            </td>
                        </tr>
                        <tr>
                            <th colspan="2" clas="tableTitle p-1"><label for="celNo">휴대전화번호</label></th>
                            <td colspan="5">
                                <input type="text" name="celNo" id="celNo" class="wx250 input_midium checkForm" maxlength="11" option="{isMust : true, varType : 'celNo', message : '휴대전화를 입력하십시오.'}" value="${param.celNo}" autocomplete="off">
                            </td>
                        </tr>
                        <tr>
                            <th colspan="2" clas="tableTitle p-1"><label for="selCd1">승차권 반환번호</label></th>
                            <td colspan="5">
                                <input type="text" title="승차권 반환번호 여섯자리 이상 여덟자리 이하" size="50" style="padding: 5px;" name="applyNum" id="sel_Cd_01" class="wx250 input_midium checkForm" minlength="6" maxlength="8" option="{isMust : true, message : '승차권 반환번호(원권번호)를 입력해주세요.'}" autocomplete="off" pattern="[0-9]+" value="${param.applyNum}">
                                <button type="button" class="btn btn-success text-white" onclick="checkTicket()">승차권 인증</button>
                            </td>
                        </tr>
                        <tr>
                            <th colspan="2" clas="tableTitle p-1"><label for="selCd5">환불예정금액</label></th>
                            <td colspan="5">
                                <input type="text" style="padding: 5px;" name="refundAmount" id="selCd5" class="wx250 input_midium checkForm" value="${refundAmount}" readonly="readonly"> 원
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </form>

        <!-- 환불계좌정보 -->
        <form action="delayRequest.do" method="post" onsubmit="return validateForm();">
            <input type="hidden" name="ptkNm" value="${param.ptkNm}">
            <input type="hidden" name="celNo" value="${param.celNo}">
            <input type="hidden" name="applyNum" value="${param.applyNum}">
            <input type="hidden" name="refundAmount" value="${refundAmount}">
            <div class="tbl_wrap tbl6">
                <table class="table-bordered align-middle">
                    <tbody>
                        <tr>
                            <th class="text-center bg-light" colspan="6"><label for="">환불계좌정보</label></th>
                        </tr>
                        <tr class="">
                            <th colspan="2" class="p-2"><label for="ptkNm2">계좌주</label></th>
                            <td>
                                <input type="text" name="ptkNm2" id="ptkNm2" class="wx250 input_midium checkForm" maxlength="20" option="{isMust : true, message : '계좌주를 입력해주세요.'}" value="${param.ptkNm}">
                            </td>
                        </tr>
                        <tr>
                            <th colspan="2" class="p-2"><label for="bankComboBox">은행명</label></th>
                            <td>
                                <select style="border: 1px solid lightgray;padding: 5px;border-radius: 5px;width: 250px;" name="bankComboBox" id="bankComboBox" option="{isMust : true, message : '은행명을 선택해주세요.'}">  
                                    <option value="" selected="">은행명</option>
                                    <option value="002">산업은행</option><option value="003">기업은행</option><option value="004">국민은행</option><option value="005">외환은행</option><option value="007">수협중앙회</option><option value="008">수출입은행</option><option value="011">NH농협은행</option><option value="012">지역농.축협</option><option value="020">우리은행</option><option value="023">SC은행</option><option value="027">한국씨티은행</option><option value="031">대구은행</option><option value="032">부산은행</option><option value="034">광주은행</option><option value="035">제주은행</option><option value="037">전북은행</option><option value="039">경남은행</option><option value="045">새마을금고연합회</option><option value="048">신협중앙회</option><option value="050">상호저축은행</option><option value="052">모건스탠리은행</option><option value="054">HSBC은행</option><option value="055">도이치은행</option><option value="056">알비에스피엘씨은행</option><option value="057">제이피모간체이스은행</option><option value="058">미즈호은행</option><option value="059">미쓰비시도쿄UFJ은행</option><option value="060">BOA은행</option><option value="061">비앤피파리바은행</option><option value="062">중국공상은행</option><option value="063">중국은행</option><option value="064">산림조합중앙회</option><option value="071">우체국</option><option value="076">신용보증기금</option><option value="077">기술신용보증기금</option><option value="081">하나은행</option><option value="088">신한은행</option><option value="089">케이뱅크</option><option value="093">한국주택금융공사</option><option value="094">서울보증보험</option><option value="095">경찰청</option><option value="096">한국전자금융㈜</option><option value="099">금융결재원</option><option value="209">유안타증권</option><option value="092">토스뱅크</option><option value="230">미래에셋증권</option><option value="218">KB증권</option><option value="240">삼성증권</option><option value="243">한국투자증권</option><option value="238">미래에셋증권</option><option value="261">교보증권</option><option value="262">하이투자증권</option><option value="247">NH투자증권</option><option value="264">키움증권</option><option value="265">이트레이드증권</option><option value="266">SK증권</option><option value="267">대신증권</option><option value="268">아이엠투자증권</option><option value="269">한화투자증권</option><option value="270">하나대투증권</option><option value="278">신한금융투자</option><option value="263">현대차증권</option><option value="280">유진투자증권</option><option value="287">메리츠종합금융증권</option><option value="289">NH농협증권</option><option value="290">부국증권</option><option value="291">신영증권</option><option value="292">LIG투자증권</option><option value="0843102">우리은행 수서역금융센터</option><option value="090">카카오뱅크</option><option value="20">우리은행</option><option value="271">토스증권</option><option value="279">DB금융투자</option></select>
                                <input type="hidden" name="selCd2" id="selCd2" class="wx250 input_midium checkForm" maxlength="10" option="{isMust : true, message : '은행명을 선택해주세요.'}">
                            </td>
                        </tr>
                        <tr>
                            <th colspan="2" class="p-2"><label for="selCd3">계좌번호</label></th>
                            <td>
                                <input type="text" name="selCd3" id="selCd3" class="wx250 input_midium checkForm" maxlength="30" option="{isMust : true, message : '계좌번호를 입력해주세요.'}">
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div><br>
            <div class="tal_c text-center">
                <button type="submit" class="btn btn-success text-white">확인</button>&nbsp;
                <button type="button" class="btn btn-secondary text-white" onclick="location.href = '/main.do';">취소</button>
            </div><br>
        </form>
    </div>
    <jsp:include page="footer.jsp" />

    <script>
		function validateForm() {
		    const namePattern = /^[가-힣]{2,6}$/;
		    const phonePattern = /^010-?[0-9]{4}-?[0-9]{4}$/;
		    const accountPattern = /^[0-9]+$/;

		    const name = document.getElementById("ptkNm").value;
		    const phone = document.getElementById("celNo").value;
		    const accountName = document.getElementById("ptkNm2").value;
		    const bank = document.getElementById("bankComboBox").value;
		    const accountNumber = document.getElementById("selCd3").value;
		    const agreement = document.querySelector('input[name="agree"]:checked').value;

		    if (agreement !== "Y") {
		        alert("개인정보 수집 및 이용에 동의하셔야 합니다.");
		        return false;
		    }
		    if (!namePattern.test(name)) {
		        alert("이름은 한글 2~6자만 입력 가능합니다.");
		        return false;
		    }
		    if (!phonePattern.test(phone)) {
		        alert("휴대전화번호 형식이 올바르지 않습니다.");
		        return false;
		    }
		    if (name !== accountName) {
		        alert("계좌주와 이름이 일치하지 않습니다.");
		        return false;
		    }
		    if (bank === "") {
		        alert("은행명을 선택해주세요.");
		        return false;
		    }
		    if (!accountPattern.test(accountNumber)) {
		        alert("계좌번호는 숫자만 입력 가능합니다.");
		        return false;
		    }		
			alert('지연료 계좌반환 신청이 완료되었습니다.');
		    return true;
		}

		function checkTicket() {
		    const applyNum = document.getElementById("sel_Cd_01").value;

		    if (applyNum.length !== 6 && applyNum.length !== 8) {
		        alert("승차권 반환번호는 6자리 또는 8자리 숫자여야 합니다.");
		        return;
		    }

		    fetch('/ticketCheck.do', {
		        method: 'POST',
		        headers: {
		            'Content-Type': 'application/x-www-form-urlencoded',
		        },
		        body: new URLSearchParams({
		            'applyNum': applyNum
		        })
		    })
		    .then(response => response.json())
		    .then(data => {
		        if (data.refundAmount !== undefined) {
		            document.getElementById("selCd5").value = data.refundAmount + " 원";
		        } else {
		            alert("해당하는 승차권 번호를 찾을 수 없습니다.");
		        }
		    })
		    .catch(error => console.error('Error:', error));
		}
    </script>
</body>
</html>
