<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>네이버 지도에 실시간 버스 노선 표시</title>
<!-- 네이버 지도 API 호출 -->
<script type="text/javascript" src="https://openapi.map.naver.com/openapi/v3/maps.js?ncpClientId=btaqhwfggo"></script>
<!-- CSS 스타일 설정 -->
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    #map {
        width: 75%;
        height: 550px;
        float: left;
    }
    #busListContainer {
        width: 25%;
        height: 550px;
        float: right;
        overflow-y: auto;
        padding: 20px;
        box-sizing: border-box;
        background-color: #f8f9fa;
        border-left: 1px solid #ddd;
    }
    #busListContainer h3 {
        margin-top: 0;
        font-size: 1.2em;
        color: #333;
    }
    #busListContainer ul {
        list-style-type: none;
        padding: 0;
    }
    #busListContainer li {
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
        cursor: pointer;
        background-color: #fff;
        transition: background-color 0.3s;
    }
    #busListContainer li:hover {
        background-color: #e9ecef;
    }
    .custom-marker {
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: #007bff;
        color: white;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 14px;
        box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
    }
    #selectContainer {
        padding: 10px;
        background-color: #f8f9fa;
        border-bottom: 1px solid #ddd;
    }
    #busStopSelect {
        width: 100%;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
        font-size: 1em;
    }
</style>
</head>
<body>
    <div id="selectContainer">
        <select id="busStopSelect" onchange="onBusStopSelect()">
            <option value="">--기차역을 선택하세요--</option>
            <option value="37.555167, 126.970833">서울역</option>
            <option value="37.595583, 127.08575">상봉역</option>
            <option value="37.529706, 126.964744">용산역</option>
            <option value="37.580861, 127.048389">청량리역</option>
            <option value="37.4874685, 127.1013245">수서역</option>
            <option value="37.515278, 126.907561">영등포역</option>
            <option value="37.623056, 127.061389">광운대역</option>
            <option value="37.561194, 127.037444">왕십리</option>
            <option value="37.541694, 127.017278">옥수역</option>
        </select>
    </div>
    <div id="map"></div>
    <div id="busListContainer">
        <h3 id="busListTitle">버스 목록</h3> <!-- 제목이 표시될 위치 -->
        <ul id="busList"></ul>
    </div>

    <script type="text/javascript">
        var map;
        var busMarkers = [];
        var stationMarkers = [];
        var polyline;
        var apiKey = "tpP56LjQPFwVOpjtcGfDAA"; // 여기에 실제 ODSAY API 키를 입력하세요.
        var busIds = [];
        var updateInterval;
        var stationMap = {}; // 정류장 ID와 이름을 매핑하는 객체

        function initMap() {
            // 서울 중심에 지도 생성
            map = new naver.maps.Map('map', {
                center: new naver.maps.LatLng(37.5666103, 126.9783882),
                zoom: 12
            });
        }

        function onBusStopSelect() {
            var busStopSelect = document.getElementById("busStopSelect");
            var selectedValue = busStopSelect.value.split(",");
            var y = parseFloat(selectedValue[0]);
            var x = parseFloat(selectedValue[1]);

            map.setCenter(new naver.maps.LatLng(y, x));
            map.setZoom(17);  // 지도를 확대합니다.

            fetchNearbyBusStops(x, y);
        }

        function fetchNearbyBusStops(x, y) {
            var apiUrl = 'https://api.odsay.com/v1/api/pointBusStation?lang=0&x=' + x + '&y=' + y + '&radius=250&apiKey=' + apiKey;

            fetch(apiUrl)
                .then(response => response.json())
                .then(data => {
                    clearStationMarkers(); // 기존 정류장 마커 초기화
                    var stations = data.result.lane;

                    for (var i = 0; i < stations.length; i++) {
                        var station = stations[i];
                        if (station.stationClass === 1) {
                            createStationMarker(station);
                        }
                    }
                })
                .catch(error => {
                    console.error('Error fetching nearby bus stops:', error);
                });
        }

        function createStationMarker(station) {
            var marker = new naver.maps.Marker({
                position: new naver.maps.LatLng(station.y, station.x),
                map: map,
                icon: {
                    url: "../img/busstation.png", // 정류장 마커 이미지 설정
                    size: new naver.maps.Size(35, 35),
                    origin: new naver.maps.Point(0, 0),
                    anchor: new naver.maps.Point(16, 32),
                },
                title: station.stationName
            });

            // 마커 클릭 이벤트 등록
            naver.maps.Event.addListener(marker, 'click', function() {
                showBusList(station);
            });

            stationMarkers.push(marker); // 정류장 마커를 배열에 추가
        }

        function clearStationMarkers() {
            // 기존 정류장 마커를 지도에서 제거
            for (var i = 0; i < stationMarkers.length; i++) {
                stationMarkers[i].setMap(null);
            }
            stationMarkers = [];
        }

        function showBusList(station) {
            var busListHtml = "";
            var busList = station.busList;

            // 제목 설정
            document.getElementById('busListTitle').innerText = '[' + station.stationName + '] 버스 목록';

            for (var i = 0; i < busList.length; i++) {
                busListHtml += "<li onclick='selectBus(" + busList[i].busID + ", \"" + busList[i].busNo + "\")'>" + busList[i].busNo + "</li>";
            }

            document.getElementById('busList').innerHTML = busListHtml;
        }

        function selectBus(busId, busNo) {
            busIds = [busId]; // 선택된 버스만 추적

            map.setZoom(15);  // 버스를 선택하면 지도를 축소합니다.

            // 선택된 버스의 노선 정보를 가져와 폴리라인을 그림
            fetchBusRoute(busId);

            updateBusPositions();

            if (updateInterval) {
                clearInterval(updateInterval);
            }
            updateInterval = setInterval(updateBusPositions, 5000);
        }

        function fetchBusRoute(busId) {
            var apiUrl = 'https://api.odsay.com/v1/api/busLaneDetail?lang=0&busID=' + busId + '&apiKey=' + apiKey;

            console.log("Fetching bus route with URL: ", apiUrl);

            fetch(apiUrl)
                .then(response => response.json())
                .then(data => {
                    console.log("API response data:", data);
                    if (data.result && data.result.station) {
                        var stations = data.result.station;
                        var path = [];

                        // 정류장 ID와 이름을 매핑하여 stationMap에 저장
                        stations.forEach(function(station) {
                            stationMap[station.stationID] = station.stationName;
                            var latLng = new naver.maps.LatLng(station.y, station.x);
                            path.push(latLng);
                        });

                        if (polyline) {
                            polyline.setMap(null);
                        }

                        polyline = new naver.maps.Polyline({
                            map: map,
                            path: path,
                            strokeColor: '#FF0000',
                            strokeOpacity: 0.8,
                            strokeWeight: 2,
                            strokeLineCap: 'round',  // 선의 끝을 둥글게 처리
                            strokeLineJoin: 'round', // 선의 교차점을 둥글게 처리
                            icons: [{
                                icon: naver.maps.SymbolPath.FORWARD_CLOSED_ARROW, // 화살표 아이콘 사용
                                offset: '100%' // 아이콘을 끝에 배치 (진행 방향 표시)
                            }]
                        });

                        console.log('Polyline path:', path); // 폴리라인에 사용될 좌표들을 로그로 확인
                    } else {
                        console.warn('No route data found for bus ID:', busId);
                    }
                })
                .catch(error => {
                    console.error('Error fetching bus route:', error);
                });
        }

        function updateBusPositions() {
            var promises = busIds.map(function(busId) {
                var apiUrl = 'https://api.odsay.com/v1/api/realtimeRoute?apiKey=' + apiKey + '&lang=0&busID=' + busId + '&busBase=0&lowBus=0';
                return fetch(apiUrl)
                    .then(response => response.json());
            });

            Promise.all(promises).then(results => {
                var allBuses = [];
                results.forEach(data => {
                    console.log('Bus data:', data); // API 응답 데이터 로그 출력
                    if (data.result && data.result.real) {
                        allBuses = allBuses.concat(data.result.real);
                    } else {
                        console.warn('Unexpected API response:', data);
                    }
                });
                displayBusPositions(allBuses);
            }).catch(error => {
                console.error('Error fetching bus positions:', error);
            });
        }

		function displayBusPositions(buses) {
		    clearBusMarkers();

		    buses.forEach(function(bus) {
		        if (bus && bus.positionY && bus.positionX) {
		            var lat = parseFloat(bus.positionY);
		            var lng = parseFloat(bus.positionX);

		            console.log("Bus data:", bus);

		            var busNumber = bus.busPlateNo || "정보 없음";
		            var fromStationId = bus.fromStationId || "정보 없음";
		            var toStationId = bus.toStationId || "정보 없음";

		            var fromStation = stationMap[fromStationId] || "정보 없음";
		            var toStation = stationMap[toStationId] || "정보 없음";
		            var congestionLevel = bus.congestion;

		            // 도착 예정 시간 가져오기
		            fetchArrivalTime(fromStationId, function(arrivalTime) {
		                if (!isNaN(lat) && !isNaN(lng)) {
		                    var marker = new naver.maps.Marker({
		                        position: new naver.maps.LatLng(lat, lng),
		                        map: map,
		                        icon: {
		                            url: "../img/busmarker.png",
		                            size: new naver.maps.Size(35, 35),
		                            origin: new naver.maps.Point(0, 0),
		                            anchor: new naver.maps.Point(16, 32),
		                        },
		                        title: '버스 ' + busNumber
		                    });

		                    var infoWindowContent = 
		                        '<div style="padding:10px;">' +
		                        '<h4>버스 번호: ' + busNumber + '</h4>' +
		                        '<p>이전 정류장: ' + fromStation + '</p>' +
		                        '<p>다음 정류장: ' + toStation + '</p>' +
		                        '<p>도착 예정 시간: ' + arrivalTime + '</p>' +
		                        '<p>혼잡도: ' + getCongestionLevel(congestionLevel) + '</p>' +
		                        '</div>';

		                    console.log("Info window content:", infoWindowContent);

		                    var infoWindow = new naver.maps.InfoWindow({
		                        content: infoWindowContent
		                    });

		                    naver.maps.Event.addListener(marker, 'click', function(e) {
		                        infoWindow.open(map, marker);
		                    });

		                    busMarkers.push(marker);
		                } else {
		                    console.warn('Invalid bus coordinates:', lat, lng);
		                }
		            });
		        } else {
		            console.warn('Invalid bus data:', bus);
		        }
		    });
		}

		function fetchArrivalTime(stationId, callback) {
		    var apiUrl = 'https://api.odsay.com/v1/api/realtimeStation?lang=0&stationID=' + stationId + '&stationBase=0&lowBus=0&apiKey=' + apiKey;

		    fetch(apiUrl)
		        .then(response => response.json())
		        .then(data => {
		            if (data.result && data.result.real && data.result.real[0] && data.result.real[0].arrival1) {
		                var arrivalSec = data.result.real[0].arrival1.arrivalSec;
		                var arrivalTime = Math.ceil(arrivalSec / 60) + "분 후"; // 도착 시간(분 단위로 변환)
		                callback(arrivalTime);
		            } else {
		                callback("정보 없음");
		            }
		        })
		        .catch(error => {
		            console.error('Error fetching arrival time:', error);
		            callback("정보 없음");
		        });
		}

		function getCongestionLevel(congestion) {
		    switch(congestion) {
		        case 1: 
		            return '<span style="color: lightgreen;"><b>여유</b></span>';
		        case 2: 
		            return '<span style="color: green;"><b>보통</b></span>';
		        case 3: 
		            return '<span style="color: orange;"><b>혼잡</b></span>';
		        case 4: 
		            return '<span style="color: red;"><b>매우 혼잡</b></span>';
		        default: 
		            return '<span style="color: gray;"><b>정보 없음</b></span>';
		    }
		}


        function clearBusMarkers() {
            // 기존 버스 마커 제거
            for (var i = 0; i < busMarkers.length; i++) {
                busMarkers[i].setMap(null);
            }
            busMarkers = [];
        }

        // 지도 초기화 함수 호출
        initMap();
    </script>
</body>
</html>
