<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
    Integer userid = (Integer) session.getAttribute("userid");
    String username = (String) session.getAttribute("username");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Q&A</title>
    <style>
        .con {
            margin: auto;
            width: 1200px;
        }
        .qna-table {
            margin: auto;
            width: 100%;
            max-width: 1200px;
            border-radius: 5px;
            border-collapse: collapse;
            border-top: none;
            table-layout: fixed; /* 테이블 레이아웃 고정 */
        }
        .header {
            background-color: rgb(226, 240, 217);
            text-align: center;
        }
        .qna-table td, .qna-table th {
            height: 30px;
            font-size: 14px;
            padding: 10px;
            text-align: center;
        }
        .qnaNo {
            width: 10%; /* 번호 열의 너비 고정 */
        }
        .qnaTitle {
            width: 40%; /* 제목 열의 너비 고정 */
        }
        .qnaWriter {
            width: 10%; /* 작성자 열의 너비 고정 */
        }
        .qnaRegDate {
            width: 15%; /* 등록일자 열의 너비 고정 */
        }
        .qnaHit {
            width: 10%; /* 조회수 열의 너비 고정 */
        }
		.qnaStatus {
			width: 15%; /* 조회수 열의 너비 고정 */
		}
        .body {
            text-align: center;
        }
        .body .title {
            text-align: left;
        }
        button {
            width: auto;
            font-size: 15px;
            border: 0;
            outline: 1.5px gray solid;
            border-radius: 5px;
            padding-left: 10px;
        }
        .atag {
            text-decoration: none;
        }
        .atag:hover {
            text-decoration: underline;
        }
        .typeBox {
            height: 40px;
            font-size: 16px;
        }
        .inputSearch {
            width: 200px;
            height: 40px;
            font-size: 16px;            
        }
        .submitBtn {
            font-size: 16px;
            width: 60px;
            height: 40px;
        }
        .submitBtn:hover {
            background-color: rgb(21, 115, 71) !important;
        }
		.badge {
			font-size: 12px; /* 크기를 줄임 */
		  	padding: 3px 5px;
		  	line-height: 1;
		}
    </style>
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />
    <div class="con">
        <h1>Q&A</h1>
        <br>
        <!-- search -->
        <div class="position-relative m-3 qna-search">
            <form action="${contextPath}/qnaList.do" method="get" id="search" name="search" class="d-flex align-items-center">
                <select class="form-select me-2" id="searchType" name="searchType" style="width: 150px;">
                    <option value="title" ${search.searchType == 'title' ? 'selected' : ''}>제목</option>
                    <option value="writer" ${search.searchType == 'writer' ? 'selected' : ''}>작성자</option>
                    <option value="content" ${search.searchType == 'content' ? 'selected' : ''}>내용</option>
                </select>
                <input type="text" class="form-control me-2" name="keyword" value="${search.keyword}" placeholder="검색어를 입력해주세요." style="width: 300px;">
                <button type="submit" class="btn btn-success">검색</button>
            </form>
        </div>   
        
        <table class="qna-table">
            <tr class="header text-center">
                <td class="qnaNo">번호</td>
                <td class="qnaTitle">제목</td>
                <td class="qnaWriter">작성자</td>
                <td class="qnaRegDate">등록일자</td>
                <td class="qnaHit">조회수</td>
				<td class="qnaStatus">답변상태</td> 
            </tr>
			<c:forEach items="${qnaList}" var="qna">
			    <tr class="text-center">
			        <td>${qna.qno}</td>
			        <td class="text-start">
						<a href="${contextPath}/qnaDetail.do?qno=${qna.qno}" class="atag text-black">${qna.qtitle}</a>
						<c:if test="${qna.reply_count > 0}">
							<span class="badge bg-success">${qna.reply_count}</span>
						</c:if>	
					</td>
			        <td>${qna.username}</td>
			        <td>${qna.qdate}</td>
			        <td>${qna.qhit}</td>
			        <td>
						<c:choose>
						    <c:when test="${qna.reply_count > 0}">
						        <span class="text-success"><strong>답변완료</strong></span>
						    </c:when>
						    <c:otherwise>
						        <strong>답변대기</strong>
						    </c:otherwise>
						</c:choose>
					</td>
			    </tr>
			</c:forEach>
        </table>
        <br>
        
		<!-- pagination -->
		<div id="paginationBox" class="pagination1">
		    <ul class="pagination justify-content-center">
		        <!-- 처음 -->
		        <li class="page-item ${pagination.page == 1 || pagination.totalPage == 0 ? 'disabled' : ''}">
		            <a class="page-link btn btn-success mx-1" href="?page=1&searchType=${search.searchType}&keyword=${search.keyword}">처음</a>
		        </li>

		        <!-- 이전 -->
		        <li class="page-item ${pagination.page == 1 || pagination.totalPage == 0 ? 'disabled' : ''}">
		            <a class="page-link btn btn-success mx-1" href="?page=${pagination.page - 1}&searchType=${search.searchType}&keyword=${search.keyword}">이전</a>
		        </li>

		        <!-- 페이지 번호 -->
		        <c:forEach begin="${pagination.startPage}" end="${pagination.endPage}" var="i">
		            <li class="page-item ${pagination.page == i ? 'active' : ''}">
		                <c:if test="${pagination.page == i}">
		                    <a class="page btn btn-secondary mx-1 disabled" href="#">${i}</a>
		                </c:if>
		                <c:if test="${pagination.page != i}">
		                    <a class="page btn btn-success mx-1" href="?page=${i}&searchType=${search.searchType}&keyword=${search.keyword}">${i}</a>
		                </c:if>
		            </li>
		        </c:forEach>

		        <!-- 다음 -->
		        <li class="page-item ${pagination.page == pagination.totalPage || pagination.totalPage == 0 ? 'disabled' : ''}">
		            <a class="page-link btn btn-success mx-1" href="?page=${pagination.page + 1}&searchType=${search.searchType}&keyword=${search.keyword}">다음</a>
		        </li>

		        <!-- 끝 -->
		        <li class="page-item ${pagination.page == pagination.totalPage || pagination.totalPage == 0 ? 'disabled' : ''}">
		            <a class="page-link btn btn-success mx-1" href="?page=${pagination.totalPage}&searchType=${search.searchType}&keyword=${search.keyword}">끝</a>
		        </li>
		    </ul>
		</div>

        <!-- 등록 버튼 -->
        <div>
			<c:if test="${(level == 'user')}">
	            <button class="btn btn-success buttonAdd" onclick="location.href='${contextPath}/qnaAdd.do?userid=${userid}'">등록</button>
    		</c:if>
		</div>
    </div>
    <jsp:include page="footer.jsp" />
</body>
</html>
