<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>네이버 지도에 실시간 지하철 위치 표시</title>
<!-- 네이버 Web Dynamic Map API 호출 -->
<script type="text/javascript" src="https://oapi.map.naver.com/openapi/v3/maps.js?ncpClientId=8jkyz2i5z7"></script>
<!-- CSS 스타일 설정 -->
<style>
    .container {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        margin: 0;
        padding: 0;
    }
    #content {
        display: flex;
        width: 100%;
    }
    #map {
        width: 75%; /* 지도 영역 넓이를 75%로 설정 */
        height: 550px;
    }
    #lineList {
        width: 25%; /* 호선 목록 넓이를 25%로 설정 */
        margin-left: 20px;
        box-sizing: border-box;
    }
    .custom-marker {
        display: flex;
        align-items: center;
    }
	#stationSelect {
	    width: 100%;
	    padding: 10px;
	    border-radius: 5px;
	    border: 1px solid #ccc;
	    font-size: 1em;
	}
</style>
</head>
<body>
	<form id="stationForm">        
	    <select id="stationSelect" onchange="moveStation()">
	        <option value="">--기차역을 선택하세요--</option>
	        <option value="37.555167,126.970833">서울역</option>
	        <option value="37.595583,127.08575">상봉역</option>
	        <option value="37.529706,126.964744">용산역</option>
	        <option value="37.580861,127.048389">청량리역</option>
	        <option value="37.4874685,127.1013245">수서역</option>
	        <option value="37.515278,126.907561">영등포역</option>
	        <option value="37.623056,127.061389">광운대역</option>
	        <option value="37.561194,127.037444">왕십리역</option>
	        <option value="37.541694,127.017278">옥수역</option>
	    </select>
	</form>
	<br>
    <div id="content">
        <div id="map"></div>
        <div id="lineList">
            <h3>지하철 호선 목록</h3>
            <select id="lineSelect" onchange="loadLineData()">
                <option value="">--호선을 선택하세요--</option>
            </select>
        </div>
    </div>

    <script type="text/javascript">
        var map;
        var markers = {};
        var apiKey = "694c586a4b6b696a353557574d4b4e"; 
        var coordCache = {}; 
        var distCache = {}; 
        var currentLine = ''; 
        var refreshInterval = 10000;
        var markerIcon = '';

		var lineColors = {
		    "1001": "#0052A4", // 1호선
		    "1002": "#00A84D", // 2호선
		    "1003": "#EF7C1C", // 3호선
		    "1004": "#00A4E3", // 4호선
		    "1005": "#996CAC", // 5호선
		    "1006": "#CD7C2F", // 6호선
		    "1007": "#747F00", // 7호선
		    "1008": "#EA545D", // 8호선
		    "1009": "#BB8336", // 9호선
		    "1061": "#0052A4", // 중앙선
		    "1063": "#77C4A3", // 경의중앙선
		    "1065": "#0090D2", // 공항철도
		    "1067": "#178C72", // 경춘선
		    "1075": "#FABE00", // 수인분당선
		    "1077": "#D4003B", // 신분당선
		    "1092": "#B7C450", // 우이신설선
		    "1032": "#9A6292"  // GTX-A
		};

        var lineIcons = {
            "1호선": "../img/1호선.png",
            "2호선": "../img/2호선.png",
            "3호선": "../img/3호선.png",
            "4호선": "../img/4호선.png",
            "5호선": "../img/5호선.png",
            "7호선": "../img/7호선.png",
            "공항철도": "../img/공항철도.png",
            "경의중앙선": "../img/경의중앙선.png",
            "경춘선": "../img/경춘선.png",
            "수인분당선": "../img/수인분당선.png",
            "GTX-A": "../img/GTX-A.png",
        };

        var stationLines = {
            "서울역": ["1호선", "4호선", "공항철도", "경의중앙선"],
            "상봉역": ["7호선", "경의중앙선", "경춘선"],
            "용산역": ["1호선", "경의중앙선"],
            "청량리역": ["1호선", "경의중앙선", "수인분당선", "경춘선"],
            "수서역": ["3호선", "수인분당선", "GTX-A"],
            "영등포역": ["1호선"],
            "광운대역": ["1호선", "경춘선"],
            "왕십리역": ["2호선", "5호선", "수인분당선", "경의중앙선"],
            "옥수역": ["3호선", "경의중앙선"]
        };

        var infoWnd = new naver.maps.InfoWindow({
            borderWidth: 1,
            borderColor: '#333',
            backgroundColor: '#fff',
            disableAutoPan: true
        });

        // 네이버 지도 초기화 및 지하철 역 좌표와 거리 정보 불러오기
        function initMap() {
            map = new naver.maps.Map('map', {
                center: new naver.maps.LatLng(37.5666103, 126.9783882),
                zoom: 12
            });

            // 지하철 역 좌표 정보를 로드
            loadCoords(function() {
                // 지하철 역 사이의 거리 정보를 로드
                loadDistances(function() {
                });
            });
        }

        // 사용자가 선택한 기차역으로 지도 이동
        function moveStation() {
            var selectElem = document.getElementById("stationSelect");
            var val = selectElem.value;
            var station = selectElem.options[selectElem.selectedIndex].text;

            if (val) {
                var coords = val.split(',');
                var lat = parseFloat(coords[0]);
                var lng = parseFloat(coords[1]);
                var pos = new naver.maps.LatLng(lat, lng);

                map.setCenter(pos);
                map.setZoom(16);

                updateLineList(station);
            }
        }

        // 선택한 기차역에 해당하는 호선 목록을 업데이트
        function updateLineList(station) {
            var selectElem = document.getElementById("lineSelect");
            selectElem.innerHTML = "<option value=''>--호선을 선택하세요--</option>";

            if (stationLines[station]) {
                stationLines[station].forEach(function(line) {
                    var opt = document.createElement("option");
                    opt.value = line;
                    opt.text = line;

                    if (lineColors[line]) {
                        opt.style.color = lineColors[line];
                    }

                    selectElem.appendChild(opt);
                });
            }
        }

        // 선택한 호선의 데이터를 불러오고 지도에 마커 표시
        function loadLineData() {
            var selectElem = document.getElementById('lineSelect');
            currentLine = selectElem.value;
			
			infoWnd.close();

            if (currentLine) {
                clearMarkers();
                markerIcon = lineIcons[currentLine];
                if (!markerIcon) {
                    console.error('Marker icon for selected line not found.');
                    return;
                }
                
                // 실시간 위치 및 도착 정보 갱신
                refreshTrainData();
                map.setZoom(13);
                setInterval(refreshTrainData, refreshInterval); // 일정 간격으로 갱신
            }
        }

        // 기존 마커를 모두 제거
        function clearMarkers() {
            for (var train in markers) {
                if (markers.hasOwnProperty(train)) {
                    markers[train].setMap(null);
                }
            }
            markers = {};
        }

        // 서울시 역사마스터 정보 API를 사용하여 지하철 역 좌표 정보 불러오기
        function loadCoords(callback) {
            console.log("Loading station coordinates...");
            var apiUrl = 'http://openapi.seoul.go.kr:8088/' + apiKey + '/xml/subwayStationMaster/1/1000/'; 

            var xhr = new XMLHttpRequest();
            xhr.open('GET', apiUrl, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4) {
                    if (xhr.status == 200) {
                        console.log("Station coordinates API response: ", xhr.responseText);
                        var parser = new DOMParser();
                        var xmlDoc = parser.parseFromString(xhr.responseText, "application/xml");
                        var rows = xmlDoc.getElementsByTagName("row");
                        for (var i = 0; i < rows.length; i++) {
                            var row = rows[i];
                            var name = row.getElementsByTagName("BLDN_NM")[0].textContent;
                            var route = row.getElementsByTagName("ROUTE")[0].textContent;
                            var lat = parseFloat(row.getElementsByTagName("LAT")[0].textContent);
                            var lot = parseFloat(row.getElementsByTagName("LOT")[0].textContent);
                            coordCache[name] = { lat: lat, lot: lot, route: route };
                        }
                        callback();
                    } else {
                        console.error('Station coordinates API error: ' + xhr.status);
                    }
                }
            };
            xhr.send();
        }

        // 서울교통공사 역간 거리 및 소요시간 정보 API를 사용하여 지하철 역 간 거리 및 소요 시간 정보 불러오기
        function loadDistances(callback) {
            console.log("Loading station distances...");
            var apiUrl = 'http://openapi.seoul.go.kr:8088/' + apiKey + '/xml/StationDstncReqreTimeHm/1/1000/'; 

            var xhr = new XMLHttpRequest();
            xhr.open('GET', apiUrl, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4) {
                    if (xhr.status == 200) {
                        console.log("Station distances API response: ", xhr.responseText);
                        var parser = new DOMParser();
                        var xmlDoc = parser.parseFromString(xhr.responseText, "application/xml");
                        var rows = xmlDoc.getElementsByTagName("row");
                        for (var i = 0; i < rows.length; i++) {
                            var row = rows[i];
                            var route = row.getElementsByTagName("SBWY_ROUT_LN")[0].textContent;
                            var name = row.getElementsByTagName("SBWY_STNS_NM")[0].textContent;
                            var dist = parseFloat(row.getElementsByTagName("DIST_KM")[0].textContent);
                            var time = row.getElementsByTagName("HM")[0].textContent;
                            if (!distCache[route]) {
                                distCache[route] = {};
                            }
                            distCache[route][name] = {
                                dist: dist,
                                time: time
                            };
                        }
                        callback();
                    } else {
                        console.error('Station distances API error: ' + xhr.status);
                    }
                }
            };
            xhr.send();
        }

        // 실시간 지하철 위치 및 도착 정보를 가져와 지도에 표시
		// 서울시 지하철 실시간 도착정보(일괄) API, 서울시 지하철 실시간 열차 위치정보 API
        function refreshTrainData() {
            var lineName = encodeURIComponent(currentLine);
            var posApiUrl = 'http://swopenAPI.seoul.go.kr/api/subway/' + apiKey + '/xml/realtimePosition/0/100/' + lineName;
            var arrApiUrl = 'http://swopenAPI.seoul.go.kr/api/subway/' + apiKey + '/xml/realtimeStationArrival/1/1001/ALL';

            // 두 API를 동시에 호출하여 실시간 정보 가져오기
            Promise.all([
                fetch(posApiUrl).then(response => response.text()),
                fetch(arrApiUrl).then(response => response.text())
            ])
            .then(([posResponse, arrResponse]) => {
                var posXmlDoc = new DOMParser().parseFromString(posResponse, "application/xml");
                var arrXmlDoc = new DOMParser().parseFromString(arrResponse, "application/xml");

                // 위치 정보와 도착 정보를 동기화하여 지도에 표시
                updateTrainPos(posXmlDoc, arrXmlDoc);
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
        }

		// 실시간 지하철 위치 정보를 도착 정보와 비교하여 지도에 마커로 표시
		function updateTrainPos(posXml, arrXml) {
		    var posRows = posXml.getElementsByTagName("row");
		    var arrRows = arrXml.getElementsByTagName("row");

		    for (var i = 0; i < posRows.length; i++) {
		        var posRow = posRows[i];
		        var trainElem = posRow.getElementsByTagName("trainNo")[0];
		        var stationElem = posRow.getElementsByTagName("statnNm")[0];

		        if (trainElem && stationElem) {
		            var train = trainElem.textContent.trim();
		            var station = stationElem.textContent.trim();

		            console.log("Location API Station Name: ", station); 

		            // 도착 정보를 역명과 열차 번호로 매칭
		            var matchingArrInfo = null;
		            for (var j = 0; j < arrRows.length; j++) {
		                var arrRow = arrRows[j];
		                var arrTrainElem = arrRow.getElementsByTagName("btrainNo")[0];
		                var arrStationElem = arrRow.getElementsByTagName("statnNm")[0];

		                if (arrTrainElem && arrStationElem) {
		                    var arrTrain = arrTrainElem.textContent.trim();
		                    var arrStation = arrStationElem.textContent.trim();

		                    if (train === arrTrain && station === arrStation) {
		                        matchingArrInfo = arrRow;
		                        break;
		                    }
		                }
		            }

		            if (matchingArrInfo) {
		                console.log("Arrival Info API Station Name: ", matchingArrInfo.getElementsByTagName("statnNm")[0].textContent);
		                // 마커 업데이트 로직 호출
		                updateMarker(train, station, matchingArrInfo);
		            } else {
		                console.warn(`No matching arrival info found for train ${train} at ${station}`);
		            }
		        } else {
		            console.error('Missing train number or station name in the API response');
		        }
		    }
		}

		// 특정 기차에 대한 마커를 업데이트하고 지도에 표시
		function updateMarker(train, station, arrInfo) {
		    getCoord(station, function(lat, lot, route) {
		        if (lat && lot) {
		            var marker;
		            if (markers[train]) {
		                marker = markers[train];
		                var prevLatLng = marker.getPosition();
		                var dur = calcDuration(route, station);
		                animate(marker, prevLatLng.lat(), prevLatLng.lng(), lat, lot, dur);
		            } else {
		                // 마커가 존재하지 않는 경우 새로 생성
		                marker = new naver.maps.Marker({
		                    position: new naver.maps.LatLng(lat, lot),
		                    map: map,
		                    title: '열차 ' + train + ' - ' + station + ' (' + route + ')',
		                    icon: {
		                        url: markerIcon,
		                        size: new naver.maps.Size(24, 40),
		                        origin: new naver.maps.Point(0, 0),
		                        anchor: new naver.maps.Point(12, 40)
		                    }
		                });

		                markers[train] = marker;

		                naver.maps.Event.addListener(marker, 'click', function(e) {
		                    showArrInfo(train, marker);
		                });
		            }

		            // 도착 정보를 마커에 적용
		            marker.arrInfo = {
		                station: station,
		                lineName: arrInfo.getElementsByTagName("trainLineNm")[0]?.textContent || "정보 없음",
		                arrivalTime: arrInfo.getElementsByTagName("barvlDt")[0]?.textContent || "정보 없음",
		                status: arrInfo.getElementsByTagName("arvlCd")[0]?.textContent || "정보 없음",
		                subwayId: arrInfo.getElementsByTagName("subwayId")[0]?.textContent || "undefined"  // subwayId 추가
		            };
		        } else {
		            console.warn('Coordinates not found for station: ' + station);
		        }
		    });
		}
		
		// 특정 마커를 클릭했을 때 도착 정보를 표시
		function showArrInfo(train, marker) {
		    if (marker.arrInfo) {
		        var info = marker.arrInfo;
		        
		        // subwayId를 사용하여 호선 색상을 가져옴
		        var subwayId = info.subwayId; // 도착 정보에서 지하철호선ID를 가져옴
		        var bgColor = lineColors[subwayId] || '#ffffff';  // 호선 ID에 따른 색상 또는 기본 흰색 설정
		        
		        // 디버깅을 위한 로그 출력
		        console.log('Subway ID:', subwayId);
		        console.log('Background Color:', bgColor);

		        // 텍스트 색상을 흰색 또는 검은색으로 설정 (배경색에 따라 대비되는 색상 선택)
		        var txtColor = isDark(bgColor) ? '#ffffff' : '#000000';

		        var contentStr = 
		            '<div style="padding:10px; font-size:12px;">' +
		                '<h4 style="margin:0; padding:10px; background-color:' + bgColor + '; color: ' + txtColor + ';">지하철 번호: ' + train + '</h4>' +
		                '<p style="margin:0;">현재 위치: ' + info.station + '</p>' +
		                '<p style="margin:0;">노선(목적지역-다음역): ' + info.lineName + '</p>' +
		                '<p style="margin:0;">도착 예정 시간: ' + info.arrivalTime + ' 초</p>' +
		                '<p style="margin:0;">상태: ' + getStatus(info.status) + '</p>' +
		            '</div>';

		        infoWnd.setContent(contentStr);
		        infoWnd.open(map, marker);
		    } else {
		        console.warn('No arrival info available for marker:', marker);
		    }
		}

		// 배경색이 어두운지 밝은지 판단하는 함수
		function isDark(color) {
		    var r = parseInt(color.slice(1, 3), 16);
		    var g = parseInt(color.slice(3, 5), 16);
		    var b = parseInt(color.slice(5, 7), 16);
		    var brightness = (r * 299 + g * 587 + b * 114) / 1000;
		    return brightness < 128;
		}
		
		// 지하철 도착 상태를 코드에 따라 반환하는 함수
		function getStatus(statusCode) {
		    switch(statusCode) {
		        case '0': return '진입 중';
		        case '1': return '도착';
		        case '2': return '출발';
		        case '3': return '전역 출발';
		        case '4': return '전역 진입';
		        case '5': return '전역 도착';
		        case '99': return '운행 중';
		        default: return '정보 없음';
		    }
		}

        // 특정 역에 대한 좌표를 가져오는 함수
        function getCoord(station, callback) {
            if (coordCache[station]) {
                var data = coordCache[station];
                var lat = parseFloat(data.lat);
                var lot = parseFloat(data.lot);

                if (!isNaN(lat) && !isNaN(lot)) {
                    callback(lat, lot, data.route);
                } else {
                    console.error('Invalid coordinates for station: ' + station);
                    callback(null, null, null);
                }
            } else {
                console.error('Station not found in cache: ' + station);
                callback(null, null, null);
            }
        }

        // 특정 역에 대한 애니메이션 지속 시간을 계산하는 함수
        function calcDuration(route, station) {
            if (distCache[route] && distCache[route][station]) {
                var timeStr = distCache[route][station].time;
                var timeParts = timeStr.split(':');
                var mins = parseInt(timeParts[0]) * 60 + parseInt(timeParts[1]);
                return mins * 1000;
            }
            return 2000;
        }

        // 마커를 애니메이션으로 이동시키는 함수
        function animate(marker, startLat, startLng, endLat, endLng, duration) {
            var startTime = Date.now();
            var startLatLng = new naver.maps.LatLng(startLat, startLng);
            var endLatLng = new naver.maps.LatLng(endLat, endLng);

            function moveMarker() {
                var elapsedTime = Date.now() - startTime;
                var progress = elapsedTime / duration;

                if (progress < 1) {
                    var currentLat = startLat + (endLat - startLat) * progress;
                    var currentLng = startLng + (endLng - startLng) * progress;
                    marker.setPosition(new naver.maps.LatLng(currentLat, currentLng));
                    requestAnimationFrame(moveMarker);
                } else {
                    marker.setPosition(endLatLng);
                }
            }

            moveMarker();
        }

        initMap(); // 초기화 함수 호출
    </script>

    </div>
</body>
</html>
