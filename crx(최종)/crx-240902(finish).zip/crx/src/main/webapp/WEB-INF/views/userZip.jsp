<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <!-- 우편번호 입력란 -->
    <input type="text" id="sample6_postcode_user" style="width:100px" placeholder="우편번호">
    <input type="button" onclick="zipcodeUser()" value="주소검색"><br>

    <!-- 주소 입력란 -->
    <input type="text" id="sample6_address_user" style="width:400px" placeholder="주소" onchange="updateUserAdd()"><br>
  
    <!-- 상세주소 입력란 -->
    <input type="text" id="sample6_detailAddress_user" placeholder="상세주소" onchange="updateUserAdd()">
  
    <!-- 참고주소 -->
    <input type="hidden" id="sample6_extraAddress_user" placeholder="참고주소">
  
    <!-- 히든 필드에 user 관련 name 속성 설정 -->
    <input type="hidden" name="userpost" id="userpost">
    <input type="hidden" name="useradd" id="useradd">
</body>

<!-- 다음 우편번호 서비스 스크립트 -->
<script src="//t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
<script>
    function zipcodeUser() {
        new daum.Postcode({
            oncomplete: function(data) {
                var addr = ''; 
                var extraAddr = ''; 

                if (data.userSelectedType === 'R') { 
                    addr = data.roadAddress;
                } else { 
                    addr = data.jibunAddress;
                }

                if (data.userSelectedType === 'R') {
                    if (data.bname !== '' && /[동|로|가]$/g.test(data.bname)) {
                        extraAddr += data.bname;
                    }
                    if (data.buildingName !== '' && data.apartment === 'Y') {
                        extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                    }
                    if (extraAddr !== '') {
                        extraAddr = ' (' + extraAddr + ')';
                    }
                    document.getElementById("sample6_extraAddress_user").value = extraAddr;

                } else {
                    document.getElementById("sample6_extraAddress_user").value = '';
                }

                document.getElementById('sample6_postcode_user').value = data.zonecode;
                document.getElementById("sample6_address_user").value = addr;
                document.getElementById("sample6_detailAddress_user").focus();
            }
        }).open();
    }

    function updateUserAdd() {
        var postcode = document.getElementById('sample6_postcode_user').value || '';
        var address = document.getElementById('sample6_address_user').value || '';
        var detailAddress = document.getElementById('sample6_detailAddress_user').value || ''; 
        var fullAddress = address + (detailAddress ? ' ' + detailAddress : '');  

        document.getElementById('userpost').value = postcode;
        document.getElementById('useradd').value = fullAddress;
    }

    document.addEventListener("DOMContentLoaded", function() {
        var userPostcode = '${crxVO.userpost}';
        var userAdd = '${crxVO.useradd}';

        if (userPostcode) {
            document.getElementById('sample6_postcode_user').value = userPostcode;
        }

        if (userAdd) {
            var addressParts = userAdd.split(' ');
            var sample6Address = addressParts.slice(0, addressParts.length - 1).join(' ');
            var sample6DetailAddress = addressParts[addressParts.length - 1];

            document.getElementById('sample6_address_user').value = sample6Address;
            document.getElementById('sample6_detailAddress_user').value = sample6DetailAddress;
        }
    });
</script>

<style>
    .wrong_text { 
        font-size: 1rem; 
        color: #f44e38; 
        letter-spacing: -0.2px; 
        font-weight: 300; 
        margin: 8px 0 2px; 
        line-height: 1em; 
        display: none;
    }
</style>
</html>
