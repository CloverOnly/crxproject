<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0" /> 
<meta http-equiv="X-UA-Compatible" content="ie=edge" />
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style>
	* { margin: 0; padding: 0; }
	.birthBox {
		width: 20%;
	}
	.genderBox {
		width: 5%;
	}
	.successPhoneChk {
		color: green;
	}
	.timer {
	    position: absolute;
	    right: 10px;
	    top: 25%; /* 수직 가운데 정렬 */
	    transform: translateY(-50%); /* 수직 가운데 정렬 보정 */
	    color: red;
	    font-weight: bold;
	    display: none;  /* 초기에는 보이지 않도록 설정 */
	}
</style>	
<title>문자(SMS) 인증</title>
</head>
<body>
	<div class="titleBox border border-3 border-success p-2 text-center text-success fs-4 fw-bold">
		<label for="phone"><strong>문자(SMS) 인증</strong></label>
	</div>
	<div class="contentBox border border-3 border-success m-2 p-2">
		<label for="name" class="mt-2"><strong>이름</strong></label><br>
		<input type="text" id="name" name="name" class="nameBox my-2 p-1 w-100 fs-6" title="이름 입력" placeholder="이름을 입력해 주세요." required autofocus/><br>
		
		<label for="birth" class="mt-2"><strong>생년월일/성별</strong></label><br>
		<input type="text" id="birth" name="birth" class="birthBox my-2 p-1 text-center fs-6" title="생년월일 입력" placeholder="• • • • • •" required />
		- <input type="text" id="gender" name="gender" class="genderBox p-1 text-center my-2 fs-6" title="성별 입력" placeholder="•" required /> • • • • • •<br>
		
		<label for="phone" class="mt-2"><strong>휴대폰번호</strong></label><br>
		<div class="phoneSet position-relative">
			<input type="text" id="phone" name="phone" class="phoneBox my-2 p-1 w-100 fs-6" title="휴대폰번호 입력" placeholder="휴대폰번호를 입력해 주세요." required />
			<!-- 타이머 -->
			<span id="timer" class="timer">02:30</span>
			<br>
			<button id="phoneChk" class="btn btn-success w-100 my-2">인증하기</button><br>
		</div>
		<label for="phone2" class="mt-2"><strong>인증번호</strong></label><br>
		<div class="certiSet">
			<input type="text" id="phone2" name="phone2" class="phone2Box my-2 p-1 w-100 fs-6" title="인증번호 입력" placeholder="숫자 6자리를 입력해 주세요." disabled required />
			<button id="phoneChk2" class="btn btn-success w-100 my-2" disabled>확인</button>
			<input type="hidden" id="phoneDoubleChk"/>
			<button class="cancelBox btn btn-secondary w-100 my-2 me-2" id="cancel" name="cancel" onclick="window.close()">취소</button>
			<div id="resultMessage" class="successPhoneChk"></div>
		</div>
	</div>
<script>
	let timerInterval;

	function startTimer(duration, display) {
		let timer = duration, minutes, seconds;
		display.style.display = 'block';  // 타이머 표시
		timerInterval = setInterval(function () {
			minutes = parseInt(timer / 60, 10);
			seconds = parseInt(timer % 60, 10);

			minutes = minutes < 10 ? "0" + minutes : minutes;
			seconds = seconds < 10 ? "0" + seconds : seconds;

			display.textContent = minutes + ":" + seconds;

			if (--timer < 0) {
				clearInterval(timerInterval);
				alert("인증 시간이 만료되었습니다.\n다시 인증해주시기 바랍니다.");
				window.close();
			}
		}, 1000);
	}

	function stopTimer() {
		clearInterval(timerInterval);
	}

	$(document).ready(function() {
		let code2 = "";
		const name_RegExp = /^[가-힣]{2,6}$/;
		const birth_RegExp = /^(0[0-9]|[1-9][0-9])(0[1-9]|[1][0-2])(0[1-9]|[1-2][0-9]|3[0-1])$/;
		const gender_RegExp = /^[1-4]$/;
		const phone_RegExp = /^010-?[0-9]{4}-?[0-9]{4}$/;
		
		// 주민등록번호	
		function isValidResidentNumber(front6, last1) {
			const year = parseInt(front6.substring(0, 2), 10);	// 주민번호 앞 1~2자리
			const month = parseInt(front6.substring(2, 4), 10);	// 주민번호 앞 3~4자리
			const day = parseInt(front6.substring(4, 6), 10);	// 주민번호 앞 5~6자리

			if (month < 1 || month > 12) {
				return false;
			}

			const fullYear = year >= 0 && year <= 99 ? (year <= new Date().getFullYear() % 100 ? 2000 + year : 1900 + year) : null;
			const isLeapYear = (fullYear % 4 === 0 && fullYear % 100 !== 0) || (fullYear % 400 === 0);

			const daysInMonth = [31, (isLeapYear ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
			if (day < 1 || day > daysInMonth[month - 1]) {
				return false;
			}

			if (month === 2 && day > (isLeapYear ? 29 : 28)) {
				return false;
			}

			const genderDigit = parseInt(last1, 10);		// 주민번호 뒤 1자리
			const currentYear = new Date().getFullYear();	// 현재 날짜
			
			// 2000년을 기준으로 성별 코드 검사
		    if (fullYear < 2000) {
		        if (![1, 2].includes(genderDigit)) {
		            return false;
		        }
		    } else if (fullYear >= 2000 && fullYear <= currentYear) {
		        if (![3, 4].includes(genderDigit)) {
		            return false;
		        }
		    } else {
		        return false;
		    }
			return true;
		}
		
		function validateForm() {
			// 이름
			const name = $("#name").val();
			if (!name_RegExp.test(name)) {
				alert("한글 2~6자만 입력해 주세요.\n예) 김의겸");
				$("#name").focus();
				return false;
			}
			
			// 주민등록번호(생년월일 + 성별)
			const birth = $("#birth").val();
			const gender = $("#gender").val();
			if (!isValidResidentNumber(birth, gender)) {
				alert("주민등록번호 앞 6자리 또는 뒤 1자리를 올바르게 작성해 주세요.\n예) 930403");
				$("#birth").focus();
				return false;
			}
			
			// 휴대폰번호
			const phone = $("#phone").val();
			if (phone == "") {
				alert("휴대폰번호가 입력되지 않았습니다. 휴대폰번호를 입력해주세요.");
				$("#phone").focus();
				$("#phone2").attr("disabled",true);
				$("#phone3").attr("disabled",true);
				phone.focus();	
			} else if (!phone_RegExp.test(phone)) {
				alert("올바르지 못한 휴대폰번호가 입력되었습니다. 올바른 휴대폰번호를 입력해주세요.");
				$("#phone").focus();
				return false;
			}
			return true;
		}
		
		$("#phoneChk").click(function() {
			if (!validateForm()) {
				return;
			}
			
			const phone = $("#phone").val();
			alert("인증번호 발송이 완료되었습니다.\n휴대폰에서 인증번호를 확인해주세요.");
			
			// 타이머 시작 (2분 30초 설정)
			let timeLimit = 2 * 60 + 30;  // 2분 30초를 초로 환산
			let display = document.querySelector('#timer');
			startTimer(timeLimit, display);
			
			$.ajax({
				type: "GET",
				url: "/phoneCheck?phone=" + phone,
				cache: false,
				success: function(data) {
					if (data === "error" || data === "") {
						alert("휴대폰번호가 올바르지 않습니다.");
						$("#phone2").attr("disabled", true);
						$("#phoneChk2").attr("disabled", true);
					} else {
						$("#phone2").attr("disabled", false);
						$("#phoneChk2").attr("disabled", false);
						$("#phoneChk2").show();
						code2 = data;
					}
				}
			});
		});
		
		$("#phoneChk2").click(function() {
			const enteredCode = $("#phone2").val();
			if (enteredCode === code2) {
				$("#resultMessage").text("인증번호가 일치합니다.");
				$("#resultMessage").css("color","green");
				$("#phoneDoubleChk").val("true");
				alert("인증이 완료되었습니다.");
				
				// 타이머 중지
				stopTimer();
				
				opener.location.href = '/childSignup.do';
				window.close();
			} else {
				$("#resultMessage").text("인증번호가 일치하지 않습니다. 확인해주시기 바랍니다.");
				$("#resultMessage").css("color","red");
				$("#phoneDoubleChk").val("false");
			}			
		});
	});
</script>
</body>
</html>
