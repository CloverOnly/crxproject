<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <title>KTX 역 선택</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	<style>
		html, body {
		    width: 695px;
		    height: 630px;
		    margin: 0;
		    padding: 0;
		    overflow: hidden;
			position: fixed;
		}
		.lineTitle{
			text-align: center;
			padding-top: 16px;
			margin-top: 16px;
			background: #2979ff;
			color: white;
			margin: 0px;
			position: relative;
		}
		.lineAll{
    		height: 629px;
			border-width: 0px 9px 9px 9px;
			border-style: solid;
			border-color: #2979ff;
		}
		.nav-link {
		    color: black; 
		}
		.nav-link.active {
		    color: #2979ff !important; 
		    font-weight: bold; 
		}
		.nav {
		    margin: 15px;
		}
	    .Gyeongbu {
			background-image: url(../img/map1.jpg);
		    background-size: cover;
		    position: absolute;
			top: 122px;
			left: 158px;
			width: 54%;
			height: 474px;
	    }
		.m1{
			position: absolute;
			top: 184px;
			left: 212px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m2{
			position: absolute;
			top: 195px;
			left: 274px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m3{
			position: absolute;
			top: 234px;
			left: 285px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m4{
			position: absolute;
			top: 243px;
			left: 213px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m5{
			position: absolute;
			top: 280px;
			left: 300px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m6{
			position: absolute;
			right: 379px;
			bottom: 224px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m7{
			position: absolute;
			top: 307px;
			left: 192px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m8{
			position: absolute;
			right: 255px;
			bottom: 232px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m9{
			position: absolute;		
			right: 224px;
			bottom: 211px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m10{
			position: absolute;
			right: 296px;
			bottom: 180px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m11{
			position: absolute;
			right: 274px;
			bottom: 152px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m12{
			position: absolute;
			right: 160px;
			bottom: 218px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m13{
			position: absolute;
			right: 161px;
			bottom: 181px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m14{
			position: absolute;
			right: 164px;
			bottom: 147px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m15{
			position: absolute;
			position: absolute;
			right: 256px;
			bottom: 122px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m16{
			position: absolute;
			right: 182px;
			bottom: 107px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m17{
			position: absolute;
			top: 311px;
			left: 304px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.Honame{
			background-image: url(../img/map2.JPG);
			background-size: cover;
			position: absolute;
			top: 122px;
			left: 158px;
			width: 54%;
			height: 474px;
		}
		.m18{
			position: absolute;
			top: 217px;
			left: 294px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m19{
			position: absolute;
			left: 222px;
			bottom: 259px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m20{
			position: absolute;
			left: 328px;
			bottom: 249px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m21{
			position: absolute;
			left: 228px;
			bottom: 224px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m22{
			position: absolute;
			left: 308px;
			bottom: 217px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m23{
			position: absolute;
			left: 275px;
			bottom: 189px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m24{
			position: absolute;
			left: 198px;
			bottom: 166px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m25{
			position: absolute;
			left: 271px;
			bottom: 115px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m26{
			position: absolute;
			left: 244px;
			bottom: 85px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m27{
			position: absolute;
			left: 174px;
			bottom: 61px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.Gyeonjeon{
			background-image: url(../img/map3.jpg);
			background-size: cover;
			position: absolute;
			top: 122px;
			left: 158px;
			width: 54%;
			height: 474px;
		}
		.m73{
			position: absolute;
			left: 431px;
			bottom: 205px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m74{
			position: absolute;
			left: 336px;
			bottom: 184px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m75{
			position: absolute;
			right: 194px;
			bottom: 174px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m28{
			position: absolute;
			right: 204px;
			bottom: 146px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m29{
			position: absolute;
			right: 184px;
			bottom: 118px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m30{
			position: absolute;
			right: 289px;
			bottom: 141px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m31{
			position: absolute;
			right: 266px;
			bottom: 93px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m32{
			position: absolute;
			right: 335px;
			bottom: 104px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.Jeolla{
			background-image: url(../img/map4.jpg);
			background-size: cover;
			position: absolute;
			top: 122px;
			left: 158px;
			width: 54%;
			height: 474px;
		}
		.m76{
			position: absolute;
			right: 422px;
			    bottom: 190px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m77{
			position: absolute;
			right: 338px;
			bottom: 189px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m33{
			position: absolute;
			right: 337px;
			bottom: 190px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m34{
			position: absolute;
			left: 315px;
			bottom: 156px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m35{
			position: absolute;
			left: 247px;
			bottom: 130px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m36{
			position: absolute;
			left: 317px;
			bottom: 117px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m37{
			position: absolute;
			left: 258px;
			bottom: 86px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m38{
			position: absolute;
			left: 330px;
			bottom: 82px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m39{
			position: absolute;
			left: 314px;
			bottom: 43px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.Gangneung{
			background-image: url(../img/map5.jpg);
			background-size: cover;
			position: absolute;
			top: 122px;
			left: 158px;
			width: 54%;
			height: 474px;
		}
		.m71{
			position: absolute;
			left: 242px;
			top: 196px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m72{
			position: absolute;
			left: 295px;
			top: 200px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m66{
			position: absolute;
			left: 208px;
			top: 219px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m40{
			position: absolute;
			left: 199px;
			top: 222px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m41{
			position: absolute;
			left: 253px;
			top: 237px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m42{
			position: absolute;
			left: 334px;
			top: 225px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m44{
			position: absolute;
			left: 370px;
			top: 200px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m45{
			position: absolute;
			left: 366px;
			top: 259px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m46{
			position: absolute;
			left: 304px;
			top: 267px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m47{
			position: absolute;
			right: 255px;
			top: 284px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m48{
			position: absolute;
			right: 232px;
			top: 246px;
			font-size: 10px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m49{
			position: absolute;
			right: 211px;
			top: 195px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m50{
			position: absolute;
			right: 168px;
			top: 219px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m51{
			position: absolute;
			right: 165px;
			top: 245px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m52{
			position: absolute;
			right: 168px;
			top: 279px;
			font-size: 12px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.jungang{
			background-image: url(../img/map6.jpg);
			background-size: cover;
			position: absolute;
			top: 122px;
			left: 158px;
			width: 54%;
			height: 474px;
		}
		.m68{
			position: absolute;
			left: 221px;
			bottom: 375px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m69{
			position: absolute;
			left: 262px;
			bottom: 406px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m70{
			position: absolute;
			left: 331px;
			bottom: 387px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m53{
			position: absolute;
			left: 282px;
			bottom: 341px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m54{
			position: absolute;
			left: 381px;
			bottom: 356px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m55{
			position: absolute;
			left: 399px;
			bottom: 329px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m56{
			position: absolute;
			left: 346px;
			bottom: 299px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m57{
			position: absolute;
			left: 383px;
			bottom: 273px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m58{
			position: absolute;
			left: 441px;
			bottom: 302px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m59{
			position: absolute;
			left: 446px;
			bottom: 262px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.Jungbunaeryuk{
			background-image: url(../img/map7.jpg);
			background-size: cover;
			position: absolute;
			top: 122px;
			left: 158px;
			width: 54%;
			height: 474px;
		}
		.m60{
			position: absolute;
			left: 236px;
			top: 243px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m61{
			position: absolute;
			left: 315px;
			top: 234px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m62{
			position: absolute;
			left: 339px;
			top: 264px;
			font-size: 13px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m63{
			position: absolute;
			left: 238px;
			top: 290px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m64{
			position: absolute;
			left: 395px;
			top: 284px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
		.m65{
			position: absolute;
			left: 339px;
			top: 311px;
			font-size: 14px;
			background-color: #2979ff;
			color: white;
			border-radius: 6px;
		}
	</style>
</head>
<body>
		<div class="lineAll">
			<div class=lineTitle>
				<h3><strong>KTX</strong></h3>
				<hr>
			</div>
			<nav>
			    <div class="nav nav-tabs" id="nav-tab" role="tablist">
			    	<button class="nav-link active" id="nav-Gyeongbu-tab" data-bs-toggle="tab" data-bs-target="#nav-Gyeongbu" type="button" role="tab" aria-controls="nav-Gyeongbu" aria-selected="true">경부선</button>
			    	<button class="nav-link" id="nav-Honame-tab" data-bs-toggle="tab" data-bs-target="#nav-Honame" type="button" role="tab" aria-controls="nav-Honame" aria-selected="false">호남선</button>
			    	<button class="nav-link" id="nav-Gyeonjeon-tab" data-bs-toggle="tab" data-bs-target="#nav-Gyeonjeon" type="button" role="tab" aria-controls="nav-Gyeonjeon" aria-selected="false">경전선</button>
					<button class="nav-link" id="nav-Jeolla-tab" data-bs-toggle="tab" data-bs-target="#nav-Jeolla" type="button" role="tab" aria-controls="nav-Jeolla" aria-selected="true">전라선</button>
					<button class="nav-link" id="nav-Gangneung-tab" data-bs-toggle="tab" data-bs-target="#nav-Gangneung" type="button" role="tab" aria-controls="nav-Gangneung" aria-selected="false">강릉선</button>
					<button class="nav-link" id="nav-jungang-tab" data-bs-toggle="tab" data-bs-target="#nav-jungang" type="button" role="tab" aria-controls="nav-jungang" aria-selected="false">중앙선</button>
					<button class="nav-link" id="nav-Jungbunaeryuk-tab" data-bs-toggle="tab" data-bs-target="#nav-Jungbunaeryuk" type="button" role="tab" aria-controls="nav-Jungbunaeryuk" aria-selected="false">중부내륙선</button>
				</div>
			</nav>
			<div class="tab-content" id="nav-tabContent">
			    <div class="tab-pane fade show active" id="nav-Gyeongbu" role="tabpanel" aria-labelledby="nav-Gyeongbu-tab" tabindex="0">
					<div>
						<div class="Gyeongbu"></div>
						<input type="button" name="stationName" class="m1" onclick="setParentText(this)" value="행신역" data-value="NAT110147">  
						<input type="button" name="stationName" class="m2" onclick="setParentText(this)" value="서울역" data-value="NAT010000">  
						<input type="button" name="stationName" class="m3" onclick="setParentText(this)" value="영등포역" data-value="NAT010091">  
						<input type="button" name="stationName" class="m4" onclick="setParentText(this)" value="광명역" data-value="NATH10219">  
						<input type="button" name="stationName" class="m5" onclick="setParentText(this)" value="수원역" data-value="NAT010415">  
						<input type="button" name="stationName" class="m6" onclick="setParentText(this)" value="대전역" data-value="NAT011668">  
						<input type="button" name="stationName" class="m7" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
						<input type="button" name="stationName" class="m8" onclick="setParentText(this)" value="김천역" data-value="NAT012546">  
						<input type="button" name="stationName" class="m9" onclick="setParentText(this)" value="동대구역" data-value="NAT013271">  
						<input type="button" name="stationName" class="m10" onclick="setParentText(this)" value="서대구역" data-value="NAT013189">  
						<input type="button" name="stationName" class="m11" onclick="setParentText(this)" value="밀양역" data-value="NAT013841">  
						<input type="button" name="stationName" class="m12" onclick="setParentText(this)" value="포항역" data-value="NAT8B0351">  
						<input type="button" name="stationName" class="m13" onclick="setParentText(this)" value="경주역" data-value="NAT023821">  
						<input type="button" name="stationName" class="m14" onclick="setParentText(this)" value="울산역" data-value="NATH13717">  
						<input type="button" name="stationName" class="m15" onclick="setParentText(this)" value="구포역" data-value="NAT014281">  
						<input type="button" name="stationName" class="m16" onclick="setParentText(this)" value="부산역" data-value="NAT014445">
						<input type="button" name="stationName" class="m17" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  

					</div>	
				</div>
			    <div class="tab-pane fade" id="nav-Honame" role="tabpanel" aria-labelledby="nav-Honame-tab" tabindex="0">
					<div class="tab-pane fade show active" id="nav-Gyeongbu" role="tabpanel" aria-labelledby="nav-Gyeongbu-tab" tabindex="0">
						<div class="Honame"></div>
						<input type="button" name="stationName" class="m1" onclick="setParentText(this)" value="행신역" data-value="NAT110147">  
						<input type="button" name="stationName" class="m18" onclick="setParentText(this)" value="용산역" data-value="NAT010032">  
						<input type="button" name="stationName" class="m4" onclick="setParentText(this)" value="광명역" data-value="NATH10219">  
						<input type="button" name="stationName" class="m7" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
						<input type="button" name="stationName" class="m17" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  
						<input type="button" name="stationName" class="m19" onclick="setParentText(this)" value="공주역" data-value="NATH20438">  
						<input type="button" name="stationName" class="m20" onclick="setParentText(this)" value="서대전역" data-value="NAT030057">  
						<input type="button" name="stationName" class="m21" onclick="setParentText(this)" value="논산역" data-value="NAT030508">  
						<input type="button" name="stationName" class="m22" onclick="setParentText(this)" value="계룡역" data-value="NAT030254">  
						<input type="button" name="stationName" class="m23" onclick="setParentText(this)" value="익산역" data-value="NAT030879">  
						<input type="button" name="stationName" class="m24" onclick="setParentText(this)" value="정읍역" data-value="NAT031314">  
						<input type="button" name="stationName" class="m25" onclick="setParentText(this)" value="광주송정역" data-value="NAT031857">  
						<input type="button" name="stationName" class="m26" onclick="setParentText(this)" value="나주역" data-value="NAT031998">  
						<input type="button" name="stationName" class="m27" onclick="setParentText(this)" value="목포역" data-value="NAT032563">	
					</div>
				</div>
			    <div class="tab-pane fade" id="nav-Gyeonjeon" role="tabpanel" aria-labelledby="nav-Gyeonjeon-tab" tabindex="0">
					<div class="Gyeonjeon"></div>
					<input type="button" name="stationName" class="m1" onclick="setParentText(this)" value="행신역" data-value="NAT110147">  
					<input type="button" name="stationName" class="m2" onclick="setParentText(this)" value="서울역" data-value="NAT010000">  
					<input type="button" name="stationName" class="m4" onclick="setParentText(this)" value="광명역" data-value="NATH10219">  
					<input type="button" name="stationName" class="m7" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
					<input type="button" name="stationName" class="m17" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  
					<input type="button" name="stationName" class="m6" onclick="setParentText(this)" value="대전역" data-value="NAT011668">  
					<input type="button" name="stationName" class="m8" onclick="setParentText(this)" value="김천역" data-value="NAT012546">  
					<input type="button" name="stationName" class="m73" onclick="setParentText(this)" value="동대구역" data-value="NAT013271">  
					<input type="button" name="stationName" class="m74" onclick="setParentText(this)" value="서대구역" data-value="NAT013189">  
					<input type="button" name="stationName" class="m75" onclick="setParentText(this)" value="밀양역" data-value="NAT013841">  
					<input type="button" name="stationName" class="m28" onclick="setParentText(this)" value="진영역" data-value="NAT880177">  
					<input type="button" name="stationName" class="m29" onclick="setParentText(this)" value="창원중앙역" data-value="NAT880281">  
					<input type="button" name="stationName" class="m30" onclick="setParentText(this)" value="창원역" data-value="NAT880310">  
					<input type="button" name="stationName" class="m31" onclick="setParentText(this)" value="마산역" data-value="NAT880345">  
					<input type="button" name="stationName" class="m32" onclick="setParentText(this)" value="진주역" data-value="NAT881014">	
				</div>
				<div class="tab-pane fade" id="nav-Jeolla" role="tabpanel" aria-labelledby="nav-Jeolla-tab" tabindex="0">
					<div class="Jeolla"></div>	
					<input type="button" name="stationName" class="m1" onclick="setParentText(this)" value="행신역" data-value="NAT110147">  
					<input type="button" name="stationName" class="m18" onclick="setParentText(this)" value="용산역" data-value="NAT010032">  
					<input type="button" name="stationName" class="m4" onclick="setParentText(this)" value="광명역" data-value="NATH10219">  
					<input type="button" name="stationName" class="m7" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
					<input type="button" name="stationName" class="m17" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  
					<input type="button" name="stationName" class="m19" onclick="setParentText(this)" value="공주역" data-value="NATH20438">  
					<input type="button" name="stationName" class="m21" onclick="setParentText(this)" value="논산역" data-value="NAT030508">  
					<input type="button" name="stationName" class="m20" onclick="setParentText(this)" value="서대전역" data-value="NAT030057">  
					<input type="button" name="stationName" class="m22" onclick="setParentText(this)" value="계룡역" data-value="NAT030254">  
					<input type="button" name="stationName" class="m76" onclick="setParentText(this)" value="익산역" data-value="NAT030879">  
					<input type="button" name="stationName" class="m77" onclick="setParentText(this)" value="전주역" data-value="NAT040257">  
					<input type="button" name="stationName" class="m34" onclick="setParentText(this)" value="남원역" data-value="NAT040868">  
					<input type="button" name="stationName" class="m35" onclick="setParentText(this)" value="곡성역" data-value="NAT041072">  
					<input type="button" name="stationName" class="m36" onclick="setParentText(this)" value="구례구역" data-value="NAT041285">  
					<input type="button" name="stationName" class="m37" onclick="setParentText(this)" value="순천역" data-value="NAT041595">  
					<input type="button" name="stationName" class="m38" onclick="setParentText(this)" value="여천역" data-value="NAT041866">  
					<input type="button" name="stationName" class="m39" onclick="setParentText(this)" value="여수엑스포역" data-value="NAT041993">
				</div>
				<div class="tab-pane fade" id="nav-Gangneung" role="tabpanel" aria-labelledby="nav-Gangneung-tab" tabindex="0">
					<div class="Gangneung"></div>
					<input type="button" name="stationName" class="m71" onclick="setParentText(this)" value="행신역" data-value="NAT110147">  
					<input type="button" name="stationName" class="m72" onclick="setParentText(this)" value="서울역" data-value="NAT010000">  
					<input type="button" name="stationName" class="m40" onclick="setParentText(this)" value="덕소역" data-value="NAT020178">  
					<input type="button" name="stationName" class="m41" onclick="setParentText(this)" value="청량리역" data-value="NAT130126">  
					<input type="button" name="stationName" class="m42" onclick="setParentText(this)" value="양평역" data-value="NAT020524">  
					<input type="button" name="stationName" class="m44" onclick="setParentText(this)" value="진부역" data-value="NATN10787">  
					<input type="button" name="stationName" class="m45" onclick="setParentText(this)" value="횡성역" data-value="NATN10230">  
					<input type="button" name="stationName" class="m46" onclick="setParentText(this)" value="만종역" data-value="NAT021033">  
					<input type="button" name="stationName" class="m47" onclick="setParentText(this)" value="둔내역" data-value="NATN10428">  
					<input type="button" name="stationName" class="m48" onclick="setParentText(this)" value="평창역" data-value="NATN10625">  
					<input type="button" name="stationName" class="m49" onclick="setParentText(this)" value="강릉역" data-value="NAT601936">  
					<input type="button" name="stationName" class="m50" onclick="setParentText(this)" value="정동진역" data-value="NAT601774">  
					<input type="button" name="stationName" class="m51" onclick="setParentText(this)" value="묵호역" data-value="NAT601545">  
					<input type="button" name="stationName" class="m52" onclick="setParentText(this)" value="동해역" data-value="NAT601485">	
				</div>
				<div class="tab-pane fade" id="nav-jungang" role="tabpanel" aria-labelledby="nav-jungang-tab" tabindex="0">
					<div class="jungang"></div>
					<input type="button" name="stationName" class="m68" onclick="setParentText(this)" value="서울역" data-value="NAT010000">  
					<input type="button" name="stationName" class="m69" onclick="setParentText(this)" value="청량리역" data-value="NAT130126">  
					<input type="button" name="stationName" class="m70" onclick="setParentText(this)" value="양평역" data-value="NAT020524">  
					<input type="button" name="stationName" class="m53" onclick="setParentText(this)" value="서원주역" data-value="NAT020864">  
					<input type="button" name="stationName" class="m54" onclick="setParentText(this)" value="원주역" data-value="NAT020947">  
					<input type="button" name="stationName" class="m55" onclick="setParentText(this)" value="제천역" data-value="NAT021549">  
					<input type="button" name="stationName" class="m56" onclick="setParentText(this)" value="단양역" data-value="NAT021784">  
					<input type="button" name="stationName" class="m57" onclick="setParentText(this)" value="풍기역" data-value="NAT022053">  
					<input type="button" name="stationName" class="m58" onclick="setParentText(this)" value="영주역" data-value="NAT022053">  
					<input type="button" name="stationName" class="m59" onclick="setParentText(this)" value="안동역" data-value="NAT022558">
	
				</div>
				<div class="tab-pane fade" id="nav-Jungbunaeryuk" role="tabpanel" aria-labelledby="nav-Jungbunaeryuk-tab" tabindex="0">
					<div class="Jungbunaeryuk"></div>
					<input type="button" name="stationName" class="m60" onclick="setParentText(this)" value="판교역" data-value="NAT250007">  
					<input type="button" name="stationName" class="m61" onclick="setParentText(this)" value="부발역" data-value="NAT250428">  
					<input type="button" name="stationName" class="m62" onclick="setParentText(this)" value="가남역" data-value="NAT280090">  
					<input type="button" name="stationName" class="m63" onclick="setParentText(this)" value="감곡장호원역" data-value="NAT280212">  
					<input type="button" name="stationName" class="m64" onclick="setParentText(this)" value="앙성온천역" data-value="NAT280358">  
					<input type="button" name="stationName" class="m65" onclick="setParentText(this)" value="충주역" data-value="NAT050827">	
				</div>
			</div>
		</div>
	
		<script>
		    function setParentText(buttonElement) {
		        if (opener && !opener.closed) { // 부모 창이 열려 있는지 확인
		            var parentInput = opener.document.getElementById("depplacename");
		            var hiddenField = opener.document.getElementById("depPlaceIdHidden");
		            
		            if (parentInput) {
		                parentInput.value = buttonElement.getAttribute('value'); // 버튼의 value 값을 부모 창의 입력 필드에 설정
		            }
		            
		            if (hiddenField) {
		                hiddenField.value = buttonElement.getAttribute('data-value'); // 버튼의 data-value 값을 hiddenField에 설정
		            }
		            
		            console.log('Selected data-value:', buttonElement.getAttribute('data-value')); // 클릭된 버튼의 data-value를 콘솔에 출력
		            
		            window.close(); // 자식 창 닫기
		        } else {
		            alert("부모 창을 찾을 수 없습니다.");
		        }
		    }
		</script>
</body>
</html>
