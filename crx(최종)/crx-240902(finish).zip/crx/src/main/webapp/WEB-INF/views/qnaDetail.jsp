<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
    Integer userid = (Integer) session.getAttribute("userid");
%>
<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <meta charset="UTF-8">
    <title>Q&A</title>
    <style>
        .con {
            margin:auto;
            width: 100%;
            max-width: 1200px;
        }
        .qnaDetail {
            width: 100%;
            margin: 0 auto;
        }
        .qnaHeader {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            border-top: 2px solid green;
            border-bottom: 2px solid green;
        }
        .qnaContent {
            padding: 10px 20px;
            border-bottom: 2px solid green;
            margin-bottom: 15px;
            min-height: 100px;
            white-space: pre-wrap;
        }
        .buttonSet {
            display: flex;
            justify-content: space-between;
            padding: 10px 20px;
        }
        .buttonSet .left-buttons, .buttonSet .right-buttons {
            display: flex;
            gap: 10px;
        }
        .dividingLine {
            border: dotted 2px green;
        }
        .replyContainer {
            display: flex;
            justify-content: space-between;
			align-items: flex-end;
            margin-bottom: 10px;
            border: 1px solid #ddd; /* 박스형 테두리 추가 */
            padding: 10px; /* 박스 내부 여백 추가 */
            border-radius: 5px; /* 박스 모서리 둥글게 */
        }
        .replyButtons {
            display: flex;
            gap: 10px;
        }
        .replyForm {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />
    <div class="con">
        <h1>Q&A</h1>
        <br>
        <div class="qnaDetail">
            <div class="qnaHeader">
                <div>
                    <span class="bg-success-subtle">&nbsp제목&nbsp</span>
                    <span>${qnaDetail.qtitle}</span>
                </div>
                <div>
                    <span class="bg-success-subtle">&nbsp작성자&nbsp</span>
                    <span>${qnaDetail.username}</span>
                </div>
                <div>
                    <span class="bg-success-subtle">&nbsp등록일자&nbsp</span>
                    <span>${qnaDetail.qdate}</span>
                </div>
            </div>
            <div class="qnaContent">
                <p>${qnaDetail.qcontent}</p>
            </div>
        </div>
        <div class="buttonSet">
            <div class="left-buttons">
                <!-- 질문 작성자만 수정과 삭제 가능 -->
                <c:if test="${userid == qnaDetail.user_userid}">
                    <button type="button" class="btn btn-success" onclick="location.href='${contextPath}/qnaMod.do?qno=${qnaDetail.qno}'">수정</button>
                    <form action="${contextPath}/qnaDelete.do?qno=${qnaDetail.qno}" method="get" onsubmit="return confirm('정말로 삭제하시겠습니까?');" style="display:inline;">
                        <input type="hidden" name="qno" value="${qnaDetail.qno}">
                        <button type="submit" class="btn btn-danger">삭제</button>
                    </form>
                </c:if>

                <!-- 권한이 있는 사람은 삭제만 가능 -->
                <c:if test="${userid != qnaDetail.user_userid && (divname == '고객안내' || divname == '통합관리') && (level == 'master' || level == 'admin')}">
                    <form action="${contextPath}/qnaDelete.do?qno=${qnaDetail.qno}" method="get" onsubmit="return confirm('정말로 삭제하시겠습니까?');" style="display:inline;">
                        <input type="hidden" name="qno" value="${qnaDetail.qno}">
                        <button type="submit" class="btn btn-danger">삭제</button>
                    </form>
                </c:if>
            </div>
            <div class="right-buttons">
                <button type="button" class="btn btn-success" onclick="location.href='${contextPath}/qnaList.do'">목록</button>
            </div>
        </div><br>

        <!-- 답변 목록 구분선 -->
        <hr class="dividingLine">

		<!-- 답변 등록 폼 -->
        <c:if test="${(divname == '고객안내' || divname == '통합관리') && (level != 'user')}">
            <div class="replyForm">
                <form action="${contextPath}/replyAdd.do" method="post">
                    <input type="hidden" name="qna_qno" value="${qnaDetail.qno}">
                    <input type="hidden" name="member_memid" value="${userid}">
                    <div class="mb-3">
                        <textarea class="form-control border-success border-2 rounded-3" name="rcontent" rows="5" placeholder="답변 내용을 입력하세요." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-success">답변 등록</button>
                </form>
            </div>
        </c:if>
        <br><br>

		<!-- 답변 목록 -->
        <c:forEach items="${replyList}" var="reply">
            <div class="replyContainer border-success border-2">
                <div>
                    <p class="fs-6">${reply.rcontent}</p>
                    <p class="fs-6 m-0">
						${reply.memname} &nbsp ${reply.rdate}
					</p>
                </div>
                <div class="replyButtons">
                    <!-- 답변 수정/삭제 버튼 -->
                    <c:if test="${(divname == '고객안내' || divname == '통합관리') && (level != 'user')}">
                        <button type="button" class="btn btn-success btn-sm" onclick="toggleReplyForm(${reply.rno})">수정</button>
                        <form action="${contextPath}/replyDelete.do" method="get" onsubmit="return confirm('정말로 삭제하시겠습니까?');">
                            <input type="hidden" name="rno" value="${reply.rno}" />
                            <input type="hidden" name="qno" value="${qnaDetail.qno}" />
                            <button type="submit" class="btn btn-danger btn-sm">삭제</button>
                        </form>
                    </c:if>
                </div>
            </div>

            <!-- 수정 폼 -->
            <div id="replyForm-${reply.rno}" style="display:none;">
                <form action="${contextPath}/replyUpdate.do" method="post">
                    <input type="hidden" name="rno" value="${reply.rno}" />
                    <input type="hidden" name="qna_qno" value="${qnaDetail.qno}" />
                    <div class="mb-3">
                        <textarea class="form-control border-success" name="rcontent" rows="5" required>${reply.rcontent}</textarea>
                    </div>
                    <button type="submit" class="btn btn-success mb-3">수정</button>
                </form>
            </div>
        </c:forEach>
    </div>
    <jsp:include page="footer.jsp" />

    <!-- 스크립트 -->
    <script>
        function toggleReplyForm(rno) {
            var form = document.getElementById('replyForm-' + rno);
            if (form.style.display === 'none') {
                form.style.display = 'block';
            } else {
                form.style.display = 'none';
            }
        }
    </script>
</body>
</html>
