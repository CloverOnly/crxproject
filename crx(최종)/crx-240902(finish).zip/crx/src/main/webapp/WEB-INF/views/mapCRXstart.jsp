<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <title>CRX 역 선택</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
		html, body {
		    width: 695px;
		    height: 630px;
		    margin: 0;
		    padding: 0;
		    overflow: hidden;
		}
		* {
			margin: 0;
			padding: 0;
			overflow: hidden;
		}
		.HwaYang{		
			position: absolute;			
			width: 399px;
		    height: 495px;
			margin: 0;
			padding: 0;
			z-index: 1;
		}
		.contanierMap {
			border: 10px solid rgb(84, 130, 53);
			border-top: 20px solid rgb(84, 130, 53);
		}
        .station-list {
  
        }
        .station-button {            
            margin: 5px;
			z-index: 2;
        }
        .station-button button {
            font-size: 14px;
            font-weight: bold;
            background-color: #28a745; /* Bootstrap success 색상 */			
            color: white;
            border: none;            
            transition: background-color 0.3s ease;
        }
        .station-button button:hover {
            background-color: #218838; /* Success 색상 hover */
        }
        .header {
            text-align: center;
			background-color: rgb(84, 130, 53);
			padding-bottom: 5px;
        }
		.header h1 {
			color: white;
		}
	    .station-list {			
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			gap: 10px;
	        position: relative;
			width: 100%;
			height: 485px; /* 지도의 높이에 맞게 설정 */
	    }
	    .station-button {
	        position: absolute;
	        margin: 0;
	    }
	    .station-button:nth-child(2) {
			top: 82px;
		    left: 297px;
	    }
	    .station-button:nth-child(3) {
			top: 53px;
		    left: 339px;
	    }
	    .station-button:nth-child(4) {
			top: 95px;
		    left: 362px;
	    }
	    .station-button:nth-child(5) {
			top: 32px;
		    left: 416px;
	    }
	    .station-button:nth-child(6) {
			top: 61px;
		    left: 435px;
	    }
		.station-button:nth-child(7) {
			top: 93px;
			left: 450px;
	    }
		.map {
			padding: 10px;
		}
    </style>
</head>
<body>
    <div class="contanierMap">
        <div class="header">
            <h1><strong>CRX</strong></h1>
        </div>
		<div class="map">
		<nav>
		    <div class="nav nav-tabs" id="nav-tab" role="tablist">
		    	<button class="nav-link active" id="nav-HwaYang-tab" data-bs-toggle="tab" data-bs-target="#nav-Gyeongbu" type="button" role="tab" aria-controls="nav-Gyeongbu" aria-selected="true"><b>화양선</b></button>		    	
			</div>
		</nav>
        <div class="station-list">
			<img src="../img/crxMap.png" class="HwaYang">
            <div class="station-button">
                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="화천" data-value="CRX010000">화천역</button>
            </div>
            <div class="station-button">
                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="양구" data-value="CRX014445">양구역</button>
            </div>
            <div class="station-button">
                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="인제" data-value="CRX011668">인제역</button>
            </div>
            <div class="station-button">
                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="고성" data-value="CRX011762">고성역</button>
            </div>
            <div class="station-button">
                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="속초" data-value="CRX014172">속초역</button>
            </div>
            <div class="station-button">
                <button name="stationName" class="px-1 rounded" onclick="setParentText(this)" value="양양" data-value="CRX014278">양양역</button>
            </div>
        </div>
		</div>
    </div>

    <script>
        function setParentText(buttonElement) {
            if (opener && !opener.closed) { // 부모 창이 열려 있는지 확인
                var parentInput = opener.document.getElementById("depplacename");
                var hiddenField = opener.document.getElementById("depPlaceIdHidden");
                
                if (parentInput) {
                    parentInput.value = buttonElement.getAttribute('value'); // 버튼의 value 값을 부모 창의 입력 필드에 설정
                }
                
                if (hiddenField) {
                    hiddenField.value = buttonElement.getAttribute('data-value'); // 버튼의 data-value 값을 hiddenField에 설정
                }
                
                console.log('Selected data-value:', buttonElement.getAttribute('data-value')); // 클릭된 버튼의 data-value를 콘솔에 출력
                
                window.close(); // 자식 창 닫기
            } else {
                alert("부모 창을 찾을 수 없습니다.");
            }
        }
    </script>
</body>
</html>