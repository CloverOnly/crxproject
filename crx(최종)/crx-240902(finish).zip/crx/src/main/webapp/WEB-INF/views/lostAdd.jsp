<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
    Integer userid = (Integer) session.getAttribute("userid");
    String username = (String) session.getAttribute("username");
%>
<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta charset="UTF-8">
    <title>유실물 안내</title>
    <style>
        .con {
            margin:auto;
            width: 1200px;
        }
        .lost-table {
            margin: auto;
            width: 1200px;
            border-radius: 5px;
            border-collapse: collapse;
            border-top: none;
        }
        .header {
            background-color: rgb(226, 240, 217);
            text-align: center;
        }
        .lost-table td, .lost-table th {
            height: 30px;
            font-size: 14px;
        }
        .lostAddForm {
            margin: 20px;
            border: 1px solid #ccc;
            padding: 30px;
            border-radius: 15px;
        }
        .no {
            width: 50px;
        }
        .title {
            width: 500px;
        }
        .body {
            text-align: center;
        }
        .body .title {
            text-align: left;
        }
        .button {
            margin: 10px;
            text-align:center;
        }
        button {
            width: auto;
            font-size: 15px;
            border: 0;
            outline: 1.5px gray solid;
            border-radius: 5px;
            padding-left: 10px;
        }
        button:active {
            border: 0;
            border-radius: 5px;
            outline: 1.5px gray solid;
            padding-left: 10px;
            background-color: rgb(84, 130, 53);
        }
        .lost-search {
            border: 1px, solid, #ccc;
            margin:5px;
            padding:10px;
        }
        .label{
            display:flex;
        }
        .atag {
            text-decoration: none;
            color: white;
        }
    </style>
    <script>
        function checkForm() {
            var titleChk = document.Chkfm.losttitle.value.trim();
            var contentChk = document.Chkfm.lostcontent.value.trim();
            
            if (titleChk === "") {
                alert("품목이 입력되지 않았습니다. 품목을 입력해 주세요.");
                document.Chkfm.losttitle.focus();
                return false;
            }
            
            if (contentChk === "") {
                alert("내용이 입력되지 않았습니다. 내용을 입력해 주세요.");
                document.Chkfm.lostcontent.focus();
                return false;
            }
            return true;
        }
    </script>    
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />
    <div class="con">
        <h1>유실물 안내</h1>
        <br>
        <form name="Chkfm" action="${contextPath}/lostAdd.do" method="post" onsubmit="return checkForm()">
            <div class="lostAddForm">
                <input type="hidden" name="userid" value="${userid}">
                <div class="lostAdd">
                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" id="lostTitle" name="losttitle" placeholder="lostTitle" autofocus>
                        <label for="lostTitle">품목을 입력해주세요</label>
                    </div>
                </div>
                <div class="form-floating mb-3">
					<select class="form-select mb-3" id="lostPlace" name="lostplace">
					    <option value="" selected disabled>보관장소를 선택하세요</option>
					    <option value="서울역 분실물 센터">서울역 분실물 센터</option>
					    <option value="강남역 분실물 센터">강남역 분실물 센터</option>
					    <option value="인천공항 분실물 센터">인천공항 분실물 센터</option>
					    <option value="부산역 분실물 센터">부산역 분실물 센터</option>
					    <option value="대구역 분실물 센터">대구역 분실물 센터</option>
					    <option value="광주역 분실물 센터">광주역 분실물 센터</option>
					    <option value="대전역 분실물 센터">대전역 분실물 센터</option>
					    <option value="화천역 분실물 센터">화천역 분실물 센터</option>
					    <option value="양구역 분실물 센터">양구역 분실물 센터</option>
					    <option value="인제역 분실물 센터">인제역 분실물 센터</option>
					    <option value="고성역 분실물 센터">고성역 분실물 센터</option>
					    <option value="속초역 분실물 센터">속초역 분실물 센터</option>
					    <option value="양양역 분실물 센터">양양역 분실물 센터</option>
					    <option value="기타">기타</option>
					</select>
                </div>
                <div class="form-floating">
                    <textarea class="form-control" id="lostContent" name="lostcontent" placeholder="lostContent" style="height: 350px"></textarea>
                    <label for="lostContent">내용을 입력해주세요</label>
                </div>                                
            </div>
            <div class="button">
                <button type="submit" class="btn btn-success btn-sm" id="lostRegist-btn">등록</button>
                <button type="button" class="btn btn-secondary btn-sm" id="lostReset-btn" onclick="location.href='${contextPath}/lostList.do'">취소</button>
            </div>
        </form>    
    </div>    
    <jsp:include page="footer.jsp" />
</body>
</html>
