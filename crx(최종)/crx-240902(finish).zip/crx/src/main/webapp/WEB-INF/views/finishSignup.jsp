<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<title>회원가입 완료</title>
<style>
	#wrapper {
	 	 display: flex;
		 justify-content: center;
		 align-items: center;
		 height: 100%;
		 flex-direction: column;
    }

	.guide{
		width: 600px;
		background-color: #f8f8f8;
		padding: 20px;
		text-align: center;
		font-size: 12px;
	}

	#loginButton{
		
	}
</style>
</head>
<body>	 
<jsp:include page="header.jsp" />
<jsp:include page="sidemenu.jsp" />
<div id="wrapper">
	
	<div class="guide">
		<br><br>
		<h4 style="text-align: center;">${username}님의 회원가입이 완료되었습니다.</h4>
		<h4 style="text-align: center;">회원번호 : ${userid}</h4>
		<br><br>
	</div>
	<br>
	<div style="text-align: center;">
		<button type="button" class="btn btn-success" onclick="location.href='login.do'" id="loginButton">로그인 하기</button>
	</div>
</div>
<jsp:include page="footer.jsp" />
</body>
</html>