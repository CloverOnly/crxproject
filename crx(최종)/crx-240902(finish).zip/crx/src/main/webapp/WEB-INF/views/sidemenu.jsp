<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>사이드메뉴</title>
	<style>
		.quickmenu {
		    position: fixed;
		    left: 40%;
		    top: 20%;
		    margin-left: 800px;
		    display: inline-block;
		    background: #fcfcfc;
		    border-radius: 10px;
		    width: 120px;
		    padding-bottom: 20px;
		    border: 1px solid #d5d5d5;
		}
		.quickfont {
		    display: inline-block;
		    width: 100%;
		    text-align: center;
		    padding-top: 20px;
		    color: #333;
		    text-decoration: none;
		    line-height: 1;
		}
		.quickfont:hover{
			transform: scale(1.1);
		}
		.sidemenu{
			font-size:12px;
			display:block;
		}
		.sidimg{
			width:60%;
		}
		.topmove{
			margin: auto;
			display: flex;
			align-items: flex-end;
			justify-content: center;
			width: 70.8px;
			height: 70.8px;
			border-radius: 50%;
			background-color: rgb(226, 240, 217);
		}

		.movetop{
			text-decoration: none;
			color: rgb(47, 47, 47);
		}
	</style>
	<script>
		function checkChat() {
		    var userid = '${userid}';
		    if (userid) {
		        window.open('http://192.168.0.57:8080/chat?userid=' + userid, '_blank', 'width=440, height=650');
		    } else {
		        alert("로그인이 필요합니다. 로그인 후 이용 부탁드립니다.");
				window.location.href = 'login.do';
		    }
		}

		function checkMgmtTrain() {
		    var userid = '${userid}';
		    if (userid) {
		        window.location.href = 'mgmtTrain.do?userid=' + userid;
		    } else {
		        alert("로그인이 필요합니다. 로그인 후 이용 부탁드립니다.");
		        window.location.href = 'login.do';
		    }
		}
	</script>
</head>
<body>
	<div class="quickmenu">
		<a href="ticket.do" class="quickfont">
			<img src="../img/reserv.gif" alt="reserv" class="sidimg">
			<span class="sidemenu">예매하기</span>
		</a>
		<a href="#" onclick="checkMgmtTrain();" class="quickfont">
			<img src="../img/ticket.gif" alt="ticket" class="sidimg">
			<span class="sidemenu">예매관리</span>
		</a>
		<a href="customerservice.do" class="quickfont">
			<img src="../img/callcenter.gif" alt="callcenter" class="sidimg">
			<span class="sidemenu">고객센터</span>
		</a>
		<a href="#" onclick="checkChat();" class="quickfont">
		    <img src="../img/chatbot.gif" alt="chatbot" class="sidimg">
		    <span class="sidemenu">1:1챗봇</span>
		</a>
		<a href="#" class="quickfont">
			<div class="topmove">
				<h1>＾</h1>
			</div>
			<span class="sidemenu">상단으로</span>
		</a>
	</div>
</body>
</html>