<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<script type="text/javascript" src="../smarteditor/js/HuskyEZCreator.js" charset="utf-8"></script>

<!DOCTYPE html>
<html>
<head>
<title>관광상품 등록</title>
<style>
	.title{
		position: relative;
		margin-left: 19%;
		margin-bottom: 50px;
	}
    .dlt{
        width: 1200px;
        margin: auto;
        padding:20px;
    }
    .dlttitle{
        text-align: center;
    }
    .dltcontent{
        display: flex;
    }
    #images{
        border: 1px dotted gray;
        margin-right: 25px;
        width: 65%;        
    }
    .dltname{
        border: 1px dotted gray;
        width:350px;
        height: 490px;
    }
    .people{
        display: flex;
        align-items: flex-start;
    }
    .tourdetail{
        text-align: center;
        width: 100px;
        border: 1px solid black;
        border-radius: 10px 10px 0 0;
        border-bottom: 0px;
        background-color: rgb(240, 240, 240);
    }
    .content{
        background-color: rgb(226, 240, 217);
        font-size: 20px;
        font-weight: bold;
    }
    .button{
        text-align: center;
        margin-top: 10px;
    }
    
    a { color:#000000; text-decoration:none; }
    .scriptCalendar { text-align:center; }
    .scriptCalendar > thead > tr > td { width:50px;height:50px; }
    .scriptCalendar > thead > tr:first-child > td { font-weight:bold; }
    .scriptCalendar > thead > tr:last-child > td { background-color: rgb(226, 240, 217); }
    .scriptCalendar > tbody > tr > td { width:50px;height:50px; }
    .calendarBtn { cursor:pointer; } 
    
</style>
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />

    <div class="title">
        <h1>관광상품 등록페이지</h1>
    </div>
    
	<form action="/smarteditor/savePost" method="post" enctype="multipart/form-data">
	    <div class="dlt">
	        <div class="dlttitle">
	            <h1><input type="text" name="tourtitle" style="width:500px" placeholder="상품제목을 입력해주세요."></h1>
	            <h5><input type="text" name="tourcomment" style="width:300px" placeholder="간단설명을 입력해주세요."></h5>
	        </div>
	    <br>
	    <div class="dltcontent">
	        <div id="images">
	            <p>※이미지 파일을 등록해주세요※</p>
	            <input type="file" name="file1Multipart">
				<br><br>
	            <input type="file" name="file2Multipart">
				<br><br>
	            <input type="file" name="file3Multipart">
	        </div>
	    
	    <div class="dltname">
	        <h6><b>상품번호 : <input type="text" name="tourno"></b></h6>
	        <h6><b>상품명 : <input type="text" name="tourname"></b></h6>
			<h6><b>금액 : <input type="text" name="tourcoin"></b>원</h6>
	        <div class="people">    
	            <h6><b>예약 인원 : </b></h6>    
	        </div>
	        <h6><b>여행 날짜 : </b><span id="selectedDateDisplay"></span></h6>
	        <input type="hidden" id="selectedDate" name="selectedDate">
	    <div>
	        <table class="scriptCalendar">
	            <thead>
	                <tr>
	                    <td class="calendarBtn" id="btnPrevCalendar">&#60;&#60;</td>
	                    <td colspan="5">
	                        <span id="calYear">YYYY</span>년
	                        <span id="calMonth">MM</span>월
	                    </td>
	                    <td class="calendarBtn" id="nextNextCalendar">&#62;&#62;</td>
	                </tr>
	                <tr>
	                    <td>일</td><td>월</td><td>화</td><td>수</td><td>목</td><td>금</td><td>토</td>
	                </tr>
	            </thead>
	            <tbody></tbody>
	        </table>
	    </div>
	    </div>    
	</div>
	<ul class="nav nav-underline">
	    <li class="nav-item">
	        <a class="nav-link active" aria-current="page" href="#">상세 설명</a>
	    </li>
	    <li class="nav-item">
	        <a class="nav-link" href="#detail2">요금안내</a>
	    </li>
	    <li class="nav-item">
	        <a class="nav-link" href="#detail3">참고사항</a>
	    </li>  
	</ul>
	<div id="detail">
	    <textarea id="editorTxt1" 
	              rows="20" cols="10" 
	              placeholder="내용을 입력해주세요"
	              style="width: 1130px" name="tourcontent">
	    </textarea>
	</div>
	<br>
	<br>

	<p class="content">요금안내</p>
	<div id="detail2">        
	    <textarea id="editorTxt2" 
	              rows="20" cols="10" 
	              placeholder="내용을 입력해주세요"
	              style="width: 1130px" name="tourcost">
	    </textarea>
	</div>
	<br>
	<br>

	<p class="content">참고사항</p>
	<div id="detail3">        
	    <textarea id="editorTxt3" 
	              rows="20" cols="10" 
	              placeholder="내용을 입력해주세요"
	              style="width: 1130px" name="tournoted">
	    </textarea>
	</div>
	<br>
	<div class="button">
	    <input type="button" class="btn btn-success" value="관광상품 등록" onclick="submitPost()">
		<a href="tourList.do" class="btn btn-secondary btn-sm">취소</a>
	</div>
	</form>
	</div>
</div>

	<script>
	    let oEditors = {};
	    let editorIds = ["editorTxt1", "editorTxt2", "editorTxt3"];

	    function smartEditor() {
	        console.log("Naver SmartEditor");
	        editorIds.forEach(function(id) {
	            nhn.husky.EZCreator.createInIFrame({
	                oAppRef: oEditors,
	                elPlaceHolder: id,
	                sSkinURI: "../smarteditor/SmartEditor2Skin.html",
	                fCreator: "createSEditor2"
	            });
	        });
	    }

	    document.addEventListener("DOMContentLoaded", function() {
	        smartEditor();
	    });
	    
		function submitPost() {
		    // SmartEditor 내용 업데이트
		    editorIds.forEach(function(id) {
		        const editor = oEditors.getById[id];
		        if (editor) {
		            editor.exec("UPDATE_CONTENTS_FIELD", []);
		        }
		    });
			
		    // 입력된 값 가져오기
		    let tourtitle = document.querySelector('input[name="tourtitle"]').value.trim();
		    let tourcomment = document.querySelector('input[name="tourcomment"]').value.trim();
		    let tourno = document.querySelector('input[name="tourno"]').value.trim();
		    let tourname = document.querySelector('input[name="tourname"]').value.trim();
		    let tourcoin = document.querySelector('input[name="tourcoin"]').value.trim();

		    // 필드별 유효성 검사 및 focus, scrollIntoView 설정
		    function focusAndScroll(element) {
		        element.focus();
		        setTimeout(() => {
		            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
		        }, 100); // 약간의 딜레이를 줘서 scrollIntoView가 확실히 실행되도록 함
		    }

		    if (tourtitle === '') {
		        alert("상품 제목을 입력해주세요.");
		        let element = document.querySelector('input[name="tourtitle"]');
		        focusAndScroll(element);
		        return;
		    }

		    if (tourcomment === '') {
		        alert("간단 설명을 입력해주세요.");
		        let element = document.querySelector('input[name="tourcomment"]');
		        focusAndScroll(element);
		        return;
		    }
		    
		    if (tourno === '') {
		        alert("상품 번호를 입력해주세요.");
		        let element = document.querySelector('input[name="tourno"]');
		        focusAndScroll(element);
		        return;
		    }

		    if (tourname === '') {
		        alert("상품명을 입력해주세요.");
		        let element = document.querySelector('input[name="tourname"]');
		        focusAndScroll(element);
		        return;
		    }

		    if (tourcoin === '' || isNaN(tourcoin)) {
		        alert("유효한 금액을 입력해주세요.");
		        let element = document.querySelector('input[name="tourcoin"]');
		        focusAndScroll(element);
		        return;
		    }

		    // 모든 유효성 검사를 통과한 경우 폼 제출
			confirm("상품을 등록하시겠습니까?");
		    document.querySelector('form').submit();
		}
	</script>
    
    <jsp:include page="footer.jsp" />
</body>
</html>
