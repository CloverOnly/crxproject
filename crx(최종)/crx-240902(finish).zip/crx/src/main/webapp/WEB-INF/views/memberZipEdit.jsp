<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <!-- 우편번호 입력란 -->
    <input type="text" id="postcode_edit" style="width:100px" placeholder="우편번호">
    <input type="button" onclick="zipEdit()" value="주소검색"><br>

    <!-- 주소 입력란 -->
    <input type="text" id="address_edit" style="width:400px" placeholder="주소" onchange="updateEdit()"><br>
  
    <!-- 상세주소 입력란 -->
    <input type="text" id="detailAddress_edit" placeholder="상세주소" onchange="updateEdit()">
  
    <!-- 참고주소 (사용하지 않지만 필요 시 활성화 가능) -->
    <input type="hidden" id="extraAddress_edit" placeholder="참고주소">
  
    <!-- 히든 필드에 member 관련 name 속성 설정 -->
	<input type="hidden" name="mempost" id="mempost_edit">
	<input type="hidden" name="memadd" id="memadd_edit">
</body>

<!-- 다음 우편번호 서비스 스크립트 -->
<script src="//t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
<script>
    function zipEdit() {
        new daum.Postcode({
            oncomplete: function(data) {
                var addr = ''; 
                var extraAddr = ''; 

                if (data.userSelectedType === 'R') { 
                    addr = data.roadAddress;
                } else { 
                    addr = data.jibunAddress;
                }

                if (data.userSelectedType === 'R') {
                    if (data.bname !== '' && /[동|로|가]$/g.test(data.bname)) {
                        extraAddr += data.bname;
                    }
                    if (data.buildingName !== '' && data.apartment === 'Y') {
                        extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                    }
                    if (extraAddr !== '') {
                        extraAddr = ' (' + extraAddr + ')';
                    }
                    document.getElementById("extraAddress_edit").value = extraAddr;

                } else {
                    document.getElementById("extraAddress_edit").value = '';
                }

                document.getElementById('postcode_edit').value = data.zonecode;
                document.getElementById("address_edit").value = addr;

                document.getElementById("detailAddress_edit").focus();
            }
        }).open();
    }

    function updateEdit() {
        var postcode = document.getElementById('postcode_edit').value || '';
        var address = document.getElementById('address_edit').value || '';
        var detailAddress = document.getElementById('detailAddress_edit').value || '';
        var fullAddress = address + ' ' + detailAddress || '';

        var mempostElement = document.getElementById('mempost_edit');
        var memaddElement = document.getElementById('memadd_edit');

        if (mempostElement && memaddElement) {
            mempostElement.value = postcode;
            memaddElement.value = fullAddress;

            // 콘솔 로그 추가
            console.log('우편번호:', mempostElement.value);
            console.log('주소:', memaddElement.value);
        } else {
            console.error('mempost_edit 또는 memadd_edit 요소를 찾을 수 없습니다.');
        }
    }

    document.addEventListener("DOMContentLoaded", function() {
        var memPostcode = '${crxVO.mempost}';
        var memAdd = '${crxVO.memadd}';

        if (memPostcode) {
            document.getElementById('postcode_edit').value = memPostcode;
        }

        if (memAdd) {
            var addressParts = memAdd.split(' ');
            var addressEdit = addressParts.slice(0, addressParts.length - 1).join(' ');
            var detailAddressEdit = addressParts[addressParts.length - 1];

            document.getElementById('address_edit').value = addressEdit;
            document.getElementById('detailAddress_edit').value = detailAddressEdit;
        }
    });
</script>

<style>
    .wrong_text { 
        font-size: 1rem; 
        color: #f44e38; 
        letter-spacing: -0.2px; 
        font-weight: 300; 
        margin: 8px 0 2px; 
        line-height: 1em; 
        display: none;
    }
</style>
</html>
