<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<title>환불</title>
<script>
	function re(applyNum) {
	    if (!confirm("정말 환불하시겠습니까?")) {
	        alert("환불이 취소되었습니다.");
	    } else {
	        $.ajax({
	            type: "POST",
	            url: "${contextPath}/refundUpTrain",
	            data: {
	                apply_num: applyNum  // 전달할 데이터 설정
	            },
	            success: function(response) {
	                alert("정상적으로 환불되었습니다.");
	                location.href = "mgmtTrain.do?userid=${userid}";  // 환불 후 리다이렉트
	            },
	            error: function() {
	                alert("환불에 실패했습니다. 다시 시도해주세요.");
	            }
	        });
	    }
	}

</script>
<style>
	.all{
		width: 1200px;
		margin: 0 auto;  <!-- 중앙 정렬 -->
	}
	.rt{
		margin: 3px;
	}	
	.search{
		text-align: center;
	}
	.minititle a{
		color: #000000;
	}
	.guide{
		width: 1200px;
		height: auto;
		background-color: #f8f8f8;
		margin: 2px;
		padding: 5px;
		font-size: 12px;
	}
	.guidep{
		margin-bottom: 3px;
	}
	table, th, td {
	    border: 2px solid white;
	    border-collapse: collapse;
	}
	
</style>
</head>
<body>	 
<jsp:include page="header.jsp" />
<div class="all">
	<div class="maintitle">
		<h1>환불</h1>
		<hr>
		</div>

	<!-- 설명 -->
<!--	<div class="guide">-->
<!--		<p class="guidep">내용내용내용내용내용내용내용내용내용내용내용내용</p>-->
<!--	</div>-->
	
	<!-- 테이블 -->
	<br>
	<div>
		<table class="table">
			<thead class="table-success">
				<td>승차시간</td>
				<td>출발역</td>
				<td>도착역</td>
				<td>예약인원</td>
				<td>결제금액</td>					
				<td>결제번호</td>
		    </thead>
		    <tbody>
			<c:forEach var="Train" items="${refundTrain}">
				<th>${Train.startdate}<br>${Train.depTime}</th>
				<th>${Train.startname}</th>
				<th>${Train.endname}</th>
				<th>성인:${Train.personnelCount}<br>아동:${Train.childCount}</th>
				<th>${Train.endCharge}</th>
				<th>${Train.apply_num}</th>
			 </tbody>
		</table>
	</div>	
	<br>
	<div style="text-align: center;">
		<button type="button" class="btn btn-danger" onclick="re('${Train.apply_num}')">환불</button>
	</div>
	</c:forEach>
</div>
<jsp:include page="sidemenu.jsp" />
<jsp:include page="footer.jsp" />
</body>
</html>