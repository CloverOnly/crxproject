package com.project.crx;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface KakaoRepository extends JpaRepository<User, Integer> {
	Optional<User> findByUsermail(String usermail);
}