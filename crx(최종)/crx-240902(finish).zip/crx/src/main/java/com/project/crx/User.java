package com.project.crx;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import jakarta.persistence.Id;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "userid")
	private int userid;

	@Column(name = "usermail", unique = true, nullable = false)
	private String usermail;

	@Column(name = "username", nullable = false)
	private String username;

	@Column(name = "usergender")
	private String usergender;

	@Column(name = "userbirth")
	private String userbirth;

	@Column(name = "usertel")
	private String usertel;

	@Column(name = "userpwd")
	private String userpwd;

	@Column(name = "level")
	private String level;

	@Column(name = "status")
	private String status;

	public User(String usermail, String username, String usergender, String userbirth, String usertel, String userpwd) {
		this.usermail = usermail;
		this.username = username;
		this.usergender = usergender;
		this.userbirth = userbirth;
		this.usertel = usertel;
		this.userpwd = userpwd;
	}
}