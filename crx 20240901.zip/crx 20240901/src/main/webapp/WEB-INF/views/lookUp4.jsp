<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <title>역 명</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	<style>
		.lineTitle{
			text-align: center;
			padding-top: 16px;
			margin-top: 16px;
			background: purple;
			color: white;
			margin: 0px;
		}
		.lineAll{
			height: 699px;
			border-width: 0px 9px 9px 9px;			
			border-style: solid;
			border-color: purple;
		}
		.nav-link {
		    color: black; 
		}
		.nav-link.active {
		    color: purple !important; 
		    font-weight: bold; 
		}	
		.Gyeongbu {
			background-image: url(../img/map8.jpg);
		    background-size: cover;
		    position: absolute;
		    left: 158px;
		    width: 54%;
		    height: 521px;
		}
		
		.Honame {
			background-image: url(../img/map9.JPG);
			background-size: cover;
			position: absolute;
			left: 158px;
			width: 54%;
			height: 521px;
		}
		
		.Jeolla {
			background-image: url(../img/map10.jpg);
			background-size: cover;
			position: absolute;
			left: 158px;
			width: 54%;
			height: 521px;
		}	
		
		.Gyeonjeon {
			background-image: url(../img/map11.jpg);
			background-size: cover;
			position: absolute;
			top: 122px;
			left: 169px;
			width: 54%;
			height: 510px;
		}

		.Donghae {
			background-image: url(../img/map12.jpg);
			background-size: cover;
			position: absolute;
			left: 151px;			
			width: 54%;
			height: 521px;
		}
	</style>
</head>
<body>
		<div class="lineAll">
			<div class=lineTitle>
				<h3><strong>SRT</strong></h3>
				<hr>
			</div>
			<nav>
			    <div class="nav nav-tabs" id="nav-tab" role="tablist">
			    	<button class="nav-link active" id="nav-Gyeongbu-tab" data-bs-toggle="tab" data-bs-target="#nav-Gyeongbu" type="button" role="tab" aria-controls="nav-Gyeongbu" aria-selected="true">경부선</button>
			    	<button class="nav-link" id="nav-Honame-tab" data-bs-toggle="tab" data-bs-target="#nav-Honame" type="button" role="tab" aria-controls="nav-Honame" aria-selected="false">호남선</button>
					<button class="nav-link" id="nav-Jeolla-tab" data-bs-toggle="tab" data-bs-target="#nav-Jeolla" type="button" role="tab" aria-controls="nav-Jeolla" aria-selected="true">전라선</button>
					<button class="nav-link" id="nav-Gangneung-tab" data-bs-toggle="tab" data-bs-target="#nav-Gangneung" type="button" role="tab" aria-controls="nav-Gangneung" aria-selected="false">강릉선</button>
					<button class="nav-link" id="nav-Gyeonjeon-tab" data-bs-toggle="tab" data-bs-target="#nav-Gyeonjeon" type="button" role="tab" aria-controls="nav-Gyeonjeon" aria-selected="false">경전선</button>
					<button class="nav-link" id="nav-Donghae-tab" data-bs-toggle="tab" data-bs-target="#nav-Donghae" type="button" role="tab" aria-controls="nav-Donghae" aria-selected="false">동해선</button>
				</div>
			</nav>
			<div class="tab-content" id="nav-tabContent">
			    <div class="tab-pane fade show active" id="nav-Gyeongbu" role="tabpanel" aria-labelledby="nav-Gyeongbu-tab" tabindex="0">
					<div>
						<div class="Gyeongbu"></div>
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="수서역" data-value="NATH30000">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="동탄역" data-value="NATH30326">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="평택지제역" data-value="NATH30536">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="대전역" data-value="NAT011668">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="김천구미역" data-value="NATH12383">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서대구역" data-value="NAT013189">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="동대구역" data-value="NAT013271">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="경주역" data-value="NATH13421">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="울산역" data-value="NATH13717">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="부산역" data-value="NAT014445"> 
					</div>	
				</div>
			    <div class="tab-pane fade" id="nav-Honame" role="tabpanel" aria-labelledby="nav-Honame-tab" tabindex="0">
						<div class="Honame"></div>
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="수서역" data-value="NATH30000">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="동탄역" data-value="NATH30326">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="평택지제역" data-value="NATH30536">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="공주역" data-value="NATH20438">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="익산역" data-value="NAT030879">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="정읍역" data-value="NAT031314">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="광주송정역" data-value="NAT031857">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="나주역" data-value="NAT031998">  
						<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="목포역" data-value="NAT032563">
					</div>
				</div>
			    <div class="tab-pane fade" id="nav-Jeolla" role="tabpanel" aria-labelledby="nav-Jeolla-tab" tabindex="0">
					<div class="Jeolla"></div>
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="수서역" data-value="NATH30000">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="동탄역" data-value="NATH30326">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="평택지제역" data-value="NATH30536">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="공주역" data-value="NATH20438">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="익산역" data-value="NAT030879">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="전주역" data-value="NAT040257">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="남원역" data-value="NAT040868">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="곡성역" data-value="NAT041072">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="구례구역" data-value="NAT041285">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="순천역" data-value="NAT041595">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="여천역" data-value="NAT041866">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="여수EXPO역" data-value="NAT041993">
				</div>
				<div class="tab-pane fade" id="nav-Gyeonjeon" role="tabpanel" aria-labelledby="nav-Gyeonjeon-tab" tabindex="0">
					<div class="Gyeonjeon"></div>	
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="수서역" data-value="NATH30000">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="동탄역" data-value="NATH30326">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="평택지제역" data-value="NATH30536">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="대전역" data-value="NAT011668">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="김천구미역" data-value="NATH12383">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="동대구역" data-value="NAT013271">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서대구역" data-value="NAT013189">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="밀양역" data-value="NAT013841">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="진영역" data-value="NAT880177">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="창원중앙역" data-value="NAT880281">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="창원역" data-value="NAT880310">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="마산역" data-value="NAT880345">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="진주역" data-value="NAT881014">
				</div>
				<div class="tab-pane fade" id="nav-Donghae" role="tabpanel" aria-labelledby="nav-Donghae-tab" tabindex="0">
					<div class="Donghae"></div>
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="수서역" data-value="NATH30000">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="동탄역" data-value="NATH30326">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="평택지제역" data-value="NATH30536">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="천안아산역" data-value="NATH10960">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="오송역" data-value="NAT050044">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="대전역" data-value="NAT011668">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="김천구미역" data-value="NATH12383">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="서대구역" data-value="NAT013189">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="동대구역" data-value="NAT013271">  
					<input type="button" name="stationName" class="cInput" onclick="setParentText(this)" value="포항역" data-value="NAT8B0351">	
				</div>
			</div>
		</div>
	
	<script>
		function setParentText(buttonElement) {
		    if (opener && !opener.closed) { // 부모 창이 열려 있는지 확인
		        var parentInput = opener.document.getElementById("arrplacename");
		        var hiddenField = opener.document.getElementById("arrPlaceIdHidden");
		        
		        if (parentInput) {
		            parentInput.value = buttonElement.getAttribute('value'); // 버튼의 value 값을 부모 창의 입력 필드에 설정
		        }
		        
		        if (hiddenField) {
		            hiddenField.value = buttonElement.getAttribute('data-value'); // 버튼의 data-value 값을 hiddenField에 설정
		        }
		        
		        console.log('Selected data-value:', buttonElement.getAttribute('data-value')); // 클릭된 버튼의 data-value를 콘솔에 출력
		        
		        window.close(); // 자식 창 닫기
		    } else {
		        alert("부모 창을 찾을 수 없습니다.");
		    }
		}
	</script>
</body>
</html>
