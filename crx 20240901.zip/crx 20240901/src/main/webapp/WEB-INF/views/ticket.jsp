<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
    Integer userid = (Integer) session.getAttribute("userid");

    // main.jsp에서 전달된 폼 데이터를 받습니다.
	String depplacename = request.getParameter("depplacename") != null ? request.getParameter("depplacename") : "";
	String depPlaceId = request.getParameter("depPlaceId") != null ? request.getParameter("depPlaceId") : "";
	String arrplacename = request.getParameter("arrplacename") != null ? request.getParameter("arrplacename") : "";
	String arrPlaceId = request.getParameter("arrPlaceId") != null ? request.getParameter("arrPlaceId") : "";
	String startdate = request.getParameter("startdate") != null ? request.getParameter("startdate") : "";
	String starttime = request.getParameter("starttime") != null ? request.getParameter("starttime") : "";
	String adultcount = request.getParameter("adultcount") != null ? request.getParameter("adultcount") : "1";
	String childcount = request.getParameter("childcount") != null ? request.getParameter("childcount") : "0";
	String trainType = request.getParameter("trainType") != null ? request.getParameter("trainType") : "";
	String seatType = request.getParameter("seatType") != null ? request.getParameter("seatType") : "일반";
%>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>일반승차권 예매</title>
    <style>
        .all {
            width: 1200px;
            margin: 0 auto; /* 중앙 정렬 */
        }
        .tiline {
            display: inline;
            border: solid 1px green;
            border-radius: 8px;
            padding: 5px;
            color: green;
            margin: 5px;
        }
        .mid {            
            background: #f8f8f8;
            padding: 5px;
        }

        .rt {
            margin: 3px;
        }
        .search {
            text-align: center;
        }
        .minititle a {
            color: #000000;
        }
        table, th, td {
            border: 2px solid white;
            border-collapse: collapse;
        }
        #Date {
            width: 140px;
            display: inline;
        }
        .checkTrain {
            border: 2px solid white;
            border-collapse: collapse;
            width: 100%;
        }
        #swapIcon {
            font-size: 20px;
            cursor: pointer; /* 클릭 가능성 추가 */
        }
        #depplacename{
            background: white;
            color: black;
        }
        #arrplacename{
            background: white;
            color: black;
        }
        .seat-btn{
            font-size: 12px;
            background: green;
			color: white;
        }
        .checkTrain {
            width: 100%;
            border-collapse: collapse;
        }
        .checkTrain th, .checkTrain td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        .checkTrain th {
            background-color: #f2f2f2;
            color: black;
        }
        .checkTrain tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .checkTrain tr:hover {
            background-color: #ddd;
        }
        /* .page-link 클래스를 재정의하여 색상을 녹색으로 변경 */
        .pagination .page-link {
            color: green;
        }

        /* 활성화된 페이지의 링크 색상도 변경 */
        .pagination .page-item.active .page-link {
            background-color: green;
            border-color: green;
            color: white; /* 텍스트 색상을 흰색으로 변경 */
        }

        /* 마우스 오버 시 링크 색상 변경 */
        .pagination .page-link:hover {
            color: darkgreen;
        }

    </style>
</head>
<body>
    <jsp:include page="header.jsp" />
    <div class="all">
        <div class="maintitle">
            <h1>일반승차권</h1>
            <hr>
        </div>

        <br>
        <div style="text-align:center;">
            <img src="../img/mark1.gif" style="width:500px">
        </div>

        <br>
<!--        <div>-->
<!--            <br>-->
<!--            <ul class="nav nav-tabs">-->
<!--                <li class="minititle nav-item">-->
<!--                    <a class="nav-link active bg-light" aria-current="page" href="ticket.do">일반승차권 조회</a>-->
<!--                </li>-->
<!--                <li class="minititle nav-item">-->
<!--                    <a class="nav-link" href="groupTicket.do">단체승차권 조회</a>-->
<!--                </li>-->
<!--            </ul>-->
<!--        </div>-->
        <div class="mid">           
            <br>
			<div class="rt">
			    <label id="trainType">열차구분</label>
			    &nbsp;
				<input class="form-check-input" type="radio" name="trainType" id="20" value="CRX" <%= "CRX".equals(trainType) ? "checked" : "" %>>
				<label class="form-check-label" for="CRX">CRX</label>
				&nbsp;&nbsp;
			    <input class="form-check-input" type="radio" name="trainType" id="00" value="KTX" <%= "KTX".equals(trainType) ? "checked" : "" %>>
			    <label class="form-check-label" for="KTX">KTX</label>
			    &nbsp;&nbsp;
			    <input class="form-check-input" type="radio" name="trainType" id="17" value="SRT" <%= "SRT".equals(trainType) ? "checked" : "" %>>
			    <label class="form-check-label" for="SRT">SRT</label>
			</div>

            <br>
            <div class="rt" id="ktxStation">
                <label for="depplacename">출발역</label>
                <input id="depplacename" name="depplacename" type="text" class="inp200" title="출발역" value="<%= depplacename %>" readonly>
                <input type="hidden" id="depPlaceIdHidden" name="depPlaceId" value="<%= depPlaceId %>">
                <input type="button" value="조회" onclick="openChild('dep')">
                &nbsp;&nbsp;
                <i id="swapIcon" class="bi bi-arrow-repeat" onclick="swapStations()"></i>
                &nbsp;&nbsp;
                <label for="arrplacename">도착역</label>
                <input id="arrplacename" name="arrplacename" type="text" class="inp200" title="도착역" value="<%= arrplacename %>" readonly>
                <input type="hidden" id="arrPlaceIdHidden" name="arrPlaceId" value="<%= arrPlaceId %>">
                <input type="button" value="조회" onclick="openChild('arr')">
            </div>

            <br>
            <div class="rt" id="arrplandtime">
                <label for="Date">출발일</label>
                <input type="date" id="Date" name="startdate" value="<%= startdate != "null" ? startdate : "" %>" onchange="formatDate()">
                <input type="hidden" id="formattedDate" value="<%= startdate != null ? startdate.replaceAll("-", "") : "" %>">
            
                &nbsp;&nbsp;
                <label for="timeSelect">시간</label>
                <select id="timeSelect" name="starttime">
                    <option value="00" <%= "000000".equals(starttime) ? "selected" : "" %>>00:00</option>
                    <option value="01" <%= "010000".equals(starttime) ? "selected" : "" %>>01:00</option>
                    <option value="02" <%= "020000".equals(starttime) ? "selected" : "" %>>02:00</option>
					<option value="03" <%= "030000".equals(starttime) ? "selected" : "" %>>03:00</option>
                    <option value="04" <%= "040000".equals(starttime) ? "selected" : "" %>>04:00</option>
                    <option value="05" <%= "050000".equals(starttime) ? "selected" : "" %>>05:00</option>
					<option value="06" <%= "060000".equals(starttime) ? "selected" : "" %>>06:00</option>
                    <option value="07" <%= "070000".equals(starttime) ? "selected" : "" %>>07:00</option>
                    <option value="08" <%= "080000".equals(starttime) ? "selected" : "" %>>08:00</option>
					<option value="09" <%= "090000".equals(starttime) ? "selected" : "" %>>09:00</option>
                    <option value="10" <%= "100000".equals(starttime) ? "selected" : "" %>>10:00</option>
                    <option value="11" <%= "110000".equals(starttime) ? "selected" : "" %>>11:00</option>
					<option value="12" <%= "120000".equals(starttime) ? "selected" : "" %>>12:00</option>
                    <option value="13" <%= "130000".equals(starttime) ? "selected" : "" %>>13:00</option>
                    <option value="14" <%= "140000".equals(starttime) ? "selected" : "" %>>14:00</option>
					<option value="15" <%= "150000".equals(starttime) ? "selected" : "" %>>15:00</option>
                    <option value="16" <%= "160000".equals(starttime) ? "selected" : "" %>>16:00</option>
                    <option value="17" <%= "170000".equals(starttime) ? "selected" : "" %>>17:00</option>
					<option value="18" <%= "180000".equals(starttime) ? "selected" : "" %>>18:00</option>
                    <option value="19" <%= "190000".equals(starttime) ? "selected" : "" %>>19:00</option>
                    <option value="20" <%= "200000".equals(starttime) ? "selected" : "" %>>20:00</option>
					<option value="21" <%= "210000".equals(starttime) ? "selected" : "" %>>21:00</option>
                    <option value="22" <%= "220000".equals(starttime) ? "selected" : "" %>>22:00</option>
                    <option value="23" <%= "230000".equals(starttime) ? "selected" : "" %>>23:00</option>
					<option value="24" <%= "240000".equals(starttime) ? "selected" : "" %>>24:00</option>
                </select>
                <label id="listtime">시</label>
            </div>

            <br>
            <div class="rt">
                <div>
					<label for="adultcount">성인(만 13세 이상)</label>
					<select id="adultcount" name="adultcount">
					    <option value="0" <%= "0".equals(adultcount) ? "selected" : "" %>>성인 0명</option>
					    <option value="1" <%= "1".equals(adultcount) ? "selected" : "" %>>성인 1명</option>
					    <option value="2" <%= "2".equals(adultcount) ? "selected" : "" %>>성인 2명</option>
					    <option value="3" <%= "3".equals(adultcount) ? "selected" : "" %>>성인 3명</option>
						<option value="4" <%= "4".equals(adultcount) ? "selected" : "" %>>성인 4명</option>
					    <option value="5" <%= "5".equals(adultcount) ? "selected" : "" %>>성인 5명</option>
					    <option value="6" <%= "6".equals(adultcount) ? "selected" : "" %>>성인 6명</option>
					    <option value="7" <%= "7".equals(adultcount) ? "selected" : "" %>>성인 7명</option>
						<option value="8" <%= "8".equals(adultcount) ? "selected" : "" %>>성인 8명</option>
						<option value="9" <%= "9".equals(adultcount) ? "selected" : "" %>>성인 9명</option>
						<option value="10" <%= "10".equals(adultcount) ? "selected" : "" %>>성인 10명</option>
					</select>
					&nbsp;&nbsp;
					
                    <label for="childcount">아동(만 6~12세)</label>                    
                    <select id="childcount" name="childcount">
                        <option value="0" <%= "0".equals(childcount) ? "selected" : "" %>>아동 0명</option>
                        <option value="1" <%= "1".equals(childcount) ? "selected" : "" %>>아동 1명</option>
                        <option value="2" <%= "2".equals(childcount) ? "selected" : "" %>>아동 2명</option>
						<option value="3" <%= "3".equals(childcount) ? "selected" : "" %>>아동 3명</option>
                        <option value="4" <%= "4".equals(childcount) ? "selected" : "" %>>아동 4명</option>
                        <option value="5" <%= "5".equals(childcount) ? "selected" : "" %>>아동 5명</option>
						<option value="6" <%= "6".equals(childcount) ? "selected" : "" %>>아동 6명</option>
                        <option value="7" <%= "7".equals(childcount) ? "selected" : "" %>>아동 7명</option>
                        <option value="8" <%= "8".equals(childcount) ? "selected" : "" %>>아동 8명</option>
						<option value="9" <%= "9".equals(childcount) ? "selected" : "" %>>아동 9명</option>
                        <option value="10" <%= "10".equals(childcount) ? "selected" : "" %>>아동 10명</option>
                    </select>                    
                </div>
            </div>
			<br>
<!--            <div class="rt">-->
<!--                <label>좌석종류</label>-->
<!--                <select id="seatType" name="seatType">-->
<!--                    <option value="일반" <%= "일반".equals(seatType) ? "selected" : "" %>>일반</option>-->
<!--                    <option value="특실" <%= "특실".equals(seatType) ? "selected" : "" %>>특실</option>-->
<!--                </select>-->
<!--            </div>-->
			<input type="hidden" id="seatType" name="seatType" value="일반">
			</div>  
			<br>
			<div class="search">
			    <button id="ktxSrtSearchButton" class="btn btn-success" onclick="fetchTicketInfo()">조회</button>
			    <button id="crxSearchButton" class="btn btn-success" style="display: none;" onclick="fetchCrxTicketInfo()">조회</button>
			</div>

            
            <br>
            <div id="results"></div>
            <div id="pagination"></div>
            
            <br>
            <jsp:include page="sidemenu.jsp" />
               
    </div>  

	<script>		
	    let currentPage = 1;
	    const itemsPerPage = 12;
	    const contextPath = "<%= request.getContextPath() %>";
	    
	    // 날짜 형식 변환 함수
	    function formatDate() {
	        var dateInput = document.getElementById('Date').value;
	        if (dateInput) {
	            var formattedDate = dateInput.replace(/-/g, '');
	            document.getElementById('formattedDate').value = formattedDate; 
	        } else {
	            document.getElementById('formattedDate').value = ''; 
	        }
	    }

	    // 오늘 이전으로 날짜 선택 제한
	    var now_utc = Date.now();
	    var timeOff = new Date().getTimezoneOffset()*60000;
	    var today = new Date(now_utc-timeOff).toISOString().split("T")[0];      
	    document.getElementById("Date").setAttribute("min", today);
	    
	    // 차종에 따라 다른 조회 버튼 표시
	    function toggleStations(trainType) {
	        if (trainType === 'CRX') {
	            document.getElementById('crxSearchButton').style.display = 'inline-block';
	            document.getElementById('ktxSrtSearchButton').style.display = 'none';
	        } else {
	            document.getElementById('crxSearchButton').style.display = 'none';
	            document.getElementById('ktxSrtSearchButton').style.display = 'inline-block';
	        }
	    }

		function resetFields() {
		    document.getElementById('depplacename').value = '';
		    document.getElementById('arrplacename').value = '';
		    document.getElementById('depPlaceIdHidden').value = '';
		    document.getElementById('arrPlaceIdHidden').value = '';
		    document.getElementById('Date').value = '';
		    document.getElementById('formattedDate').value = '';
		    document.getElementById('timeSelect').value = '00';
		    document.getElementById('adultcount').value = '1';
		    document.getElementById('childcount').value = '0';
		}
		console.log('출발지역1: ', depplacename);
		console.log('도착지역1: ', arrplacename);
		console.log('히든출발지역1: ', depPlaceIdHidden);
		console.log('히든도착지역1: ', arrPlaceIdHidden);

		// 페이지가 로드될 때 초기 설정
		window.onload = function() {
		    let trainTypeElement = document.querySelector('input[name="trainType"]:checked');

		    if (!trainTypeElement) {
		        document.getElementById('20').checked = true;
		        trainTypeElement = document.getElementById('20');
		    }

		    toggleStations(trainTypeElement.value);

		    document.querySelectorAll('input[name="trainType"]').forEach(function(element) {
		        element.addEventListener('change', function(event) {
		            toggleStations(event.target.value);
		            resetFields(); // 필드 초기화
		        });
		    });
		};
	    
	    // 출발역과 도착역 바꾸기
	    function swapStations() {
	        var arrPlace = document.getElementById('arrplacename').value;
	        var depPlace = document.getElementById('depplacename').value;
	        var start = document.getElementById('depPlaceIdHidden').value;
	        var end = document.getElementById('arrPlaceIdHidden').value; 
	        document.getElementById('arrplacename').value = depPlace;
	        document.getElementById('depplacename').value = arrPlace;
	        document.getElementById('arrPlaceIdHidden').value = start;
	        document.getElementById('depPlaceIdHidden').value = end;
	    }

	    // 역 조회
	    function openChild(stationType) {
	        window.name = "parentForm";
	        const trainType = document.querySelector('input[name="trainType"]:checked').value;

	        let url, windowName;

	        if (trainType === 'KTX') {
	            url = stationType === 'dep' ? "lookUp.do" : "lookUp2.do";
	            windowName = stationType === 'dep' ? "lookUpForm" : "lookUp2Form";
	        } else if (trainType === 'SRT') {
	            url = stationType === 'dep' ? "lookUp3.do" : "lookUp4.do";
	            windowName = stationType === 'dep' ? "lookUp3Form" : "lookUp4Form";
	        } else if (trainType === 'CRX') {
	            url = stationType === 'dep' ? "lookUp5.do" : "lookUp6.do";
	            windowName = stationType === 'dep' ? "lookUp5Form" : "lookUp6Form";
	        }

	        window.open(url, windowName, "width=695, height=630, resizable=no, scrollbars=no, toolbar=no, menubar=no");
	    }
	    
	    // 좌석 조회	
		function seatTicket(trainno, depPlace, arrPlace, depTime, arrTime, duration, adultcharge, startdate) {
		    var depPlaceId = document.getElementById('depPlaceIdHidden').value;
		    var arrPlaceId = document.getElementById('arrPlaceIdHidden').value;
		    var seatType = document.getElementById('seatType').value;
		    var formattedDate = document.getElementById('formattedDate').value;
		    var trainType = document.querySelector('input[name="trainType"]:checked').value;
		    var adultcount = document.getElementById('adultcount').value;
		    var childCount = document.getElementById('childcount').value;
		    
		    // 로그인 여부 확인
		    var userid = <%= userid != null ? "'" + userid + "'" : "null" %>; // 서버에서 userid를 가져오는 부분

		    if (!userid) {
		        // 로그인되지 않은 경우, 로그인 페이지로 리디렉션
		        window.location.href = 'login.do'; // 로그인 페이지 URL로 변경
		        return;
		    }

		    // 콘솔에 startdate 값을 출력
		    console.log("Start Date:", startdate);
			console.log('출발지역2: ', depplacename);
			console.log('도착지역2: ', arrplacename);
			console.log('히든출발지역2: ', depPlaceIdHidden);
			console.log('히든도착지역2: ', arrPlaceIdHidden);

		    var queryParams = '?' +
		        'depPlace=' + encodeURIComponent(depPlace) + '&' +
		        'arrPlace=' + encodeURIComponent(arrPlace) + '&' +
		        'trainno=' + encodeURIComponent(trainno) + '&' +
		        'depTime=' + encodeURIComponent(depTime) + '&' +
		        'arrTime=' + encodeURIComponent(arrTime) + '&' +
		        'duration=' + encodeURIComponent(duration) + '&' +
		        'seatType=' + encodeURIComponent(seatType) + '&' +
		        'formattedDate=' + encodeURIComponent(formattedDate) + '&' +
		        'trainType=' + encodeURIComponent(trainType) + '&' +
		        'adultcount=' + encodeURIComponent(adultcount) + '&' +
		        'childCount=' + encodeURIComponent(childCount) + '&' +
		        'userid=' + encodeURIComponent(userid) + '&' +
		        'startdate=' + encodeURIComponent(startdate) + '&' +
		        'adultcharge=' + encodeURIComponent(adultcharge);

		    var openWin3 = window.open("seat.do" + queryParams, "seat", "width=1020, height=850, resizable=no, scrollbars=no");
		}

	    
		function fetchTicketInfo() {
			       var depPlaceId = document.getElementById('depplacename').value;
			       var arrPlaceId = document.getElementById('arrplacename').value;
			       var seatType = document.getElementById('seatType').value;
			       var formattedDate = document.getElementById('formattedDate').value;
				   var trainType = document.querySelector('input[name="trainType"]:checked').id;
			       var start = document.getElementById('depPlaceIdHidden').value;
			       var end = document.getElementById('arrPlaceIdHidden').value;
				   // 인원 정보 가져오기
				   var adultCountElement = document.getElementById('adultcount');
				   var childCountElement = document.getElementById('childcount');
				   var adultCount = adultCountElement ? adultCountElement.value : '0';
				   var childCount = childCountElement ? childCountElement.value : '0';
				   var totalCount = parseInt(adultCount) + parseInt(childCount);

			       var xhr = new XMLHttpRequest();
			       var serviceKey = 'KOyx/5iXteTdFA1wcSF1KvBTsEQcHMa8cFsrBwLTM6EGpTydPaVEtn4IjjQrwiIxqBvpc+qi4NM9izQQfHzT3w=='; // 서비스 키
			       var queryParams = '?' + encodeURIComponent('serviceKey') + '=' + encodeURIComponent(serviceKey) +
			           '&' + encodeURIComponent('pageNo') + '=' + encodeURIComponent('1') +
			           '&' + encodeURIComponent('numOfRows') + '=' + encodeURIComponent('10') +
			           '&' + encodeURIComponent('_type') + '=' + encodeURIComponent('json') +
			           '&' + encodeURIComponent('depPlaceId') + '=' + encodeURIComponent(start) +
			           '&' + encodeURIComponent('arrPlaceId') + '=' + encodeURIComponent(end) +
			           '&' + encodeURIComponent('depPlandTime') + '=' + encodeURIComponent(formattedDate) +
			           '&' + encodeURIComponent('trainGradeCode') + '=' + encodeURIComponent(trainType);
					   
				   var formattedDate = document.getElementById('formattedDate').value;
			       var startdate = formattedDate; // 또는 필요한 값으로 설정 

			       xhr.open('GET', 'https://apis.data.go.kr/1613000/TrainInfoService/getStrtpntAlocFndTrainInfo' + queryParams);
			       xhr.onreadystatechange = function () {
			           if (this.readyState == 4) {
			               if (this.status == 200) {
			                   try {
			                       var response = JSON.parse(this.responseText);
			                       var items = response.response.body.items.item || [];
			                       if (items.length > 0) {
			                           var table = '<table class="checkTrain">' +
			                               '<thead>' +
			                               '<tr>' +
			                               '<th>열차종류</th>' +
			                               '<th>열차번호</th>' +
			                               '<th>출발역</th>' +
			                               '<th>도착역</th>' +
			                               '<th>좌석종류</th>' +
			                               '<th>출발시간</th>' +
			                               '<th>도착시간</th>' +
			                               '<th>소요시간</th>' +
			                               '</tr>' +
			                               '</thead>' +
			                               '<tbody>';
			                           items.forEach(function(item) {
			                               var depTime = String(item.depplandtime); 
			                               var arrTime = String(item.arrplandtime);

			                               // 문자열을 Date 객체로 변환
			                               var startDate = new Date(
			                                   depTime.substring(0, 4), 
			                                   depTime.substring(4, 6) - 1, 
			                                   depTime.substring(6, 8),
			                                   depTime.substring(8, 10),
			                                   depTime.substring(10, 12)
			                               );
			                               var endDate = new Date(
			                                   arrTime.substring(0, 4), 
			                                   arrTime.substring(4, 6) - 1, 
			                                   arrTime.substring(6, 8),
			                                   arrTime.substring(8, 10),
			                                   arrTime.substring(10, 12)
			                               );

			                               // HH:mm 형식으로 변환
			                               var formattedTime = startDate.toTimeString().substring(0, 5);
			                               var formatted2Time = endDate.toTimeString().substring(0, 5);

			                               // 소요시간 계산
			                               var durationMinutes = Math.round((endDate - startDate) / 60000); // 밀리초를 분으로 변환
			                               var hours = Math.floor(durationMinutes / 60);
			                               var minutes = durationMinutes % 60;
			                               
										   console.log('출발지역3: ', depplacename);
										   console.log('도착지역3: ', arrplacename);
										   console.log('히든출발지역3: ', depPlaceIdHidden);
										   console.log('히든도착지역3: ', arrPlaceIdHidden);
										   
			                               table += '<tr>' +
										       '<td>' + (item.traingradename || 'N/A') + '</td>' +
										       '<td>' + (item.trainno || 'N/A') + '</td>' +
										       '<td>' + (item.depplacename || 'N/A') + '</td>' +
										       '<td>' + (item.arrplacename || 'N/A') + '</td>' +
										       '<td><button class="seat-btn" onclick="seatTicket(\'' + item.trainno + '\', \'' + item.depplacename + '\', \'' + item.arrplacename + '\', \'' + formattedTime + '\', \'' + formatted2Time + '\', \'' + hours + '시간 ' + minutes + '분\', \'' + item.adultcharge + '\', \'' + startdate + '\')">좌석 선택</button></td>' +
										       '<td>' + formattedTime + '</td>' +
										       '<td>' + formatted2Time + '</td>' +
										       '<td>' + hours + '시간 ' + minutes + '분</td>' +
											   '<input type="hidden" class="adultcharge" value="' + (item.adultcharge || 'N/A') + '">' +
										   '</tr>';

			                           });

			                           table += '</tbody></table>';
			                           document.getElementById('results').innerHTML = table;
			                       } else {
			                           document.getElementById('results').innerText = '검색된 결과가 없습니다.';
			                       }
			                   } catch (e) {
			                       console.error('JSON 파싱 오류:', e);
			                       document.getElementById('results').innerText = '서버 응답을 처리하는 동안 오류가 발생했습니다.';
			                   }
			               } else {
			                   document.getElementById('results').innerText = '서버 응답 오류: ' + this.statusText;
			               }
			           }
			       };

			       xhr.onerror = function () {
			           console.error('네트워크 오류 발생:', this.statusText);
			           document.getElementById('results').innerText = '네트워크 오류가 발생했습니다.';
			       };

			       xhr.send();
			   }


	   function fetchCrxTicketInfo() {
	       const departureStation = document.getElementById('depPlaceIdHidden').value.trim();
	       const arrivalStation = document.getElementById('arrPlaceIdHidden').value.trim();
	       const departureDate = document.getElementById('Date').value.trim();  // startdate로 사용
	       const departureTime = document.getElementById('timeSelect').value.trim();
	       const adultCount = document.getElementById('adultcount').value.trim();
	       const childCount = document.getElementById('childcount').value.trim();
	       const seatType = document.getElementById('seatType').value.trim();

	       if (departureStation === "") {
	           alert("출발역을 선택하세요.");
	           return;
	       }

	       if (arrivalStation === "") {
	           alert("도착역을 선택하세요.");
	           return;
	       }

	       if (departureDate === "") {
	           alert("출발일을 선택하세요.");
	           return;
	       }

	       const url = contextPath + '/crx/search?departureStation=' + departureStation +
	                   '&arrivalStation=' + arrivalStation +
	                   '&departureDate=' + departureDate +
	                   '&departureTime=' + departureTime +
	                   '&adultCount=' + adultCount +
	                   '&childCount=' + childCount +
	                   '&seatType=' + seatType;

	       const xhr = new XMLHttpRequest();
	       xhr.open('GET', url, true);
	       xhr.onreadystatechange = function () {
	           if (xhr.readyState === 4 && xhr.status === 200) {
	               try {
	                   const response = JSON.parse(xhr.responseText);		                

	                   const trainData = response.filter(item => 
	                       item.trainNumber && 
	                       item.departureStation && 
	                       item.arrivalStation && 
	                       item.departureTime && 
	                       item.arrivalTime && 
	                       item.duration && 
	                       item.fareSpecial && 
	                       item.fareStandard
	                   );

	                   displayCrxPage(trainData, 1, departureDate);  // startdate로 전달
	               } catch (error) {
	                   console.error('CRX 데이터 파싱 오류:', error);
	                   document.getElementById('results').innerText = '데이터를 처리하는 중 오류가 발생했습니다.';
	               }
	           }
	       };
	       xhr.send();
	   }


	   function displayCrxPage(items, page, startdate) {
	       const startIndex = (page - 1) * itemsPerPage;
	       const endIndex = page * itemsPerPage;
	       const paginatedItems = items.slice(startIndex, endIndex);

	       const resultsContainer = document.getElementById('results');
	       resultsContainer.innerHTML = '';  // 기존 내용을 초기화

	       if (paginatedItems.length > 0) {
	           const table = document.createElement('table');
	           table.className = 'checkTrain';

	           const thead = document.createElement('thead');
	           const headRow = document.createElement('tr');
	           ['열차종류', '열차번호', '출발역', '도착역', '출발시간', '도착시간', '소요시간', '성인요금', '아동요금', '좌석선택'].forEach(text => {
	               const th = document.createElement('th');
	               th.innerText = text;
	               headRow.appendChild(th);
	           });
	           thead.appendChild(headRow);
	           table.appendChild(thead);

	           const tbody = document.createElement('tbody');
	           paginatedItems.forEach(function (item) {
	               const row = document.createElement('tr');

	               const trainTypeCell = document.createElement('td');
	               trainTypeCell.innerText = 'CRX';
	               row.appendChild(trainTypeCell);

	               const trainNumberCell = document.createElement('td');
	               trainNumberCell.innerText = item.trainNumber;
	               row.appendChild(trainNumberCell);

	               const departureStationCell = document.createElement('td');
	               departureStationCell.innerText = item.departureStation;
	               row.appendChild(departureStationCell);

	               const arrivalStationCell = document.createElement('td');
	               arrivalStationCell.innerText = item.arrivalStation;
	               row.appendChild(arrivalStationCell);

	               const departureTimeCell = document.createElement('td');
	               departureTimeCell.innerText = item.departureTime;
	               row.appendChild(departureTimeCell);

	               const arrivalTimeCell = document.createElement('td');
	               arrivalTimeCell.innerText = item.arrivalTime;
	               row.appendChild(arrivalTimeCell);

	               const durationCell = document.createElement('td');
	               durationCell.innerText = item.duration;
	               row.appendChild(durationCell);

	               const fareSpecialCell = document.createElement('td');
	               fareSpecialCell.innerText = item.fareSpecial;
	               row.appendChild(fareSpecialCell);

	               const fareStandardCell = document.createElement('td');
	               fareStandardCell.innerText = item.fareStandard;
	               row.appendChild(fareStandardCell);

	               const seatSelectionCell = document.createElement('td');
	               const seatButton = document.createElement('button');
	               seatButton.className = 'seat-btn';
	               seatButton.innerText = '좌석 선택';
	               seatButton.onclick = function() {
	                   seatTicket(item.trainNumber, item.departureStation, item.arrivalStation, item.departureTime, item.arrivalTime, item.duration, item.fareStandard, startdate);  // startdate 전달
	               };
	               seatSelectionCell.appendChild(seatButton);
	               row.appendChild(seatSelectionCell);

	               tbody.appendChild(row);
	           });

	           table.appendChild(tbody);
	           resultsContainer.appendChild(table);
	       } else {
	           resultsContainer.innerText = '해당 페이지에 데이터가 없습니다.';
	       }

	       displayPagination(items.length, page);
	   }




	    function displayPage(items, page) {
	        const startIndex = (page - 1) * itemsPerPage;
	        const endIndex = page * itemsPerPage;
	        const paginatedItems = items.slice(startIndex, endIndex);

	        if (paginatedItems.length > 0) {
	            let table = '<table class="checkTrain">' +
	                '<thead>' +
	                '<tr>' +
	                '<th>열차종류</th>' +
	                '<th>열차번호</th>' +
	                '<th>출발역</th>' +
					'<th>도착역</th>' +
					'<th>출발시간</th>' +
					'<th>도착시간</th>' +
					'<th>소요시간</th>' +	                
	                '<th>성인요금</th>' +
					'<th>아동요금</th>' +
					'<th>좌석선택</th>' 

	                
	                '</tr>' +
	                '</thead>' +
	                '<tbody>';
	            paginatedItems.forEach(function(item) {
	                var depTime = String(item.depplandtime); 
	                var arrTime = String(item.arrplandtime);

	                var startDate = new Date(
	                    depTime.substring(0, 4), 
	                    depTime.substring(4, 6) - 1, 
	                    depTime.substring(6, 8),
	                    depTime.substring(8, 10),
	                    depTime.substring(10, 12)
	                );
	                var endDate = new Date(
	                    arrTime.substring(0, 4), 
	                    arrTime.substring(4, 6) - 1, 
	                    arrTime.substring(6, 8),
	                    arrTime.substring(8, 10),
	                    arrTime.substring(10, 12)
	                );

	                var formattedTime = startDate.toTimeString().substring(0, 5);
	                var formatted2Time = endDate.toTimeString().substring(0, 5);

	                var durationMinutes = Math.round((endDate - startDate) / 60000);
	                var hours = Math.floor(durationMinutes / 60);
	                var minutes = durationMinutes % 60;
	                
	                table += '<tr>' +
	                    '<td>' + (item.traingradename || 'N/A') + '</td>' +
	                    '<td>' + (item.trainno || 'N/A') + '</td>' +
	                    '<td>' + (item.depplacename || 'N/A') + '</td>' +
	                    '<td>' + (item.arrplacename || 'N/A') + '</td>' +
						'<td>' + formattedTime + '</td>' +
						'<td>' + formatted2Time + '</td>' +
						'<td>' + hours + '시간 ' + minutes + '분 </td>' +
						'<td>' + (item.adultcharge || 'N/A') + '</td>' +
						'<td>' + ((item.adultcharge * 0.9) || 'N/A') + '</td>' +
	                    '<td><button class="seat-btn" onclick="seatTicket(\'' + item.trainno + '\', \'' + item.depplacename + '\', \'' + item.arrplacename + '\', \'' + formattedTime + '\', \'' + formatted2Time + '\', \'' + hours + '시간 ' + minutes + '분\', \'' + item.adultcharge + '\', \'' + startdate + '\')">좌석 선택</button></td>' +	                    
	                    '<input type="hidden" class="adultcharge" value="' + (item.adultcharge || 'N/A') + '">' +
	                '</tr>';
	            });

	            table += '</tbody></table><br>';
	            document.getElementById('results').innerHTML = table;
	        } else {
	            document.getElementById('results').innerText = '해당 페이지에 데이터가 없습니다.';
	        }

	        displayPagination(items.length, page);
	    }

	    function displayPagination(totalItems, currentPage) {
	        const itemsPerPage = 12;
	        const totalPages = Math.ceil(totalItems / itemsPerPage);
	        let paginationHTML = '<nav><ul class="pagination justify-content-center">';

	        for (let i = 1; i <= totalPages; i++) {
	            paginationHTML += '<li class="page-item ' + (i == currentPage ? 'active' : '') + '">'
	                + '<a class="page-link" href="#" onclick="goToPage(' + i + ')">' + i + '</a>'
	                + '</li>';
	        }

	        paginationHTML += '</ul></nav>';
	        document.getElementById('pagination').innerHTML = paginationHTML;
	    }

	    function goToPage(page) {
	        fetchTicketInfo(page);
	    }
	</script>

</body>
</html>