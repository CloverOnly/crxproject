<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>
<%
    Integer userid = (Integer) session.getAttribute("userid");
%>
<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <meta charset="UTF-8">
    <title>FAQ</title>
    <style>
        .con {
            margin:auto;
            width: 100%;
            max-width: 1200px;
        }
        .faq-table {
            margin: auto;
            width: 100%;
            border-radius: 5px;
            border-collapse: collapse;
            border-top: none;
        }
        .header {
            background-color: rgb(226, 240, 217);
            text-align: center;
        }
        .faq-table td, .faq-table th {
            height: 30px;
            font-size: 14px;
        }
        .faqDetail {
            width: 100%;
            margin: 0 auto;
        }
        .faqHeader {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            border-top: 2px solid green;
            border-bottom: 2px solid green;
        }
        .attachment {
            display: flex;
            align-items: center;
            padding: 10px 20px;
            border-bottom: 2px solid green;
            margin-bottom: 15px;
            min-height: 50px; /* 높이를 지정하여 가운데 정렬 효과 */
        }
        .attachment div {
            display: flex;
            align-items: center; /* 높이 가운데 정렬 */
        }
        .faqContent {
            padding: 10px 20px;
            border-bottom: 2px solid green;
            margin-bottom: 15px;
            min-height: 100px;
            white-space: pre-wrap;
        }
        .buttonSet {
            display: flex;
            justify-content: space-between;
            padding: 10px 20px;
        }
        .buttonSet .left-buttons, .buttonSet .right-buttons {
            display: flex;
            gap: 10px;
        }
		.atag {
			text-decoration: none;
		}
    </style>
</head>
<body>
    <jsp:include page="header.jsp" />
    <jsp:include page="sidemenu.jsp" />
    <div class="con">
        <h1>FAQ</h1>
        <br>
        <div class="faqDetail">
            <div class="faqHeader">
                <div>
                    <span class="bg-success-subtle">&nbsp제목&nbsp</span>
                    <span>${faqDetail.faqtitle}</span>
                </div>
                <div>
                    <span class="bg-success-subtle">&nbsp등록일자 &nbsp</span>
                    <span>${faqDetail.faqdate}</span>
                </div>
            </div>
            <div class="faqContent">
                <p>${faqDetail.faqcontent}</p>
            </div>
        </div>
        <div class="buttonSet">
            <div class="left-buttons">
                <c:if test="${(divname == '고객안내' || divname == '통합관리') && (level == 'master' || level == 'admin')}">
                    <button type="button" class="btn btn-success" onclick="location.href='${contextPath}/faqMod.do?faqno=${faqDetail.faqno}'">수정</button>
                    <form action="/faqDelete.do?faqno=${faqDetail.faqno}" method="get" onsubmit="return confirm('정말로 삭제하시겠습니까?');" style="display:inline;">
                        <input type="hidden" name="faqno" value="${faqDetail.faqno}">
                        <button type="submit" class="btn btn-danger">삭제</button>
                    </form>
                </c:if>
            </div>
            <div class="right-buttons">
                <button type="button" class="btn btn-success" onclick="location.href='${contextPath}/faqList.do'">목록</button>
            </div>
        </div>
    </div>
    <jsp:include page="footer.jsp" />
</body>
</html>
