<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<script>
	document.addEventListener("DOMContentLoaded", function() {
	    buildCalendar();
	    
	    document.getElementById("btnPrevCalendar").addEventListener("click", function(event) {
	        prevCalendar();
	    });
	    
	    document.getElementById("nextNextCalendar").addEventListener("click", function(event) {
	        nextCalendar();
	    });
	});

	var toDay = new Date(); // @param 전역 변수, 오늘 날짜
	var nowDate = new Date();  // @param 전역 변수, 실제 오늘날짜 고정값

	/**
	 * @brief   이전달 버튼 클릭시
	 */
	function prevCalendar() {
	    toDay = new Date(toDay.getFullYear(), toDay.getMonth() - 1, toDay.getDate());
	    buildCalendar();    // @param 전월 캘린더 출력 요청
	}

	/**
	 * @brief   다음달 버튼 클릭시
	 */
	function nextCalendar() {
	    toDay = new Date(toDay.getFullYear(), toDay.getMonth() + 1, toDay.getDate());
	    buildCalendar();    // @param 명월 캘린더 출력 요청
	}

	/**
	 * @brief   캘린더 오픈
	 * @details 날짜 값을 받아 캘린더 폼을 생성하고, 날짜값을 채워넣는다.
	 */
	function buildCalendar() {
	    let doMonth = new Date(toDay.getFullYear(), toDay.getMonth(), 1);
	    let lastDate = new Date(toDay.getFullYear(), toDay.getMonth() + 1, 0);

	    let tbCalendar = document.querySelector(".scriptCalendar > tbody");

	    document.getElementById("calYear").innerText = toDay.getFullYear();                       // @param YYYY년
	    document.getElementById("calMonth").innerText = autoLeftPad((toDay.getMonth() + 1), 2);   // @param MM월

	    // @details 이전 캘린더의 출력결과가 남아있다면, 이전 캘린더를 삭제한다.
	    while(tbCalendar.rows.length > 0) {
	        tbCalendar.deleteRow(tbCalendar.rows.length - 1);
	    }

	    // @param 첫번째 개행
	    let row = tbCalendar.insertRow();

	    // @param 날짜가 표기될 열의 증가값
	    let dom = 1;

	    // @details 시작일의 요일값( doMonth.getDay() ) + 해당월의 전체일( lastDate.getDate())을  더해준 값에서
	    //               7로 나눈값을 올림( Math.ceil() )하고 다시 시작일의 요일값( doMonth.getDay() )을 빼준다.
	    let daysLength = (Math.ceil((doMonth.getDay() + lastDate.getDate()) / 7) * 7) - doMonth.getDay();

	    // @param 달력 출력
	    // @details 시작값은 1일을 직접 지정하고 요일값( doMonth.getDay() )를 빼서 마이너스( - )로 for문을 시작한다.
	    for(let day = 1 - doMonth.getDay(); daysLength >= day; day++) {
	        let column = row.insertCell();

	        // @param 평일( 전월일과 익월일의 데이터 제외 )
	        if(Math.sign(day) == 1 && lastDate.getDate() >= day) {
	            // @param 평일 날짜 데이터 삽입
	            column.innerText = autoLeftPad(day, 2);

	            // @param 일요일인 경우
	            if(dom % 7 == 1) {
	                column.style.color = "#FF4D4D";
	            }

	            // @param 토요일인 경우
	            if(dom % 7 == 0) {
	                column.style.color = "#4D4DFF";
	                row = tbCalendar.insertRow();   // @param 토요일이 지나면 다시 가로 행을 한줄 추가한다.
	            }

		        // @details 현재 시간 체크
		        let currentHour = new Date().getHours();
		        let isToday = (toDay.getFullYear() == nowDate.getFullYear() && toDay.getMonth() == nowDate.getMonth() && nowDate.getDate() == day);
		        let isPastDate = (toDay.getFullYear() < nowDate.getFullYear()) || 
		                          (toDay.getFullYear() == nowDate.getFullYear() && toDay.getMonth() < nowDate.getMonth()) ||
		                          (toDay.getFullYear() == nowDate.getFullYear() && toDay.getMonth() == nowDate.getMonth() && nowDate.getDate() > day);
			        if (isToday) {
		            if (currentHour >= 12) {
		                column.style.backgroundColor = "#E5E5E5";
		                column.style.cursor = "default";
		                column.onclick = null;
		            } else {
		                column.style.backgroundColor = "#FFFFE6";
		                column.style.cursor = "pointer";
		                column.onclick = function() { calendarChoiceDay(this); };
		            }
		        } else if (isPastDate) {
		            column.style.backgroundColor = "#E5E5E5";
		            column.style.cursor = "default";
		            column.onclick = null;
		        } else {
		            column.style.backgroundColor = "#FFFFFF";
		            column.style.cursor = "pointer";
		            column.onclick = function() { calendarChoiceDay(this); };
		        }
			    } else {
		        let exceptDay = new Date(doMonth.getFullYear(), doMonth.getMonth(), day);
		        column.innerText = autoLeftPad(exceptDay.getDate(), 2);
		        column.style.color = "#A9A9A9";
		        column.style.cursor = "default";
		    }
			    dom++;
		}
	}

	/**
	 * @brief   날짜 선택
	 * @details 사용자가 선택한 날짜에 체크표시를 남긴다.
	 */
	function calendarChoiceDay(column) {
	    // @param 기존 선택일이 존재하는 경우 기존 선택일의 표시형식을 초기화 한다.
	    if(document.getElementsByClassName("choiceDay")[0]) {
	        if(document.getElementById("calMonth").innerText == autoLeftPad((nowDate.getMonth() + 1), 2) && document.getElementsByClassName("choiceDay")[0].innerText == autoLeftPad(toDay.getDate(), 2)) {
	            document.getElementsByClassName("choiceDay")[0].style.backgroundColor = "#FFFFE6";  
	        } else {
	            document.getElementsByClassName("choiceDay")[0].style.backgroundColor = "#FFFFFF";
	        }
	        document.getElementsByClassName("choiceDay")[0].classList.remove("choiceDay");
	    }

	    // @param 선택일 체크 표시
	    column.style.backgroundColor = "#ccffff";
		column.style.borderRadius = "50%";
	    // @param 선택일 클래스명 변경
	    column.classList.add("choiceDay");
	    
	    // 선택한 날짜를 여행 기간 표시 요소에 출력
		var selectedYear = document.getElementById("calYear").innerText;
		var selectedMonth = document.getElementById("calMonth").innerText;
		var selectedDay = column.innerText;
		var selectedDate = selectedYear + "년 " + selectedMonth + "월 " + selectedDay + "일";
		document.getElementById("tourdateDisplay").innerText = selectedDate;
		document.getElementById("tourdate").value = selectedDate;
	}

	/**
	 * @brief   숫자 두자릿수( 00 ) 변경
	 * @details 자릿수가 한자리인 ( 1, 2, 3등 )의 값을 10, 11, 12등과 같은 두자리수 형식으로 맞추기위해 0을 붙인다.
	 * @param   num     앞에 0을 붙일 숫자 값
	 * @param   digit   글자의 자릿수를 지정 ( 2자릿수인 경우 00, 3자릿수인 경우 000 … )
	 */
	function autoLeftPad(num, digit) {
	    if(String(num).length < digit) {
	        num = new Array(digit - String(num).length + 1).join("0") + num;
	    }
	    return num;
	}
</script>
<!DOCTYPE html>
<html>
<head>
<title>관광상품 리스트</title>
<style>
	.detailheader{
		background-color:green;
		height:30px;
	}
	.detail{
		padding:20px;
	}
	.detailtitle{
		text-align: center;
	}
	.detailcontent{
		display: flex;
	}
	.detailimg img{
		border-radius: 10px;
	}
	#carouselExampleIndicators{
		margin-right: 30px;
		width: 65%;		
	}
	.people{
		display: flex;
		align-items: flex-start;
	}
	.no{
		margin-left: 10px;
		font-size: 12px;
	}
	.tourdetail{
		text-align: center;
		width: 100px;
		border: 1px solid black;
		border-radius: 10px 10px 0 0;
		border-bottom: 0px;
		background-color: rgb(240, 240, 240);
	}
	#detail, #detail2, #detail3{
		padding: 10px;
	}
	.content{
		background-color: rgb(226, 240, 217);
		font-size: 20px;
		font-weight: bold;
	}	

	a { color:#000000; text-decoration:none; }
	.scriptCalendar { text-align:center; }
	.scriptCalendar > thead > tr > td { width:50px;height:50px; }
	.scriptCalendar > thead > tr:first-child > td { font-weight:bold; }
	.scriptCalendar > thead > tr:last-child > td { background-color: rgb(226, 240, 217); }
	.scriptCalendar > tbody > tr > td { width:50px;height:50px; }
	.calendarBtn { cursor:pointer; } 

	.mod{
		display: flex;
		justify-content: space-between;
		width: 126px;
		position: relative;
		left: 87%;
		top: 130%;
	}
	.coinreserv{
		display: flex;
		justify-content: space-between;
	    align-items: center;
	}
</style>
<script>
	function deleteTour(url) {
	    if (confirm('정말 삭제 하시겠습니까?')) {
	        fetch(url, { method: 'GET' })
	            .then(response => {
	                if (response.ok) {
	                    alert('삭제되었습니다.');
	                    if (window.opener) {
	                        window.opener.location.reload();
	                        window.close();
	                    }
	                } else {
	                    alert('삭제 실패');
	                }
	            })
	    }
	}

	function updatetotalcoin() {
	    const numPeople = document.getElementById('numPeople').value;
	    const tourCoin = ${tour.tourcoin != null ? tour.tourcoin : 0};  // tourcoin이 null일 경우 기본값 0 설정
	    const totalcoin = numPeople * tourCoin;
	    const formattedTotalCoin = totalcoin.toLocaleString('ko-KR'); // 3자리마다 쉼표 추가
	    document.getElementById('totalcoin').innerText = formattedTotalCoin + '원';
	    document.getElementById('totalAmount').value = totalcoin; // 총 금액을 숨겨진 필드에 설정
	}

	function validateForm() {
	     const numPeople = document.getElementById('numPeople').value;
	     const tourDate = document.getElementById('tourdate').value;
	     const userid = "${param.userid}"; // JSP에서 userid를 가져옴

		 if (userid === "Guest") {
		     alert('로그인 후 이용가능합니다.');
		     return false;
		 }
		 
	     if (numPeople < 1) {
	         alert('예약 인원을 선택하세요.');
	         return false;
	     }

	     if (!tourDate) {
	         alert('여행 날짜를 선택하세요.');
	         return false;
	     }


	     if (!confirm('장바구니에 추가하시겠습니까?')) {
	         return false;
	     }

	     return true;
	 }

	document.addEventListener('DOMContentLoaded', (event) => {
	    document.getElementById('numPeople').addEventListener('change', updatetotalcoin);
	    updatetotalcoin(); // 초기값 설정
	});
	
</script>
</head>
<body>
	<c:set var="filePath1" value="${fn:replace(tour.file1, '\\\\', '/')}"/>
	<c:set var="file1" value="${fn:replace(filePath1, 'src/main/webapp/', '../')}"/>

	<c:set var="filePath2" value="${fn:replace(tour.file2, '\\\\', '/')}"/>
	<c:set var="file2" value="${fn:replace(filePath2, 'src/main/webapp/', '../')}"/>

	<c:set var="filePath3" value="${fn:replace(tour.file3, '\\\\', '/')}"/>
	<c:set var="file3" value="${fn:replace(filePath3, 'src/main/webapp/', '../')}"/>

	<!-- 성공 또는 실패 메시지 처리 -->
	<c:if test="${not empty message}">
	    <script>
	        alert("${message}");
	    </script>
	</c:if>
	<c:if test="${not empty errorMessage}">
	    <script>
	        alert("${errorMessage}");
	    </script>
	</c:if>
	
	<div class="detailheader">
		
	<c:if test="${(divname == '여행상품' || divname == '통합관리') && (level == 'master' || level == 'admin')}">
		<div class="mod">
			  <button class="btn btn-success" onclick="location.href='${contextPath}/tourMod.do?tourrnum=${tour.tournum}&index=${param.index}'">수정</button>
			  <button class="btn btn-danger" onclick="deleteTour('${contextPath}/tourDelete.do?tournum=${tour.tournum}');">삭제</button>
		</div>
	</c:if>

	</div>
	
	<form action="tourReserv" method="post" onsubmit="return validateForm()">
		<input type="hidden" name="tournum" value="${tour.tournum}">
		<input type="hidden" name="index" value="${param.index}">
		<input type="hidden" name="userid" value="${param.userid}">		
		
	<div class="detail">
		<h1 class="detailtitle">${tour.tourtitle}</h1>
		<input type="hidden" name="tourtitle" value="${tour.tourtitle}">
		<br>
			<div class="detailcontent">
				<div id="carouselExampleIndicators" class="carousel slide">
	  				<div class="carousel-indicators">
	    				<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
	    				<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
	    				<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
	  				</div>
	  				<div class="carousel-inner">
	    				<div class="carousel-item active">
	      					<img src="${file1}" class="d-block w-100 h-80" alt="..." style="width:740px; height:470px;">
	    				</div>
	    				<div class="carousel-item">
		      				<img src="${file2}" class="d-block w-100 h-80" alt="..." style="width:740px; height:470px;">
		    			</div>
	    				<div class="carousel-item">
	      					<img src="${file3}" class="d-block w-100 h-80" alt="..." style="width:740px; height:470px;">
	    				</div>
	  				</div>
	  				<button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
	    				<span class="carousel-control-prev-icon" aria-hidden="true"></span>
	    				<span class="visually-hidden">Previous</span>
	  				</button>
	  				<button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
		    			<span class="carousel-control-next-icon" aria-hidden="true"></span>
		    			<span class="visually-hidden">Next</span>
	  				</button>
				</div>

			<div class="detailname">
				<h6><b>상품번호 : ${tour.tourno}</b></h6>
				<input type="hidden" name="tourno" value="${tour.tourno}">
				<h6><b>상품명 : ${tour.tourname}</b></h6>
				<input type="hidden" name="tourname" value="${tour.tourname}">
				<div class="people">	
					<h6><b>예약 인원 : </b></h6>	
					<select id="numPeople" name="tourcount" class="no" style="font-size:14px">
						<option value="0">0명</option>
						<option value="1">1명</option>
						<option value="2">2명</option>
						<option value="3">3명</option>
						<option value="4">4명</option>
						<option value="5">5명</option>
						<option value="6">6명</option>
						<option value="7">7명</option>
						<option value="8">8명</option>
						<option value="9">9명</option>
						<option value="10">10명</option>				
					</select>
				</div>
					<h6><b>여행 날짜 : </b><span id="tourdateDisplay">날짜를 선택하세요</span></h6>
					<input type="hidden" id="tourdate" name="tourdate" value="${tourdateDisplay}" />
				<div>				
		    		<table class="scriptCalendar">
		        		<thead>
		    		        <tr>
	    	            		<td class="calendarBtn" id="btnPrevCalendar">&#60;&#60;</td>
	        	        		<td colspan="5">
	            	        		<span id="calYear">YYYY</span>년
	                	    		<span id="calMonth">MM</span>월
	                			</td>
	                			<td class="calendarBtn" id="nextNextCalendar">&#62;&#62;</td>
	           				</tr>
				            <tr>
	    	    		        <td>일</td><td>월</td><td>화</td><td>수</td><td>목</td><td>금</td><td>토</td>
	        	    		</tr>
	        			</thead>
	        			<tbody></tbody>
	    			</table>
				</div>
				<div class="coinreserv">
					<h6><b>금액 :</b> <span id="totalcoin"></span></h6>
					<input type="hidden" id="totalAmount" name="totalcoin">
					<button class="btn btn-success">장바구니 추가</button>
				</div>
			</div>
		</form>
	</div>
	<ul class="nav nav-underline">
		<li class="nav-item">
	    	<a class="nav-link active" aria-current="page" href="#">상세 설명</a>
  		</li>
  		<li class="nav-item">
		    <a class="nav-link" href="#detail2">요금안내</a>
	  	</li>
  		<li class="nav-item">
		    <a class="nav-link" href="#detail3">참고사항</a>
	  	</li>  
	</ul>
	<div id="detail">
		${tour.tourcontent}	
	</div>
	<br>
	<br>
	
	<p class="content">요금안내</p>
	<div id="detail2">		
		<div class="faretable">
				${tour.tourcost}		
		</div>
	</div>
	<br>
	<br>
	
	<p class="content">참고사항</p>
	<div id="detail3">
		${tour.tournoted}
	</div>
	</div>
</div>
</body>
</html>
