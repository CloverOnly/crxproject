<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <title>Seat Selection</title>
</head>
<body>
    <h1>좌석 선택</h1>
    <table border="1">
        <thead>
            <tr>
                <th>호차</th>
                <th>선택 좌석</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach var="seat" items="${seats}">
                <tr>
                    <td>${seat.hocha}</td>
                    <td>${seat.selectedSeats}</td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
</body>
</html>
