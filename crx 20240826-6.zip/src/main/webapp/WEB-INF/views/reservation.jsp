<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
	<meta charset="UTF-8">
    <title>예약</title>
    <style>
        .all {
            width: 1200px;    
            margin: 0 auto; /* 중앙 정렬 */
        }
        .tiline {
            display: inline;
            border: solid 1px green;
            border-radius: 8px;
            padding: 5px;
            color: green;
            margin: 5px;
        }
        .guide {
			width: 1200px;
			height: 80px;
			background-color: #f8f8f8;
			margin: 2px;
			padding: 5px;
        }
        .guidep {
            margin-bottom: 3px;
        }
        .payment {
            text-align: center;
        }
		.bi{
			color: red;
		} 
    </style>
    <script>
        window.addEventListener('load', function() {
            // 서버에서 전달된 예약 정보 리스트를 JavaScript 배열로 변환
            var reservations = [];
            
            <c:forEach var="reservation" items="${reservation}">
                reservations.push({
					reservno: '${reservation.reservno}',
                    startname: '${reservation.startname}',
                    endname: '${reservation.endname}',
                    seatType: '${reservation.seatType}',
                    startdate: '${reservation.startdate}',
                    trainType: '${reservation.trainType}',
                    personnelCount: parseInt('${reservation.personnelCount}', 10) || 0,
                    childCount: parseInt('${reservation.childCount}', 10) || 0,
                    trainno: '${reservation.trainno}',
                    depTime: '${reservation.depTime}',
                    arrTime: '${reservation.arrTime}',
                    duration: '${reservation.duration}',
                    selectedSeats: '${reservation.selectedSeats}',
                    hocha: '${reservation.hocha}',
                    totalAdultCharge: parseFloat('${reservation.totalAdultCharge}') || 0,
                    totalChildCharge: parseFloat('${reservation.totalChildCharge}') || 0,
                    endCharge: parseFloat('${reservation.endCharge}') || 0,
                    totalCharge: parseFloat('${reservation.totalCharge}') || 0,
                    totalDiscount: parseFloat('${reservation.totalDiscount}') || 0,
                    userid: '${reservation.userid}'
                });
            </c:forEach>

            // 첫 번째 예약 정보를 가져와 폼에 채우기
            if (reservations.length > 0) {
                var firstReservation = reservations[0];
                
				document.getElementById('reservno').value = firstReservation.reservno;
                document.getElementById('startname').value = firstReservation.startname;
                document.getElementById('endname').value = firstReservation.endname;
                document.getElementById('seatType').value = firstReservation.seatType;
                document.getElementById('startdate').value = firstReservation.startdate;
                document.getElementById('trainType').value = firstReservation.trainType;
                document.getElementById('personnelCount').value = firstReservation.personnelCount;
                document.getElementById('childCount').value = firstReservation.childCount;
                document.getElementById('trainno').value = firstReservation.trainno;
                document.getElementById('depTime').value = firstReservation.depTime;
                document.getElementById('arrTime').value = firstReservation.arrTime;
                document.getElementById('duration').value = firstReservation.duration;
                document.getElementById('selectedSeats').value = firstReservation.selectedSeats;
                document.getElementById('hocha').value = firstReservation.hocha;
                document.getElementById('totalAdultCharge').value = firstReservation.totalAdultCharge;
                document.getElementById('totalChildCharge').value = firstReservation.totalChildCharge;
                document.getElementById('endCharge').value = firstReservation.endCharge;
                document.getElementById('totalCharge').value = firstReservation.totalCharge;
                document.getElementById('totalDiscount').value = firstReservation.totalDiscount;
                document.getElementById('userid').value = firstReservation.userid;
            }
        });

        function reservationForm() {
            document.getElementById('reservationForm').submit();
			
        }
        
        function tBack() {
            window.location.href = '${contextPath}/ticket.do';
        }
    </script>
</head>
<body>
    <jsp:include page="header.jsp" />
    <div class="all">    
        <div class="maintitle">
            <h1>예약</h1>
            <hr>
        </div>
            
        <br>
        <div style="text-align:center;">
            <img src="../img/mark2.gif" style="width:500px">
        </div>
        
        <br>
        <div class="guide">
			<br>
            <i class="bi bi-exclamation-circle"></i>
			<span class="guidep"><strong>10분 내에 결제하지 않으면 취소됩니다.</strong></span>
			<br>
        </div>
        
        <br>
        <div>
            <table class="table">
                <thead class="table-success">
                    <tr>
                        <th>승차일자</th>
                        <th>열차종류</th>
                        <th>열차번호</th>
                        <th>출발역</th>
                        <th>도착역</th>
                        <th>출발시간</th>
                        <th>도착시간</th>
                        <th>인원</th>
                        <th>결제금액</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="reservation" items="${reservation}">
                        <tr>
                            <td>${reservation.startdate}</td>
                            <td>${reservation.trainType}</td>
                            <td>${reservation.trainno}</td>
                            <td>${reservation.startname}</td>
                            <td>${reservation.endname}</td>
                            <td>${reservation.depTime}</td>
                            <td>${reservation.arrTime}</td>
                            <td>${reservation.personnelCount + reservation.childCount}</td>
                            <td>${reservation.endCharge}원</td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
        
        <br>
        <div>
            <table class="table">
                <thead class="table-success">
                    <tr>
                        <th>열차번호</th>
                        <th>객실등급</th>
                        <th>좌석정보</th>    
                        <th>운임요금</th>
                        <th>할인금액</th>
                        <th>영수금액</th>
                    </tr>    
                </thead>
                <tbody>
                    <c:forEach var="reservation" items="${reservation}">
                        <tr>
                            <td>${reservation.trainno}</td>
                            <td>${reservation.seatType}</td>
                            <td>${reservation.hocha}${reservation.selectedSeats}</td>                
                            <td>${reservation.totalCharge}원</td>
                            <td>${reservation.totalDiscount}원</td>
                            <td>${reservation.endCharge}원</td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>

        <br><br><br>
        <div class="payment">
            <form id="reservationForm" action="${contextPath}/payment.do" method="post">
                <input type="hidden" id="startname" name="startname" />
                <input type="hidden" id="endname" name="endname" />
                <input type="hidden" id="seatType" name="seatType" />
                <input type="hidden" id="startdate" name="startdate" />
                <input type="hidden" id="trainType" name="trainType" />
                <input type="hidden" id="personnelCount" name="personnelCount" />
                <input type="hidden" id="childCount" name="childCount" />
                <input type="hidden" id="trainno" name="trainno" />
                <input type="hidden" id="depTime" name="depTime" />
                <input type="hidden" id="arrTime" name="arrTime" />
                <input type="hidden" id="duration" name="duration" />
                <input type="hidden" id="selectedSeats" name="selectedSeats" />
                <input type="hidden" id="hocha" name="hocha" />
                <input type="hidden" id="totalAdultCharge" name="totalAdultCharge" />
                <input type="hidden" id="totalChildCharge" name="totalChildCharge" />
                <input type="hidden" id="endCharge" name="endCharge" />
                <input type="hidden" id="totalCharge" name="totalCharge" />
                <input type="hidden" id="totalDiscount" name="totalDiscount" />
                <input type="hidden" id="userid" name="userid" />
				<input type="hidden" id="reservno" name="reservno" />

                <!-- 버튼 클릭 시 폼을 제출합니다 -->
				<button id="seatPament" type="button" class="btn btn-success" onclick="reservationForm()">예매하기</button>
				<button type="button" class="ba btn btn-success" onclick="tBack()">돌아가기</button>
			</form>
        </div>    
    </div>

    <jsp:include page="sidemenu.jsp" />
    <jsp:include page="footer.jsp" />
</body>
</html>
