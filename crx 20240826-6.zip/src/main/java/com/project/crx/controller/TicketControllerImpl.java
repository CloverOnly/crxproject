package com.project.crx.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.TicketService;
import com.project.crx.vo.TicketVO;

@Controller
public class TicketControllerImpl implements TicketController {
	
    private final TicketService ticketService;
	private Object ticketingService;

    // 생성자 주입
    public TicketControllerImpl(TicketService ticketService) {
        this.ticketService = ticketService;
    }
	
	//일반예매
    @GetMapping("/ticket.do")
    public String ticket() {
        return "ticket"; 
    }
    
    //단체예매
    @GetMapping("/groupTicket.do")
    public String groupTicket() {
        return "groupTicket"; 
    }
    
    //역 명 조회 작은 팝업
    @GetMapping("/lookUp.do")
	public String lookUp() {
	    return "lookUp"; 
	}
	@GetMapping("/lookUp2.do")
	public String lookUp2() {
	    return "lookUp2"; 
	}

	//좌석예매 팝업
	@GetMapping("/seat.do")
	public String seat(Model model) {
        List<TicketVO> seat = ticketService.getSeat();
        if (seat == null || seat.isEmpty()) {
            System.out.println("No ticketing data available.");
        }
        model.addAttribute("seat", seat);
        return "seat"; // JSP 페이지 이름
    }
	@PostMapping("/seat.do")
	public ModelAndView saveSeat(@ModelAttribute("seat") TicketVO seat, BindingResult result, RedirectAttributes rAttr) {
	    ModelAndView mav = new ModelAndView("redirect:/seat.do");

	    if (result.hasErrors()) {
	        mav.addObject("message", "좌석 정보 저장에 실패했습니다. 입력값을 확인해 주세요.");
	        mav.setViewName("seat");
	        return mav;
	    }

	    try {
	        // 좌석 정보를 저장하는 서비스 호출
	        ticketService.saveSeat(seat);
	        rAttr.addFlashAttribute("message", "좌석 정보가 성공적으로 저장되었습니다.");
	    } catch (Exception e) {
	        e.printStackTrace();
	        rAttr.addFlashAttribute("message", "좌석 정보 저장에 실패했습니다.");
	    }

	    return mav;
	}


    //예약
    @GetMapping("/reservation.do")
    public String reservation(Model model) {
        // 서비스 레이어를 통해 예약 정보 가져오기
        List<TicketVO> reservation = ticketService.getReservation();
        
        // 모델에 예약 정보 추가
        model.addAttribute("reservation", reservation);

        return "reservation"; // JSP 페이지 이름
    }

    
    //결제
    @GetMapping("/payment.do")
    public String payment(Model model) {
        // 서비스 레이어를 통해 예약 정보 가져오기
        List<TicketVO> payment = ticketService.getPayment();
        
        // 모델에 예약 정보 추가
        model.addAttribute("payment", payment);

        return "payment"; // JSP 페이지 이름
    }
    @PostMapping("/payment.do")
    public ModelAndView savePayment(@ModelAttribute("payment") TicketVO payment, BindingResult result, RedirectAttributes rAttr) {
        ModelAndView mav = new ModelAndView();

        if (result.hasErrors()) {
            // 유효성 검사 실패 시 에러 메시지를 모델에 추가하고 폼으로 돌아감
            mav.addObject("message", "좌석 정보 저장에 실패했습니다. 입력값을 확인해 주세요.");
            mav.setViewName("payment");
            return mav;
        }

        try {
            // 좌석 정보를 저장하는 서비스 호출
            rAttr.addFlashAttribute("message", "예매 정보가 성공적으로 저장되었습니다.");
            mav.setViewName("redirect:/payment.do"); // 성공 후 리디렉션할 페이지
        } catch (Exception e) {
            e.printStackTrace();
            rAttr.addFlashAttribute("message", "예매 정보 저장에 실패했습니다.");
            mav.setViewName("payment"); // 실패 시 다시 폼 페이지로 돌아가기
        }

        return mav;
    }
    @PostMapping("/ticketPay")
    @ResponseBody
    public String handlePaymentResult(@RequestBody TicketVO paymentRecord) {
        // 데이터베이스에 저장
        boolean success = ticketService.savePayment(paymentRecord);
        return success ? "Success" : "Error";
    }
    

    
    //발권
    @GetMapping("/ticketing.do")
    public String ticketing(Model model, @RequestParam("apply_num") int applyNum) {
    	//System.out.println("fdsfdsddsf");
    	//System.out.println(applyNum);
        List<TicketVO> ticketing = ticketService.getTicketing(applyNum);
        if (ticketing == null || ticketing.isEmpty()) {
            System.out.println("No ticketing data available.");
        }
        model.addAttribute("ticketing", ticketing);
        return "ticketing"; // JSP 페이지 이름
    }

    
    //예매관리
    @GetMapping("/management.do")
    public String management() {
        return "management"; 
    }
    
    //이용내역
    @GetMapping("/usageDetails.do")
    public String usageDetails() {
        return "usageDetails"; 
    }
    
    //환불
    @GetMapping("/refund.do")
    public String refund() {
        return "refund"; 
    }
    
    //환불완료
    @GetMapping("/refundEnd.do")
    public String refundEnd() {
        return "refundEnd"; 
    }
    
    //화천역
    @GetMapping("/hwacheon.do")
    public String hwacheon() {
        return "hwacheon"; 
    }
    //양구역
    @GetMapping("/yanggu.do")
    public String yanggu() {
        return "yanggu"; 
    }
    //인제역
    @GetMapping("/inje.do")
    public String inje() {
        return "inje"; 
    }
    //고성역
    @GetMapping("/goseong.do")
    public String goseong() {
        return "goseong"; 
    }
    //속초역
    @GetMapping("/sokcho.do")
    public String sokcho() {
        return "sokcho"; 
    }
    //양양역
    @GetMapping("/yangyang.do")
    public String yangyang() {
        return "yangyang"; 
    }
    
    
    
    //테스트
    @GetMapping("/test.do")
    public String test() {
        return "test"; 
    }
    @GetMapping("/test2.do")
    public String test2() {
        return "test2"; 
    }
	@GetMapping("/test3.do")
	public String test3() {
	    return "test3"; 
	}
	@GetMapping("/test4.do")
	public String test4() {
	    return "test4"; 
	}


	public ModelAndView saveSeat(TicketVO seat, RedirectAttributes rAttr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ModelAndView savePayment(TicketVO payment, RedirectAttributes rAttr) {
		// TODO Auto-generated method stub
		return null;
	}


	
}